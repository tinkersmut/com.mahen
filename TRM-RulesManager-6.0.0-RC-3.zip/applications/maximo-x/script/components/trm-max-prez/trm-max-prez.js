    Polymer({
      is: 'trm-max-prez',
      behaviors: [BaseComponent],
      properties: {
        /**
         * the xml representation of the maximo application fetched by an RM OSLC Script 
         */
        xml: {
          type: String,
          notify: true,
        },
        /**
         *  the name of the app
         */
        appname: {
          type: String,
          notify: true,
        },
        /**
         * the dom of the application
         */
        presentation: {
          type: Object
        },
        /**
         * The rules to be passed to the supporting controls
         */
        rules: {
          type: Object,
          notify: true,
        },
        /**
         * a csv list of dialogs
         */
        dialogstr: {
          type: String,
          notify: true
        },
        /**
         * a json map of app dialogs and their dom node
         */
        dialogmap: {
          type: Object,
          notify: true
        },

      },
      observers: ['_obsxml(xml,rules)'],
      listeners: {
        'dialogselector.change': '_selectdialog',
        'contextmenu-node': '_showContextMenu',
        'blur': '_onblur'
      },
      created: function() {

      },
      ready: function() {

      },
      attached: function() {

      },
      /**
       * fetch the app/dialogs when the app xml is defined
       */
      _obsxml: function() {
        //ensure both the app string and the rules have been defined
        if (this.xml && this.rules) {
          //remove any dialogs that had been displayed
          this._removeDisplayedDialogs();
          //create a domparser
          var dparser = new DOMParser();
          //parse the application xml
          var parsed = dparser.parseFromString(this.xml, "text/xml");
          //find the page (node)
          this.presentation = parsed.querySelector("page");
          //clear the presentation area if an app is displayed
          if (this.$.container.children.length > 0) {
            this.$.container.removeChild(this.$.container.firstElementChild);
          }
          //create the handler to present the application
          var newchild = Polymer.Base.create('trm-max-control-handler', {
            'rules': this.rules,
            'component': this.presentation,
            'id': 'prez'

          });
          //append the control
          this.$.container.appendChild(newchild);


          //get the dialogs list from the parsed app
          var dialogarr = parsed.querySelectorAll("dialog");
          //map to store the dialogname/node
          var dmap = {};
          //list of dialog names
          var list = "";
          //create the csv of the dialog names, and store their corresponding nodes
          for (var i = 0; i < dialogarr.length; i++) {
            //get the current dialog
            var curr = dialogarr[i];
            //get its id and label
            var cid = curr.getAttribute("id");
            var clabel = curr.getAttribute("label");
            //create it's name in the select list
            var mainval = clabel + "(" + cid + ")";
            //if there's no label
            if (clabel == null || clabel.length == 0) {
              //just use the id
              mainval = cid;
            }
            //add the element to the map
            dmap[mainval] = {
              "node": curr
            };
            //append to the list
            if (list.length > 0) {
              list = list + "," + mainval;
            } else {
              list = mainval;
            }
          }
          //store the variables
          this.dialogmap = dmap;
          this.dialogstr = list;
        } else {
          // console.log("not set yet: ", this.xml, this.rules)
        }
      },
      /**
       * displays the selected dialog
       */
      _selectdialog: function(evt) {
        //remove any dialog that has been previously been displayed
        this._removeDisplayedDialogs();
        //get the selection
        var currcomp = this.dialogmap[evt.srcElement.value].node;
        //if we can't find it, return null
        if (currcomp == null) {
          return;
        }
        //create the new component
        var newchild = Polymer.Base.create('trm-max-control-handler', {
          'rules': this.rules,
          'component': currcomp,
          'id': 'dialogcontent'

        });
        //append the new child
        this.$.currdialog.appendChild(newchild);
      },
      /**
       * remove the dialog if it's displayed
       */
      _removeDisplayedDialogs: function() {
        //look in the dialog section
        while (this.$.currdialog.children[0]) {
          //remove the dialog
          Polymer.dom(this.$.currdialog).removeChild(this.$.currdialog.children[0]);
        }
      },
      /**
       * Called when an open menu is clicked off
       */
      _closemenu: function(e) {
        let menu = this.$.menu;
        if (!menu) {
          return;
        }
        Polymer.Base.async(function() {
          menu.close();
        }, 200);
        e.stopPropagation();
      },

      /**
       * Unfocus from this prez...close menu if open
       */
      _onblur: function(e) {
        this.closemenu(e);
      },

      /**
       * Called when a control is right clicked
       */
      _showContextMenu: function(e) {
        // node trm-max-control firing event
        // component is node.component
        // tag name is node.component.tagName
        let node = e.detail.node;
        let x = e.detail.x;
        let y = e.detail.y;

        // no actions to show
        if (!this._cmactions || !this._cmactions.length) {
          return;
        }

        // set the current node for each action
        this._cmactions.forEach(function(action) {
          action.node = node;
          //TODO: configure check states for check actions
        });
        
        // populate right click menu with unhidden actions
        this.$.menu.items = this._cmactions.filter(function(action) {
          return action.hide && !action.hide(node);
        });
        
        // nothing to show
        if (!this.$.menu.items.length) {
          return;
        }

        // needed for positioning
        this.$.menu.top = y;
        this.$.menu.left = x;

        // open it
        this.$.menu.open();
      },

      /**
       * Add an action for right click. Use the hide property of the action param to determine if this action should be shown for the passed in node. 
       * NOTE: node is the control that was right clicked (i.e trm-max-control-handler).
       * @param action POJO (ex: {name: String/function, icon: String/function, hide: function(node){return node.component.tagName == 'textbox', run: function(node)})
       */
      addContextAction: function(action) {
        // doesn't exist...create empty
        let temp = this._cmactions ? this._cmactions : [];
        this._cmactions = temp.concat([action]);
      },

      /**
       * Called when an action is run from context menu
       */
      _selectItem: function(e) {
        let item = e.detail.item;
        let node = item.node;
        
        // close open menu
        this._closemenu(e);
        
        // run action
        if (node && item.run && typeof(item.run) === 'function') {
          item.run(node);
          
          // TODO: update prez
        }
      }

    });
