Polymer({
  is : 'trm-max-compregistry',
  behaviors : [ BaseComponent ],
  properties : {
    /**
     * Set to true on this element to not cache data. Caches by default
     */
    noCache : {
      type : Boolean,
      value : false,
      notify : true
    },

    /**
     * The key used in the localStorage to hold this cache
     */
    _key : {
      type : String,
      value: 'compregistry',
      notify : true
    },
    /**
     * Data fetched from the server via ajax
     */
    _response : {
      type : Object,
      notify : true,
      observer : '_handleResponse'
    },
    /**
     * Data response from the server
     */
    data : {
      type : Object,
      notify : true,
      observer : '_dataUpdated'
    },
    
    /**
     * Name of the registry file in the war 
     */
    _regname : {
      type: String,
      value: 'registry.json',
      observer : '_updateURL'
    }

  },
  
  ready: function(){
    // initialize
    this._updateURL();
  },
  
  _updateURL: function(){
    let pathname = window.location.pathname;
    // fix when index.html is in play
    pathname = pathname.replace(/index\.html/i,'');
    this._url = window.location.origin + pathname + this._regname;
  },

  /**
   * Called whenever the _response is set. Does nothing if caching...sets data if no-caching
   */
  _handleResponse : function(response) {
    if(this.noCache) {
      this.data = response;
    }
  },

  _dataUpdated : function() {
    if(!this.data || !this._resolve) {
      return;
    }
    this._resolve(this.data);
  },

  /**
   * Retrieves the registry from the server
   * @return Promise that resolves to {maximo:,library:} when fetched
   */
  fetchRegistry: function() {
    if(this.data){
      this._fetchpromise = undefined;
      return Promise.resolve(this.data);
    }
    if(this._fetchpromise){
      return this._fetchpromise;
    }
    this._resolve = undefined;
    this._reject = undefined;
    this._fetchpromise = new Promise((resolve, reject)=>{
      this._resolve = resolve;
      this._reject = reject;
      this.$.xwar.generateRequest();
    });
    return this._fetchpromise;
  },
  
  /**
   * Get all maximo- components
   * @return Promise that resolves to [name:,description:,files:]
   */
  getMaximoComponents: function(){
    if(this.data){
      return Promise.resolve(this.data.maximo.filter(c => !c.behavior));
    }
    return new Promise((resolve, reject) => {
      this.fetchRegistry().then(data => {
        if(!data || !data.maximo){
          reject("Failed to retrieve registry");
          return;
        }
        resolve(data.maximo.filter(c => !c.behavior));
      }, err=>{
        reject(err);
      })
    });
  },
  
  /**
   * Get all maximo behaviors
   * @return Promise that resolves to [name:,description:,files:]
   */
  getMaximoBehaviors: function(){
    if(this.data){
      return Promise.resolve(this.data.maximo.filter(c => c.behavior));
    }
    return new Promise((resolve, reject) => {
      this.fetchRegistry().then(data => {
        if(!data || !data.maximo){
          reject("Failed to retrieve registry");
          return;
        }
        resolve(data.maximo.filter(c => c.behavior));
      }, err=>{
        reject(err);
      })
    }); 
  },
  
  /**
   * Get all non maximo- components
   * @return Promise that resolves to [name:,description:,files:]
   */
  getLibraryComponents: function(){
    if(this.data){
      return Promise.resolve(this.data.library);
    }
    return new Promise((resolve, reject) => {
      this.fetchRegistry().then(data => {
        if(!data || !data.library){
          reject("Failed to retrieve registry");
          return;
        }
        resolve(data.library);
      }, err=>{
        reject(err);
      })
    });
  },

  /**
   * Retrieves the registry from the server
   * @return Promise that resolves to {name:,description:,files:} when fetched
   */
  getComponent: function(name){
    // safety first
    if(name === undefined){
      return Promise.reject('Illegal argument');
    }
    let promise = undefined;
    // maximo component
    if(name.match(/^maximo\-/i)){
      promise = this.getMaximoComponents()
    }      

    // library component
    else{
      promise = this.getLibraryComponents();
    }
    return new Promise((resolve, reject) => {
      promise.then(data => {
        let filtered = data.filter(c => c.name == name);
        if(!filtered || !filtered.length){
          reject('Component '+name+' not found');
          return;
        }
        resolve(filtered[0]);
      }, err => {
        reject(err);
      });
    });
  },
  
  /**
   * Retrieves the behavior file
   * @return Promise that resolves to {name:,description:,files:} when fetched
   */
  getBehaviorFile: function(name){
    // safety first
    if(name === undefined){
      return Promise.reject('Illegal argument');
    }
    return new Promise((resolve, reject) => {
      this.getMaximoBehaviors().then(data => {
        let filtered = data.filter(c => c.name == name);
        if(!filtered || !filtered.length || !filtered[0].files.length){
          reject('Behavior '+name+' not found');
          return;
        }
        resolve(filtered[0].files[0]);
      }, err => {
        reject(err);
      });
    });
  },
  
  /**
   * Handles an ajax error from the server
   */
  _processError : function(e) {
    if(this._reject) {
      var error = e;
      if(e.detail && e.detail.error)
        error = e.detail.error;
      this._reject(error);
    }
  },
});
