Polymer({
  is: 'trm-max-control-tabledetails',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {},
  listeners: {},
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },

});