Polymer({
  is: 'trm-max-control-tablecol',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {
    inputrow: {
      type: Boolean,
      notify: true,
      value: false
    },
    imagesrc: {
      type: String,
      notify: true,
      value: function() {
        return this.getImagePath("img_row_unselect_over.gif")
      }
    }
  },
  listeners: {
    //'tablecol.click' : 'expanddetails'
  },
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },
  getImageSrc: function() {
    switch (this.getType()) {
      case 2:
        return this.getImagePath(this.getAtt(this.component, 'mxevent_icon'));
      case 3:
        return this.getImagePath('img_row_unselect_over.gif');
    }

  },
  getInputWidth: function() {
    var ret = 61
    if (this.hasAtt(this.component, "attlength")) {
      var len = parseInt(this.getAtt(this.component, "attlength"));
      if (len <= 25) {
        ret = 75;
      } else {
        ret = 125;
      }
    }
    return ret;
  },
  isSelect: function() {
    return this.getType() == 1;
  },
  isMxEventIcon: function() {
    return this.getType() == 2;
  },
  isStandard: function() {
    return this.getType() == 0;
  },
  isToggle: function() {
    return this.getType() == 3;
  },
  getType: function() {
    if (!this.hasAtt(this.component, "mxevent")) {
      return 0;
    }
    if (this.hasAtt(this.component, "mxevent_icon")) {
      return 2;
    }
    var att = this.getAtt(this.component, "mxevent");
    switch (att) {
      case "toggleselectrow":
        return 1;
      case "toggledetailstate":
        return 3;
      default:
        return 0;
    }

    return 0;
  },
  expanddetails: function() {
    try {
      var query = this.$$('img');
      if (query.id == "toggleicon") {
        if (query.src == this.getImagePath('img_row_select_over.gif')) {
          query.src = this.getImagePath('img_row_unselect_over.gif');
        } else {
          query.src = this.getImagePath('img_row_select_over.gif');
        }
      }
    } catch (err) {
      console.log("couldn't change icon ", query, err);
    }
    this.fire('maxprez-table-expand', {});
  }

});