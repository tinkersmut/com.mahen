///    Copyright (c)  2002-2019
//
//    Total Resource Management (TRM)
//    5695 King Centre Dr
//    Alexandria, VA 22315
//    703.548.4285
//    www.trmnet.com
//
//    All Rights Reserved
//
//    This program is an unpublished work protected by the Copyright Act
//    of the United States of America. It contains proprietary information
//    and trade secrets which are the property of Total Resource 
//    Management (TRM) Incorporated. This work is submitted to the recipient
//    in confidence, the information contained herein may not be copied or
//    disclosed in whole or in part except as permitted by written agreement
//    signed by an officer of Project Software and Development Incorporated.
//
//    Decompilation or modification of this software is strictly prohibited.
//
//    No part of this work may be reproduced or used in any form or by
//    any means; graphic, electronic, or mechanical including
//    photocopying, recording, taping or information storage and retrieval
//    systems without the permission of Project Software and Development
//    Incorporated.
///

//trm.util.Util.js: This file contains the debug functionality and miscellaneous utilities
//  used by other modules.  

var trm;
if(!trm)
  trm = {};
if(!trm.util)
  trm.util = {};
if(!trm.util.Util)
  trm.util.Util = {};
if(!trm.maximo)
  trm.maximo = {};

// ******************************DEBUG FUNCTIONS*************************************************

if(!trm.debug)
  trm.debug = {}
trm.debug.ERROR = 0;
trm.debug.WARN = 2;
trm.debug.INFO = 4;
trm.debug.DEBUG = 6;
trm.debug.DEBUG2 = 8;
trm.debug.DEBUG3 = 10;

trm.debug.showErr = function() {
  //show the error string in a new window.
  var newWin = window.open('about:blank');
  if(isnull(newWin)) {
    //popup blocker may be enabled.
    alert("Pop-up blocker may be enabled in your browser!\n Turn it off and try again.");
    return;
  }
  newWin.document.write(trm.debug.errStr);
}

trm.debug.setLevel = function(level) {
  trm.debug.level = level;
}

trm.trace = function(msg) {
  if(trm.debug.level >= trm.debug.INFO) {
    console.log(msg);
  }
}

trm.info = trm.trace;

trm.error = function(msg) {
  if(trm.debug.level >= trm.debug.ERROR) {
    console.error(msg);
  }
}

trm.debug.show = function() {
}

trm.debug.hide = function() {
}

trm.warn = trm.error;

/**
 * An observer pattern for notifications
 */
trm.Notifier = function (){
  this.observers = [];

  /**
   * Add an observer notified on event
   */
  this.addObserver = function (obs){
    this.observers.push(obs);
  }
  
  /**
   * Removes observer from being notified
   */
  this.removeObserver = function (obs){
    this.observers = this.observers.filter(function(o){return o !== obs});
  }
  
  /**
   * Notifies all observers calling the method with the spefied data name(this, data)
   */
  this.notifyObservers = function (name, data){
    this.observers.forEach(function(o){
      o[name](this, data);
    });
  }
}

// ******************************MISC FUNCTIONS*************************************************

function isnull(p) {
  var isnull = false;
  switch(typeof (p)) {
    case "undefined":
      isnull = true;
      break;
    case "null":
      isnull = true;
      break;
    case "object":
      if(p == null)
        isnull = true;
      break;
    case "number":
      if(null == p)
        isnull = true;
      break;
    case "string":
      if("" == p)
        isnull = true;
      if("null" == p)
        isnull = true;
      if("undefined" == p)
        isnull = true;
      break;
  }
  if(isnull == false) {
    if(p.isnull == true)
      isnull = true;
  }
  return isnull;
}

trm.util.Util.getTarget = function(evt) {
  //get the target, the event fired on.
  var target = evt.target;
  if(isnull(target)) {
    //IE
    target = evt.srcElement;
  }
  return target;
}

trm.util.Util.fireEvent = function(evtName /* keyup */, target, value) {
  if(top.document.createEventObject) { //IE
    var keyupevt = top.document.createEventObject();
    keyupevt.keyCode = value;
    target.fireEvent('on' + evtName, keyupevt);
  } else { //firefox
    // change this for 7!! Intentionally putting a syntax error here so it bombs.
    var keyupevt = indow.document.createEvent("MouseEvent");
    clickEvent.initEvent("click", false, true);
    target.dispatchEvent(clickEvent);
  }
}

trm.util.Util.addAttr = function(url, attrName, attrValue) {
  if(url.length <= 0)
    return;
  if(isnull(attrName) || isnull(attrValue))
    return url;

  var lastChar = url.charAt(url.length - 1);
  var newUrl = url;

  // if this is not the first attribute, add an &
  if(lastChar != '?' && lastChar != '&')
    newUrl += '&';
  return newUrl + attrName + "=" + attrValue;
}

trm.util.Util.setGlobalParams = function(newRootPath, newUISessionId) {
  if(!top.document.trm)
    top.document.trm = {};
  top.document.trm.rootPath = newRootPath;
  top.document.trm.uisessionid = newUISessionId;
}

trm.util.Util.getControl = function(target) {
  //if you have main_grid5_6_textbox as the input box, 
  //traverse up to get its main_grid5_6 object.
  // TODO make this work with firefox. arbitary attribute "control" is not readable by firefox.
  var targetParam = target;
  while(!isnull(target) && target.control != "true") {
    target = target.parentNode;
  }
  if(isnull(target))
    return targetParam;
  return target;
}

trm.util.Util.XMLHttpRequest = function() {
  //wrapper around the XMLHttpRequest object.
  this.processResponseText = function(responseText) {
    this.responseText = responseText;
    this.notifier.notifyObservers("processResponseText", responseText);
  }

  this.processResponseXML = function(responseXML) {
    this.responseXML = responseXML;
    this.notifier.notifyObservers("processResponseXML", responseXML);
  }

  this.addObserver = function(observer) {
    this.notifier.addObserver(observer);
  }
  this.removeObserver = function(observer) {
    this.notifier.removeObserver(observer);
  }

  this.constructor = function() {
    var xmlHttp;
    var me = this;
    
    // this IS AJAX: this is the mechanism for asynch. sending and parsing data. 
    // fix 1538: using much newer code for ajax. appears to be much faster
    if(window.XMLHttpRequest){
      xmlHttp = new XMLHttpRequest();
    }
    else if(window.ActiveXObject){
      xmlHttp = new ActiveXObject('MSXML2.XMLHTTP.3.0');
    }else{
      trm.error('Browser does not support ajax!');
      return false;
    }

    xmlHttp.onreadystatechange = function() {
      if(xmlHttp.readyState == 4) {
        me.processResponseText(xmlHttp.responseText);
        me.processResponseXML(xmlHttp.responseXML);
      }
    }
    return xmlHttp;
  }

  this.requestData = function(requestUrl) {
    this.xmlHttp = this.constructor();
    this.xmlHttp.open("GET", requestUrl, true /* asynchronously */);
    this.xmlHttp.send(null);
  }

  //data
  this.xmlHttp = this.constructor();
  this.notifier = new trm.Notifier();
  this.responseText;
  this.responseXML;

}//XMLHttpRequest

function moveObj(txtBoxPos, widgetToMove) {
  if(txtBoxPos.length < 2) {
    trm.warn("moveObj: txtBoxPos INVALID length: " + txtBoxPos.length);
    return;
  }
  var left = txtBoxPos[0];
  var top = txtBoxPos[1];

  widgetToMove.style.position = 'absolute';
  widgetToMove.style.left = (left) + "px";
  widgetToMove.style.top = (top) + "px";
  // obj.style.display = "block";
}

function findPos(obj) {
  var curleft = curtop = 0;
  if(obj.offsetParent) {
    do {
      curleft += obj.offsetLeft;
      curtop += obj.offsetTop;
    } while(obj = obj.offsetParent);
  }
  return [ curleft, curtop ];
}

// Jun 5, 2008 SN: Bug# 979. Speed up DisplaySetting rule.
// The main culprit is getElementById(). Added a method
// to look for a child with a given id. This makes it
// faster since typically we have the parent control and
// want to look for its <id>_textbox control or somthing like that
// so we have to typically traverse very few levels.
trm.util.Util.getChildMatchingFn = function(parent, recurseLevel, fn) {
  //do a breadth first search of
  // the parent's children and find the child of the given id.

  // by default recurse the parent entirely.
  if(isnull(recurseLevel))
    recurseLevel = 25; // more than sufficient.

  var queue = new Array();
  queue.push(parent);
  var level = 0;
  while(queue.length > 0 && level < recurseLevel) {
    //while there is something to process.

    // get the first element in queue.
    var currParent = queue.shift();

    // Sep 17, 2008 SN: Bug# 1128. CSU required text fields without labels
    // highlight required doesnt work.
    // if this parent has no children, it should continue to process the
    // remaining queue, not quit right away.
    var children = currParent.childNodes;
    if(isnull(children) || (children.length <= 0))
      continue;

    // there are children.
    for( var i = 0; i < children.length; i++) {
      var currChild = children[i];

      if(fn.isMatch(currChild)) {
        //      if(currChild.id == childId) {
        return currChild;
      }

      //push it into the queue and continue
      queue.push(currChild);
    }

    level++;

    // if(level > 10) {
    // trm.warn("getChild: level unusually high! " + level);
    // }
  }//while  
}

trm.util.Util.getChildWithTagName = function(parent, childTagName, recurseLevel, occurence) {
  /**
   * childTagName: return the child matching the given tag.
   * recurseLevel:  
   * occurence   : = 2 => get the second occurence of the given tag.
   */

  function fn(childTagName, occurence) {
    this.childTagName = childTagName;
    this.occurence = occurence || 1; // if no occurence is specified, return first occurence.
    this.isMatch = function(currChild) {
      if(currChild.tagName == this.childTagName)
        this.occurence--;
      return this.occurence == 0;
    }
  }
  return trm.util.Util.getChildMatchingFn(parent, recurseLevel, new fn(childTagName, occurence));
}

trm.util.Util.getChild = function(parent, childId, recurseLevel) {
  function fn(childId) {
    this.childId = childId;
    this.isMatch = function(currChild) {
      return currChild.id == this.childId;
    }
  }
  return trm.util.Util.getChildMatchingFn(parent, recurseLevel, new fn(childId));
}

trm.util.Util.dump = function(collection) {
  //recursively dump any state stored in a
  // collection map.
  var str = "";
  var queue = new Array();
  queue.push(collection);
  var prefix = "--";
  var count = 5;
  while(queue.length > 0 && count > 0) {
    var current = queue.pop();
    if(typeof (current) == "object") {
      //that itself is a collection.
      for(name in current) {
        var val = current[name];
        str += prefix + " " + name + "=" + val + "\n";
        queue.push(val);
      } //for name in current    
    } //if current.length
    // else it is not a collection and its value would have been printed
    // in the previous pass.
    prefix += "--";
    count--;
  } //while queue.length > 0
  alert(str);
}

trm.util.Util.dumpTrm = function() {
  trm.util.Util.dump(top.document.trm);
}

String.prototype.trim = function() {
  return this.replace(/^\s+|\s+$/g, '');
}

trm.toString = function(obj) {
  var str = "";
  if(typeof(obj) != "object") return "" + obj;
  
  for(key in obj) {
    if(typeof(obj[key]) != "function") {
      if(str != "")
        str += ","
      str  += '"'  + key + '":' +   obj[key];
    }  
  }
  return str;
}

trm.size = function(obj) {
  var len = obj.length ? obj.length : 0;
  for( var key in obj) {
    if(typeof (obj[key]) != "function") {
      len++;
    }
  }
  return len;
}

trm.maximo.isVersion = function(version) {
  if(!trm.maximo.version)
    trm.maximo.version = 6;

  // for now we can have only versions 6 or 7.
  // in future 7.1 etc will be both versions 7 and 7.1!
  return trm.maximo.version == version;
}

trm.maximo.playSound = function (sound) {
  var url = sound;
  // relative...fix it up
  if(!url.match(/^http[s]?[:].*/)){
    url = MAXRCURL + sound; //get the wav file url
  }
  var isIE = /* @cc_on!@ */false || !!document.documentMode;  //check to see if it's IE
  var soundid = "rm_sound_" + sound.split("-").join('_'); //declare an ID for the tag we're creating
  require([ "dojo/domReady!", "dojo/dom", "dojo/dom-construct", "dojo/fx" ], function(dom, domConstruct) {
    if (!isIE) {  //if it's not ie, add an audio tag and play it
      if (!dojo.byId(soundid)) {
        var body = dojo.body();
        var n = dojo.create("audio", {
          id : soundid,
          innerHTML : "",
          type : "audio/wav",
          src : url,
          autostart : false
        }, body);
      }
      var thissound = dojo.byId(soundid);
      thissound.play();
    } else { //if it is ie, add a bgsound tag and play it
      if (!dojo.byId(soundid)) {
        var body = dojo.body();
        var n = dojo.create("bgsound", {
          id : soundid
        }, body);
      }
      var thissound = dojo.byId(soundid);
      thissound.src = url;
    }
  });
}


// trm.debug.setLevel(trm.debug.DEBUG3);
trm.debug.setLevel(-1); // turn debugging off.

// comment this out if you don't want smartbrowser.
trm.smartbrowser = 'enabled';

trm.maximo.version = 7;
