///    Copyright (c)  2002-2019
//
//    Total Resource Management (TRM)
//    5695 King Centre Dr
//    Alexandria, VA 22315
//    703.548.4285
//    www.trmnet.com
//
//    All Rights Reserved
//
//    This program is an unpublished work protected by the Copyright Act
//    of the United States of America. It contains proprietary information
//    and trade secrets which are the property of Total Resource 
//    Management (TRM) Incorporated. This work is submitted to the recipient
//    in confidence, the information contained herein may not be copied or
//    disclosed in whole or in part except as permitted by written agreement
//    signed by an officer of Project Software and Development Incorporated.
//
//    Decompilation or modification of this software is strictly prohibited.
//
//    No part of this work may be reproduced or used in any form or by
//    any means; graphic, electronic, or mechanical including
//    photocopying, recording, taping or information storage and retrieval
//    systems without the permission of Project Software and Development
//    Incorporated.
///

var trm;
if(!trm)
  trm = {};
if(!trm.inputdevice)
  trm.inputdevice = {};

/**
 * Get the trm.inputdevice.Controller instance for the passed document. In chrome o will be a doc. In I.E its a window
 */
trm.inputdevice.getController = function(o){
  if(!o){
    return {};
  }
  if(o == window){
    return o.document.trm.inputdevice.Controller;
  }
  if(!o.trm || !o.trm.inputdevice){
    return {};
  }
  return o.trm.inputdevice.Controller;
}

trm.inputdevice.Controller = function(doc) {
  this.MODE_DEFAULT = 0;
  this.MODE_TAB = 1;
  this.MODE_SHIFT_TAB = 2;
  this.mode = this.MODE_DEFAULT;
  
  this.cancelEvent = function(evt) {
    evt.cancelBubble = true;
    evt.returnValue = false;
    if(evt.preventDefault)
      evt.preventDefault();
    if(evt.stopPropagation)
      evt.stopPropagation();
    return false;
  }
  
  /**
   * 
   */
  this.getRefocusId = function() {
    var focusId = getFocusId();
    if(!isnull(focusId) && !isnull(FIELDS)) {
      return FIELDS.nextFocusId(this, focusId);
    }  
  } //getRefocusId
  
  this.refocus = function(currentevt,id) {
    //cancel maximo's tab order and
    //refocus based on our rules.
    if(currentevt)
      this.cancelEvent(currentevt);
    if(id.match(/_iframe/)){
      var x = STORAGE.getElement(id);
      if(x){
        if(x.contentDocument){
          trm.enableTRMFocusOrder(x.contentDocument);
          focusElement(x.contentDocument.body.firstChild);
          return;
        }
        else if(x.contentWindow){
          trm.enableTRMFocusOrder(x.contentWindow.document);
          focusElement(x.contentWindow.document.body.firstChild);
          return;
        }
      }
    }
    focusItemNow(id);  
  }//refocus
  
  this.getAsc = function(evt) {
    return(evt.keyCode ? evt.keyCode : (evt.which ? evt.which : evt.charCode));
  }

  this.mouseDownHdlr = function(evt) {
    trm.inputdevice.getController(this).mode = this.MODE_DEFAULT;
  }
  
  //TODO: improve this handler to handle generic sequence of characters.
  this.keyDownHdlr = function(evt) {
    var inputdevice = trm.inputdevice.getController(this);
    var asc = inputdevice.getAsc(evt);

    if(asc == 9) {
      //tab and shift tab changes the mode of the controller.
      if(evt.shiftKey == true) {
        inputdevice.mode = inputdevice.MODE_SHIFT_TAB;        
        
      } else {
        inputdevice.mode = inputdevice.MODE_TAB;
      }
      
      //bug# 1430. Need to be able to control the tab ordering in a maximo app.
      //Now tab ordering works in firefox and chrome as well.
      //Changing how the tabordering fires. 
      //Now this is the only place taborder is checked.
      //when user presses tab or shift-tab
      var refocusId = inputdevice.getRefocusId();
        
      // hidden control
      var i = 0;
      while(!isnull(refocusId) && FIELDS.isHidden(refocusId) && i++ < 100){
        // fix 2444: changed from inputdevice.getRefocusid() (wasn't able to give that control focus)
        refocusId = FIELDS.nextFocusId(inputdevice,refocusId);
      }

      if(!isnull(refocusId)){
        // refocus to the specified control id
        inputdevice.refocus(evt,refocusId);

        // just log issue for now?
        // FIELDS.isHidden could have failed
        var test = getFocusId();
        if(test != refocusId){
          console.log('Re-focus failed '+test+' has focus instead of ',STORAGE.getElement(refocusId))
        }
      }
    } else {
      inputdevice.mode = inputdevice.MODE_DEFAULT;
    }  
  }//hdlr:fn()      

  this.addHdlr = function(obj, evtName, evtHdlr) {
    if(obj.addEventListener) {
      //firefox/IE
      obj.addEventListener(evtName, evtHdlr, false/*usecapture*/);
      return true;
    } else {
      if(obj.attachEvent) {
        //IE
        var e = obj.attachEvent("on" + evtName, evtHdlr);
        return e;
      } else {
        alert("Handler could not be attached.");
      }
    }
  }

  this.init = function(doc) {
    this.addHdlr(doc, 'keydown', this.keyDownHdlr);
    this.addHdlr(doc, 'mousedown', this.mouseDownHdlr);
    return true;
  }

  this.dummy = this.init(doc);
} //Controller

trm.enableTRMFocusOrder = function(doc){
  if(!doc.trm){
    doc.trm = {};
  }
  if(!doc.trm.inputdevice){
    doc.trm.inputdevice = {};
  }
  if(!doc.trm.inputdevice.Controller) {
    doc.trm.inputdevice.Controller = new trm.inputdevice.Controller(doc);
  }  
}

//enable/disable the smartbrowser feature.
if(trm.smartbrowser == 'enabled') {
  trm.enableTRMFocusOrder(top.document);
}
