/**
 * Utility for configuring the ACE miniapp
 */
var ACEMA = {};

/**
 * @param Deferred
 * @param instance
 * @returns Promise
 */
ACEMA.loadBeautify = function (Deferred, instance) {
  console.log("Loading beautify")
  var retval = new Deferred();
  instance.loadLibrary(function() {
    return window.js_beautify !== undefined
  }, instance.rootUrl + "/libraries/beautify/beautify.js", retval.resolve.bind(deferred));
  return retval.promise;
}

/**
 * 
 * @param Deferred
 * @param instance
 * @returns Promise
 */
ACEMA.loadVim = function (Deferred, instance) {
  console.log("Loading vim")
  var retval = new Deferred();
  instance.loadLibrary(function() {
    return window.ace !== undefined && window.ace.require('ace/keyboard/vim') !== undefined
  }, instance.rootUrl + "/libraries/ace/keybinding-vim.js", retval.resolve.bind(deferred));
  return retval.promise;
}

/**
 * 
 * @param when
 * @param Deferred
 * @param instance
 * @param editor
 * @returns
 */
ACEMA.loadJSFormatter = function (when, Deferred, instance, editor) {
  console.log("loading js formatter")
  var retval = new Deferred();
  // make sure beautify is loaded
  when(ACEMA.loadBeautify(Deferred, instance), function() {
    var tm = instance.editor.session.getMode();
    // not js
    if (!tm || !tm.$id || !tm.$id.indexOf || tm.$id.indexOf('javascript') < 0) {
      retval.resolve(false);
      return;
    }
    console.log("beautify loaded");
    instance._formatter = function(v) {
      return window.js_beautify(v, {
        "indent_size": 2,
        "preserve-newlines": true
      });
    }
    retval.resolve(true);
  });
  return retval.promise;
}

/**
 * 
 * Configures Vi mode for ace editor. This will save the win keyboard handler default to instance._winkh member for later reset if nec
 * 
 * @param when
 * @param Deferred
 * @param instance
 * @param editor
 * @returns Promise
 */
ACEMA.configureVIM = function (when, Deferred, instance, editor) {
  console.log("toggling vi mode")
  var retval = new Deferred();
  // make sure vim is loaded
  when(ACEMA.loadVim(Deferred, instance), function(success) {
    console.log("vim loaded ", success);

    if (instance._winkh === undefined) {
      instance._winkh = editor.getKeyboardHandler();
    }

    if (instance.vim) {
      // set save command to :w (this assumes save command was created)
      if (!instance._exDefined) {
        var api = window.ace.require('ace/keyboard/vim').CodeMirror.Vim;
        api.defineEx('write', 'w', function(cm, input) {
          instance.updateSource();
          // takes 200 to update source
          if (sendClick !== undefined && saveButton !== undefined) {
            setTimeout(function() {
              sendClick(saveButton);
            }, 500);
          }
        });
        instance._exDefined = true;
      }

      instance.editor.setKeyboardHandler("ace/keyboard/vim");
    } else {
      instance.editor.setKeyboardHandler(instance._winkh);
    }
    retval.resolve(true);
  });
  return retval.promise;
}


ACEMA.getCompletions = function (editor, session, pos, prefix, callback) {
    console.log("get completions",this);
    var line = session.getLine(pos.row);
    this.fetch("getcompletions",{'a1':{'prefix':prefix, 'line':line, 'column':pos.column}}).then(function(completions){
        console.log("got completions", completions);
        callback(null, completions);
    });
}

/**
 * Add the Maximo snippets
 */
ACEMA.initSnippets = function (instance, editor){
  var snippetManager = window.ace.require("ace/snippets").snippetManager;
  if(snippetManager.autoscripts){
    console.log("Unregistering snippets", snippetManager.autoscripts);
    snippetManager.unregister(snippetManager.autoscripts, "javascript");
    snippetManager.unregister(snippetManager.autoscripts, "python");
    delete snippetManager.autoscripts;
  }

  // see https://cloud9-sdk.readme.io/docs/snippets for details on formatting
  
  instance.fetch("getsnippets",{}).then(function(snippets){
    console.log("registering snippets ", snippets);
    // register to existing snippets
    snippetManager.register(snippets, "javascript");    
    snippetManager.register(snippets, "python");    
    snippetManager.autoscripts = snippets;
  });

}

/**
 * Add Maximo completion variables
 */
ACEMA.initContentAssist = function (when, Deferred, instance, editor){
  var contentAssist = window.ace.require('ace/ext/language_tools');
  
  editor.setOptions({
    enableBasicAutocompletion: true,
    enableSnippets: true,
    enableLiveAutocompletion: false
  });
  
  contentAssist.addCompleter({
    'getCompletions': ACEMA.getCompletions.bind(instance)
  });    
}

/**
 * 
 * @param instance
 * @param editor
 */
ACEMA.initEditor = function (when, Deferred, instance, editor) {
  console.log("loading trm ace updates")
  // load vi mode and enable if instance.vim
  ACEMA.configureVIM(when, Deferred, instance, editor);
  
  // add trm snippets
  ACEMA.initSnippets(instance, editor);
  editor.on("focus", function(){ACEMA.initSnippets(instance, editor)});
  
  // add trm completions
  ACEMA.initContentAssist(when, Deferred, instance, editor);
  
  ACEMA.loadJSFormatter(when, Deferred, instance, editor);
  editor.commands.addCommand({
    name: 'format',
    bindKey: {
      win: 'Ctrl-Shift-F',
      mac: 'Command-Shift-F',
      sender: 'editor|cli'
    },
    exec: function(env, args, request) {
      if (instance._formatter) {
        var _formatter = instance._formatter;
        // remember cursor loc
        var pos = editor.getCursorPosition();

        // format a specific selection
        var range = editor.getSelectionRange();
        if (range.start.row != range.end.row || range.start.column != range.end.column) {
          var selectedtext = editor.getSession().getDocument().getTextRange(range);
          editor.getSession().getDocument().replace(range, _formatter(selectedtext, env, args, request));
          return;
        }

        // format whole thing
        editor.setValue(_formatter(editor.getValue(), env, args, request));
        editor.moveCursorToPosition(pos);
        editor.clearSelection();
      }
    }.bind(this)
  });
}

/**
 * Find the AceEditor miniapp instance
 * @return Promise resolves to the miniapp instance or false if not found
 */
ACEMA.findAceMA = function (Deferred) {
  var _checkcount = 0;

  /**
   * Quick method to keep checking for several seconds if miniapp is loaded
   */
  var _check = function(deferred) {
    if (_checkcount > 5) {
      deferred.resolve(false);
      return;
    }
    window.setTimeout(
      function() {
        if (window.miniapps) {
          if (window.miniapps.aceeditor && window.miniapps.aceeditor.instances) {
            var aceMA = window.miniapps.aceeditor.instances;
            if (Object.keys(aceMA).length) {
              deferred.resolve(aceMA[Object.keys(aceMA)[0]]);
              return;
            }
          }
        }
        _checkcount++;
        _check(deferred);
      }, 500);
    return deferred.promise;
  }

  var retval = new Deferred();
  _check(retval);
  return retval.promise;
}

/**
 * @param isVim true only to enable VI mode for this user
 */
ACEMA.loadAceEnhancements = function (isVim) {
  require(['dojo/when', 'dojo/Deferred'], function(when, Deferred) {
    when(ACEMA.findAceMA(Deferred), function(instance) {
      if (!instance || !instance.editor) {
        console.log("Ace Enhancements failed. Unable to locate miniapp.");
        return;
      }
      // prevent doing this everytime the control re-renders
      if (instance._loaded) {
        return;
      }
      instance._loaded = true;
      console.log('FOUND EDITOR', instance.editor);
      instance.vim = isVim === true;
      ACEMA.initEditor(when, Deferred, instance, instance.editor);
    });
  });
}

/**
 * 
 */
ACEMA.toggleVIM = function () {
  require(['dojo/when', 'dojo/Deferred'], function(when, Deferred) {
    when(ACEMA.findAceMA(Deferred), function(instance) {
      if (!instance || !instance.editor) {
        console.log("Toggle VIM failed. No instance found", instance)
        return;
      }
      instance.vim = !instance.vim;
      ACEMA.configureVIM(when, Deferred, instance, instance.editor);
      console.log("VIM toggled", instance.vim);
    });
  });
}
