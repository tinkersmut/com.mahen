/**    Copyright (c)  2002-2019
//
//    Total Resource Management (TRM)
//    5695 King Centre Dr
//    Alexandria, VA 22315
//    703.548.4285
//    www.trmnet.com
//
//    All Rights Reserved
//
//    This program is an unpublished work protected by the Copyright Act
//    of the United States of America. It contains proprietary information
//    and trade secrets which are the property of Total Resource 
//    Management (TRM) Incorporated. This work is submitted to the recipient
//    in confidence, the information contained herein may not be copied or
//    disclosed in whole or in part except as permitted by written agreement
//    signed by an officer of Project Software and Development Incorporated.
//
//    Decompilation or modification of this software is strictly prohibited.
//
//    No part of this work may be reproduced or used in any form or by
//    any means; graphic, electronic, or mechanical including
//    photocopying, recording, taping or information storage and retrieval
//    systems without the permission of Project Software and Development
//    Incorporated.
*/

/**
 * Utilities for analyzing the DOM
 */
var DOM = {};
/**
 * Common functionality for fields
 */
var FIELDS = {};
/**
 * Utility for storing data. This storage is temporary for the context of an event.
 */
var STORAGE = {};
/**
 * Common functionality for filter fields
 */
FIELDS.FILTERS = {};
/**
 * A sorted array of id's
 */
FIELDS.FOCUSORDER = new Array();
/**
 * Iterates all elements with an RMSTYLE and converts the RM css styles to usable style attributes
 */
DOM.replaceRMSTYLES = function(){
  // our marker
  var elements = getElementsByClassName('RMSTYLE', 'INPUT');
  elements = elements.concat(getElementsByClassName('RMSTYLE', 'LABEL'));
  // amahen: for table de2
  elements = elements.concat(getElementsByClassName('RMSTYLE', 'TR'));
  // cell child controls should have these
  elements = elements.concat(getElementsByClassName('RMSTYLE', 'TD'));
  // fix 3912: cell text
  elements = elements.concat(getElementsByClassName('RMSTYLE', 'SPAN'));
  
  var rexp = new RegExp("(^|\\s)RM\\w+[_][^\\s]+","gm");
  for(var i = 0; i < elements.length; i++){
    var matches = elements[i].className.match(rexp);
    DOM.addRMStyles(elements[i], matches);
  }
}
/**
 * 3668-style wasn't being reset after leaving the field in highlight selected
 * 
 * @param element HTML Element
 */
DOM.replaceElementRMSTYLES = function(element){
	  // our marker
	  var rexp = new RegExp("(^|\\s)RM\\w+[_][^\\s]+","gm");
	    var matches = element.className.match(rexp);
	    if (matches != null && matches.length > 0) {
	      DOM.addRMStyles(element, matches);
	    }
	}

/**
 * Helper method to pull the name and value out of an RMSTYLE css class and turn it into a usable style attribute
 * 
 * @param element HTML element
 * @param matches Array of Strings
 */
DOM.addRMStyles = function(element, matches){
  var namerexp = new RegExp("\\s*RM(\\w+)[_].+");
  var valuerexp = new RegExp("\\s*RM\\w+[_](.+)");
  
  for(var i = 0; i < matches.length; i++){
    // parse class to usable style
    var stylename = matches[i].replace(namerexp, "$1");
    var value = matches[i].replace(valuerexp, "$1");

    // did not parse a stylename or value
    if(stylename == matches[i] || value == matches[i]){
      continue;
    }
    // fix 3717: only for input tags
    if(stylename[0] === 'I'){
      stylename = stylename.substr(1);
      // skip...style only for inputs
      if(element.tagName !== 'INPUT'){
        continue;
      }
    }
    
    // fix 2950
    if(stylename.toLowerCase().indexOf('color') > -1 && value && value.length == 6 && value.match(/^[a-fA-F0-9]+/)){
      value = '#'+value;
    }
    // fix 3859
    if(value && value[0] === '-' && value.replace(/^\-/,'') == element.style[stylename]){
      // replace camel case...do here not in remove style or we break DOM.removeBGC method
      stylename= stylename.replace(/([A-Z])/g,'-$1').toLowerCase();
      DOM.removeStyle(element, stylename);
    }
    // add style
    else{
      //3657-make important, ensure there's a px
      var priority=undefined;
      if (stylename == "fontSize") {
        value = isNaN(value) ? value : (value + "px");
        priority = 'important';
      }
      DOM.addStyle(element, stylename, value, priority);
    }
  }
}

/**
 * @return id of this element. undefined if there is no id
 */
DOM.getElementId = function(element){
  if(!element){
    return;
  }
  
  if(DOM.verticallabels && !element.id){
    var temp = DOM.getVerticalLabel(element);
    if(temp)
      element.id = temp.id + '_rm';
  }
  
  return element.id;
}

/**
 * Helper method to get the Input element associated with the required image
 */
DOM.getInputElement = function(element){
  
  if(!element){
    return null;
  }
  
  if(element.tagName == 'INPUT'){
    return element;
  }
  
  // get the first input we can find
  var retval = DOM.getComponent(element, 'textbox');
  if(!retval && FIELDS.isVerticalLabelRow(element)){
    element = DOM.getNextSibling(element);
    if(element){
      retval = DOM.getComponent(element, 'textbox');
    }
  }
  return retval;
}

/**
 * @param parent
 * @returns the first child ELEMENT of the passed argument
 */
DOM.getFirstChild = function(parent){
  if(!parent){
    return;
  }
  for(var i =0; i < parent.childNodes.length; i++){
    // type element (type 3 is text)...children is not supported by w3c
    if(parent.childNodes[i].nodeType == 1){
      return parent.childNodes[i];
    }
  }
}

/**
 * Get the previous sibling that is NOT a text node
 */
DOM.getPreviousSibling = function (sibling){
  if(!sibling){
    return;
  }
  for(var prev = sibling.previousSibling;prev; prev = prev.previousSibling){
    if(prev.nodeType == 1){
      return prev;
    }
  }
  return prev;
}

/**
 * Get the next sibling that is NOT a text node. Undefined if there is not one
 */
DOM.getNextSibling = function (sibling){
  if(!sibling){
    return;
  }
  for(var next = sibling.nextSibling;next;next = next.nextSibling){
    if(next.nodeType == 1){
      return next;
    }
  }
}

/**
 * Helper method
 * @return A tag that matches the specified name. NULL if not found
 */
DOM._getToolbarButton = function(toolbar, name) {
  var images = toolbar.getElementsByTagName('A');
  for ( var i = 0; i < images.length; i++) {
    if (images[i].eventtype == name) {
      return images[i];
    }
  }

}

/**
 * 
 */
DOM.getToolbarButton = function(name) {
  var toolbars = getElementsByClassName('toolbar');
  if (!toolbars) {
    return;
  }
  for ( var j = 0; j < toolbars.length; j++) {
    var button = MA._getToolbarButton(toolbars[j], name);
    if (button) {
      return button;
    }
  }
}

/**
 * 
 */
DOM.hideToolbarButton = function(name){
  var button = DOM.getToolbarButton(name);
  if(button){
    var td = button.parentNode.parentNode;
    td.parentNode.removeChild(td);
    STORAGE.setPersistent(name, td);
  }
}

/**
 * Get the TABLE element directly above the filter input
 */
DOM.getTableForFilter = function(element){
  // amahen: the tr for this is 14 parents above the actual input...shrink it down
  var a = getElementsByClassName('fld','TD',element);
  if(a && a.length > 0){
    // this will be the TABLE element
    element = a[0].parentNode.parentNode.parentNode;
  }
  return element;
}

/**
 * @param input
 *          MUST be the INPUT element
 * @return TABLE element for the passed in input element
 * @throws Exception
 *           when not a valid element
 */
DOM.getTableForInput = function(input){
  if(!input || input.tagName != 'INPUT'){
    throw 'Invalid element';
  }
  var i = 0 ;
  while(i < 10 && input && input.tagName != 'TABLE'){
    input = input.parentNode;
    i++;
  }
  if(input.tagName != 'TABLE'){
    throw 'Input element not connected to document';
  }
  return input;
}

/**
 * Static function to retrieve the label/textbox/container of a specified control
 * 
 * @param element
 *          the control or control container (usually the TR but can be the INPUT etc)
 * @param component
 *          the name of the component to find (label, textbox, desc, container)
 * @returns Element representing the specified component
 */
DOM.getComponent = function(element, component){
  if(!element) {
    trm.error('Element was never associated with ChgStyle object');
    return;
  }
  
  // its a filter control
  if(element.isfilter){
    element = DOM.getTableForFilter(element);
  } 
  
  var occurence;
  switch(component.toLowerCase()) {
    case "link":
      if(element.tagName == 'A'){
        return element;
      }
      return trm.util.Util.getChildWithTagName(element, 'A', 20, 1);
    case "label":
      if(element.tagName == 'LABEL' || element.tagName == 'A'){
        return element;
      }
      // fix 2117...fixed
      if(FIELDS.isVerticalLabelRow(element) && DOM.getPreviousSibling(element)){
        element = DOM.getPreviousSibling(element);
      }
      // TODO: change this to use getElementByClassName('label')
      return trm.util.Util.getChildWithTagName(element, 'LABEL', 20, 1);
    case "textbox":
      // fix 1636: make longdesc/multiline textboxes style editable
      if('INPUT' == element.tagName || 'TEXTAREA' == element.tagName){
        return element;
      }
      if(element.tagName == 'IFRAME'){
        var doc = element.contentDocument;
        if(!doc && element.contentWindow){
          doc = element.contentWindow.document;
        }
        if(doc && doc.body){
          return doc.body.firstChild;
        }
      }
      occurence = 1;
      // intentional fall thru
    case "desc":
      if(!occurence)
        occurence = 2;
      var retval = trm.util.Util.getChildWithTagName(element, 'INPUT', 20, occurence);
      if(retval && retval.className != 'dijitOffScreen'){
        return retval;
      }
      retval = trm.util.Util.getChildWithTagName(element, 'TEXTAREA', 20, occurence);
      if(!retval && occurence == 1){
        retval = trm.util.Util.getChildWithTagName(element, 'IFRAME', 20, 1);
      }
      return retval;
    case "container":
      return element;
    default:
      return trm.util.Util.getChildWithTagName(element, component.toUpperCase(), 20, 1);
        
  }
  trm.error("Failed to get element for type " + component);
}

/**
 * @return html element that represents the container of this control (TABLE or TR)
 */
DOM.getControlElement = function(el){
  var retval = el;
  while(!FIELDS.isControl(retval)){
    
    retval = retval.parentNode;
  }
  return retval;
}

/**
 * @return TR for label if vertical labels is enabled and this is the TR of an input (with no id)
 */
DOM.getVerticalLabel = function(el){
  if(!DOM.verticallabels)
    return undefined;
  var sib = DOM.getPreviousSibling(el);
  if(!sib){
    return undefined;
  }
  if(sib.getAttribute && sib.getAttribute("control") == "true"){
    return sib;
  }
}

/**
 * Removes background color before style is changed dynamically
 */
DOM.appendClass = function(parent, clazz){
  if('trh' == clazz){
    DOM.removeBGC(parent);
  }
  window._appendClass(parent, clazz);
}

/**
 * Reapplys background color before style is changed dynamically
 */
DOM.removeClass = function(parent, clazz){
  if(window._removeClass){
    window._removeClass(parent, clazz);
  }
  // fix 2602
  else{
    removeClass(parent, clazz);
  }

  // apply trm styles
  if('trh' == clazz){

    // apply de1 styls
    var q = FIELDS.getStyleQ(parent);
    if(q){
      q.applyQueuedStyles();
    }

    // apply de2 styles
    DOM.replaceElementRMSTYLES(parent);
  }
}

/**
 * Sets the specified style for the element
 */
DOM.addStyle = function(element, stylename, value, priority){
  // reduce camelcase
  stylename = stylename.replace(/([A-Z])/g,'-$1').toLowerCase();
  if(element.style.setProperty){
    if(priority === undefined){
      element.style.setProperty(stylename, value);
    }
    else{
      element.style.setProperty(stylename, value, priority);
    }
  }
  else if(element.style.setAttribute){
    element.style.setAttribute(stylename, value);
  }
}

/**
 * Removes the specified style from the element
 */
DOM.removeStyle = function(element, stylename){
  if(element.style.removeProperty){
    element.style.removeProperty(stylename);
  }
  else if(element.style.removeAttribute){
    element.style.removeAttribute(stylename);
  }
}

/**
 * Removes the background color from the specified element
 */
DOM.removeBGC = function(element){
  DOM.removeStyle(element, 'backgroundColor');
  DOM.removeStyle(element, 'background-color');
}

/**
 * Get the parent with role='row'
 */
DOM.getRow = function(element){
  if(!element || !element.getAttribute){
    return element;
  }
  if(element.getAttribute('role') == 'row'){
    return element;
  }
  return DOM.getRow(element.parentNode);
}

/**
 * 
 */
DOM.readBoolean = function(value) {
  // returns the boolean value of "true", "false", true, false
  var retVal;
  if(value == "true" || value == true)
    retVal = true;
  else
    if(value == "false" || value == false)
      retVal = false;
  return retVal;
}

/**
 * Gets an array from the storage. If one doesn't exist for the specified key it is created. This is used to store temporary arrays until the STORAGE.clear()
 * method is called.
 * 
 * @param key
 *          unique id for the array
 * @returns Array
 */
STORAGE.getArray = function(key){
  if(!STORAGE.ARRAYS){
    STORAGE.ARRAYS = {};
  }
  if(!STORAGE.ARRAYS[key]){
    STORAGE.ARRAYS[key] = new Array();
  }
  return STORAGE.ARRAYS[key];
}

/**
 * Gets the element associated with the specified ID in the DOM. This will temporarily cache the element until the storage is cleared.
 * 
 * @param id
 *          of the element to retrieve
 * @returns Element associated in the DOM with the specified ID.
 */
STORAGE.getElement = function(id){
  if(!STORAGE.ELEMENTS){
    STORAGE.ELEMENTS = {};
  }
  if(!STORAGE.ELEMENTS[id]){
    STORAGE.ELEMENTS[id] = top.document.getElementById(id);
  }
  return STORAGE.ELEMENTS[id];
}

/**
 * Set Persistent data. Data will not be cleared by clear() method
 * 
 * @param key
 * @param value
 */
STORAGE.setPersistent = function(key, value){
  if(!STORAGE.PERSISTENT){
    STORAGE.PERSISTENT = {};
  }
  STORAGE.PERSISTENT[key] = value;
}

/**
 * Get the persentent data associated with the key
 * 
 * @param key
 * @returns Object stored under that persistent key
 */
STORAGE.getPersistent = function(key){
  if(STORAGE.PERSISTENT){
    return STORAGE.PERSISTENT[key];
  }
}

/**
 * Clears the temporary storage. This should be called when we are no longer sure that what is stored is valid (i.e we store elements but the elements may have
 * been removed from the document).
 */
STORAGE.clear = function(){
  STORAGE.ARRAYS = null;
  STORAGE.ELEMENTS = null;
}

/**
 * Clears any persistent data (things not cleared by clear)
 */
STORAGE.clearPersistent = function(){
  STORAGE.PERSISTENT = null;
}

/**
 * Sets the filter input fields defined by content.ids as required
 * 
 * @param content
 */
FIELDS.FILTERS.setRequired = function(content){
  var filterrowid = content.filterrowid;
  var ids = content.ids;
  
  // used as backup (not really nec)
  FIELDS.setRequiredStyle(content);
  
  if(!filterrowid || !ids){
    return;
  }
  
  var filterrow = STORAGE.getElement(filterrowid);
  if(!filterrow){
    return;
  }
  
  for( var i = 0; i < ids.length; i++) {
    FIELDS.FILTERS.setFilterFieldRequired(filterrow, STORAGE.getElement(ids[i]));
  }
}

/**
 * Sets the field in the filter row to required
 */
FIELDS.FILTERS.setFilterFieldRequired = function(filterrow, field){
  // sanity check
  if(!field){
    return;
  }
  
  // mark as filter for some of our conv. methods to find inputs etc easier
  field.isfilter = true;
  
  if(!filterrow._onkeyup){
    filterrow._onkeyup = filterrow.onkeyup;
    
    // amahen: i.e will not set a value for the event var unless we use attachEvent
    if(filterrow.attachEvent){
      // remove the old event or in i.e this will still cause a search
      // detach didn't seem to work so just set it to nothing
      filterrow.onkeyup = '';
      eval('filterrow.attachEvent("onkeyup",function(event){FIELDS.FILTERS.onkeyup(event, "'+filterrow.id+'");})');
    }
    // all other browsers don't have attachEvent
    else{
      eval('filterrow.onkeyup = function(event){FIELDS.FILTERS.onkeyup(event, "'+filterrow.id+'")};');
    }
  }
  if(!filterrow.requiredFilters){
    filterrow.requiredFilters = new Array();
  }
  
  var input = DOM.getComponent(field, 'textbox');
  if(input){
    filterrow.requiredFilters.push(input.id);
    input.isfilter = true;
    field.required = true;
    field.filterrowid = filterrow.id;
    FIELDS.addFilterControl(field);
  }
}

/**
 * 
 */
FIELDS.FILTERS.onkeyup = function(event, filterrowid){
  var filter = STORAGE.getElement(filterrowid);
  
  // sanity check
  if(!event || !filter){
    return;
  }
  
  // tabbing thru fields
  if(event.keyCode == KEYCODE_TAB || event.keyCode == KEYCODE_SHIFT){
    filter._onkeyup(event);
    return;
  }
  
  // about to filter rows...make sure required fields are filled
  for( var i = 0; i < filter.requiredFilters.length; i++) {
    var input = STORAGE.getElement(filter.requiredFilters[i]);
    if(isnull(input.value)){
        
      // prevent querying
      if(tableRowEnterKeyFlag==1 && event.keyCode==KEYCODE_ENTER){
        showMessage(2,"Required filter fields are empty");
        return;
      }
    }
  }
  
  filter._onkeyup(event);
}



/**
 * Gets the divs that surround each of the 'required' astrix images. We use these to determine fields(inputs) on the page
 */
FIELDS.getAllFields = function(){
  
  var retval = getElementsByClassName('fld');
  var chk = getElementsByClassName('checkbox');
  if(chk){
    retval.concat(chk);
  }
  return retval;
}

/**
 * Get the filter input elements if there are any with rules
 * 
 * @returns Array
 */
FIELDS.getFilterControls = function(){
  var inputids = STORAGE.filtercontrols;
  if(!inputids){
    return;
  }
  var retval = new Array(inputids.length);
  for(var i = 0; i < inputids.length; i++){
    retval[i] = STORAGE.getElement(inputids[i]);
  }
  return retval;
}

/**
 * Adds an HTMLInputElement to the filter control id array
 */
FIELDS.addFilterControl = function(element){
  var tempid = DOM.getElementId(element);
  if(!tempid){
    return;
  }
  var inputids = STORAGE.filtercontrols;
  if(!inputids){
    STORAGE.filtercontrols = (inputids = new Array());
  }
  if(!inputids[tempid]){
    inputids.push(tempid);
    inputids[tempid] = true;
  }
}

/**
 * @returns Array that maps element id's to their respective StyleQs
 */
FIELDS.getStyleQMap = function(){
  if(!STORAGE.styleMap){
    STORAGE.styleMap = new Array();
  }
  return STORAGE.styleMap;
}

/**
 * @param element
 *          Element to get the associated StyleQ of
 * @returns StyleQ if there is one associated with the element. NULL otherwise.
 */
FIELDS.getStyleQ = function(element){
  var tempid = DOM.getElementId(element);
  if(!tempid){
    trm.warn('Invalid element passed to getStyleQ '+element ? element.tagName : '(null element)');
    return;
  }
  var index =  FIELDS.getStyleQMap()[tempid];
  // Bug 1674: replace if(index) with better check
  if(!isnull(index)) {
    return FIELDS.getStyleQMap()[index];
  }
}

/**
 * @param element
 *          Element to associate styleQ with
 * @param styleQ
 *          StyleQ to associate with element
 */
FIELDS.addStyleQ = function(element, styleQ){
  
  var tempid = DOM.getElementId(element);
  // nothing to add
  if(!tempid){
    // perhaps throw exception here?
    trm.error('Failed to find id for element during StyleQ add '+(element ? element.tagName : '(null element)'));
    return;
  }
  var map = FIELDS.getStyleQMap();
  var index = map[tempid];
  
  // Bug 1674: replace if(index) with better check
  if(!isnull(index)) {
  // replace existing member
    map.splice(index, 1, styleQ);
  } else {
  // didn't exist. add to end
    index = map.push(styleQ) - 1;
    map[tempid] = index;
  }
}

/**
 * @element Element with a StyleQ to remove from the map
 */
FIELDS.removeStyleQ = function(element){
  var tempid = DOM.getElementId(element);
  // nothing to add
  if(!tempid){
    trm.error('Failed to find id for element during StyleQ removal '+(element ? element.tagName : '(null element)'));
    return;
  }
  var map = FIELDS.getStyleQMap();
  var index = map[tempid];
  // Bug 1674: replace if(index) with better check
  if(!isnull(index)) {
    map[tempid] = null;
    
    // just replace it...removing it will shift array
    map.splice(index, 1, null);
  }
}

/**
 * Just sets the tab ordering to go to the next tab thru Req
 */
FIELDS.focusRequiredFirst = function(content) {
  FIELDS.cycleRequiredFirst = true;
  
  // sanity check
  if(!focusItem){
    return;
  }
  
  // focus on the first required field
  var flds = getElementsByClassName('fld_req');
  for( var i = 0; flds && i < flds.length; i++) {
    if(FIELDS.isRequired(flds[i])){
      focusItem(flds[i].id,true);
      break;
    }
  }
}

/**
 * Sets the order in which fields gain focus when tabbing
 * 
 * @param content
 *          json object
 */
FIELDS.setFocusOrder = function(content) {
  
  STORAGE.clearPersistent();
  
  var focusOrder = content.focusOrder;
  
  // check to make sure its the input id (merged from rev 1426 of 4.2.x)
  for( var i = 0; i < focusOrder.length; i++) {
    var current = focusOrder[i];

    var ctrl = STORAGE.getElement(current);

    // fix 2188: noticed that focus order broke for smartcloud vert labels
    // these ids match the label row...get the input row
    if(DOM.verticallabels && FIELDS.isVerticalLabelRow(ctrl)){
      ctrl = DOM.getNextSibling(ctrl);
    }

    var ctrl2 = DOM.getComponent(ctrl, 'textbox');
    if(ctrl2){
      focusOrder[i] = ctrl2.id;
    }
    // fix 2193: focus order and checkboxes
    else{
      ctrl2 = DOM.getComponent(ctrl, 'link');
      if(ctrl2){
        focusOrder[i] = ctrl2.id;
      }
    }
  }
  
  // cycle the required fields first
  if(content.cycleRequiredFirst){
    FIELDS.focusRequiredFirst(content);
  }
  
  // focus on the first not readonly element (since we are not focusing on a required field)
  else{
    var i = -1;
    for(i = 0; focusOrder && i < focusOrder.length; i++){
      var input = STORAGE.getElement(focusOrder[i]);
      if(input && input.className.match(/fld_ro/)){
        continue;
      }
      break;
    }
    if(focusItem && focusOrder && focusOrder.length && i < focusOrder.length){
      focusItem(focusOrder[i],true);
    }
  }

  FIELDS.FOCUSORDER = focusOrder;
}

/**
 * lookup the next element in the tab order if rules dictate it. the prevId is the focus id i.e. retrieved from the getFocusId() function and not the top level
 * element. The return id must also focussable
 * 
 * @returns mxId that is focussable (i.e not hidden)
 */
FIELDS.nextFocusId = function(inputdevice, prevId) {
  var x = STORAGE.getElement(prevId);
  if(x.className && x.className.match(/dijitEditor/)){
      prevId = prevId+"_iframe";
  }
  
  var event = new FieldFocusEvent(inputdevice, prevId);
  
  // get the next empty required field
  if(FIELDS.cycleRequiredFirst){
    STORAGE.setPersistent('focusevent', event);
    var retval = event.getNextRequired();
    if(retval){
      
      // break the cycle...cause a blur event
      if(retval == prevId){
        showMessage(2, "Please fill in all required fields first");
      }else{
        return retval;
      }
    }
  }
  
  // iterate default maximo order
  if(FIELDS.FOCUSORDER.length < 1){
    return null;
  }
  
  // have rules and next in order
  if(event.hasNextFromRules()){
    return event.getNextFromRules();
  }
  
  // don't loop...break out
  return null;
} 

/**
 * Check if the control is required and has a value
 * 
 * @param input
 * @returns true only if the field is required AND has no value
 */
FIELDS.isRequired = function(input, ignoreHidden){
  
  // passed filter field
  if(input && input.filterrowid && input.required){
    return !FIELDS.hasValue(input);
  }
  //fix 2825: their dom changed slightly
  if(input && input.isfilter && input.parentElement && input.parentElement.required){
    return !FIELDS.hasValue(input);
  }
  
  // comes after isControl...sanity check
  if(!input){
    return false;
  }
  
  // whole control is hidden
  if(!ignoreHidden && FIELDS.isHidden(input.id)){
    return false;
  }
  
  // has a value (not required for field focus)
  if(FIELDS.hasValue(input) ){
    return false;
  }
  
  //fix 2830, 2770: fldinfo is unreliable
  return input.className.match(/fld_req/);
}

/**
 * Check if the control is readonly
 * 
 * @param input
 *          returns true only if this input is readonly
 */
FIELDS.isReadOnly = function(input){
  
  // sanity check
  if(!input){
    return false;
  }
  
  return (input.disabled || input.getAttribute("readonly"));
}

/**
 * @returns true only when this field has a value (something other than '')
 */
FIELDS.hasValue = function(input){
  if(!input){
    throw 'Illegal argument for FIELD.hasValue';
  }
  // checkbox
  if(input.tagName == 'IMG'){
    return true;
  }
  
  // has a value
  if(!isnull(input.value) && input.value != ""){
    return true;
  }
  
  // has no value
  return false;
 
}

/**
 * Sets the style of the currently selected input. i.e HighlightSelected
 */
FIELDS.setSelectedStyle = function(jsParams){
  STORAGE.selectedStyle = FIELDS.divideStyle(jsParams.setHash);
  STORAGE.selectedStyleForRows = false;
  for(var x in jsParams.setHash){
    if(x.match(/^container/)){
      STORAGE.selectedStyleForRows = true;
      break;
    }
  }
}

/**
 * Sets the style of required fields. i.e HighlightRequired
 */
FIELDS.setRequiredStyle = function(jsParams){
  FIELDS.requiredStyle = FIELDS.divideStyle(jsParams.setHash);
}

/**
 * Sets the style of readonly fields. i.e HighlightReadOnly
 */
FIELDS.setReadOnlyStyle = function(jsParams){
  FIELDS.readOnlyStyle = FIELDS.divideStyle(jsParams.setHash);
}

/**
 * @returns Array [inputstyle, controlstyle, inputtablestyle]. Never null
 */
FIELDS.divideStyle = function(style){
  var input = {};
  var control = {};
  var table = {};
  for(var x in style){
    // not textbox or label so its for the control
  // Bug 1659: remove "label" from this test. was not being found in the case of
  // required and readonly labels. Putting it on the control allows label to be found.
  // note: multi part text boxes where main text is required and description part is readonly
  // may show the wrong label color as the label being found is the first one in the control
    if(!x.match(/(?:^textbox)/)){
      control[x] = style[x];
    }
    
    // input property
    else{
      // border/color needs to be on input table not on the input
      var y = x.replace(/textbox/,'container');
      table[y] = style[x];
      input[x] = style[x];
    }
  }
  return [input, control, table];
}

/**
 * Replaces the keys of the styleTLV and returns the new styleTLV with updated keys but same values.
 * 
 * @param styleTLV current style JSON object
 * @param replaceFunc function with 1 arg that is the current key of styleTLV. returns the new key or orig arg
 * @return styleTLV with updated keys but same values
 */
FIELDS.replaceStyleKey = function(styleTLV, replaceFunc){
  var retval = {};
  for(var i in styleTLV){
    var newi = replaceFunc(i);
    retval[newi] = styleTLV[i];
  }
  
  return retval;
}

/**
 * Change the keys of the styleTLV so that the textbox styles point to the desc input
 * 
 * @return styleTLV with keys updated to replace textbox with desc
 */
FIELDS.updateStyleAsDesc = function(styleTLV){
  return FIELDS.replaceStyleKey(styleTLV, function(i){
      if(i.indexOf('textbox') > -1){
        i = i.replace('textbox','desc');
      }
      return i;
  });
}

/**
 * TRUE only if the element is the TR for a radiobutton row (where label is to the right) 
 */
FIELDS.isRadioButtonRow = function(element){
   const inputs = element.getElementsByTagName('INPUT');
   if(inputs !== undefined && inputs.length){
     const input = inputs[0];
     return input.getAttribute && input.getAttribute('ctype') == 'radiobutton';
   }
}

/**
 * 
 */
FIELDS.isVerticalLabelRow = function(element){
  if(!DOM.verticallabels){
    return false;
  }
  if(!element){
    return false;
  }
  if(element.tagName != 'TR'){
    return false;
  }
  if(!element.id){
    return false;
  }
  // table row
  if(element.id.indexOf('[') != -1){
    return false;
  }
  if(!(element.getAttribute && element.getAttribute('control')=='true')){
    return false;
  }
  if(FIELDS.isRadioButtonRow(element)){
    return false;
  }
  return true;

}

/**
 * 
 */
FIELDS.isVerticalInputRow = function(element){
  if(!DOM.verticallabels){
    return false;
  }
  if(!element){
    return false;
  }
  if(element.tagName != 'TR'){
    return false;
  }
  return  element.id.indexOf('[') == -1 && !(element.getAttribute && element.getAttribute('control')=='true');
}

/**
 * @returns TR associated with the input. NULL if control is not found. There is a limit of 10 to prevent long loops
 */
FIELDS.getControl = function(input){
  // sanity check
  if(!input){
    return;
  }
  if(input.isfilter){
    return input;
  }
  var count = 0;
  while(count < 10 && input.tagName != 'TR'){
    input = input.parentNode;
  }
  
  if(FIELDS.isControl(input)){
    return input;
  }
}

/**
 * @returns true only when this is the control conatiner for an input/inputs.
 */
FIELDS.isControl = function(element){
  if(!element){
    return false;
  }
  
  // fix 2117
  if(DOM.verticallabels && element.tagName == 'TR'){
    
    var temp = DOM.getPreviousSibling(element);
    if(temp)
      element = temp;
  }
  
  // normal DOM
  return element.getAttribute && element.getAttribute("control") == "true";
}

/**
 * Called when a field gains focus
 */
FIELDS.onFocus = function(component){
  // Bug# 1310. Tabbing out of a field with display rules on it doesn't shift focus to the next field in IE.
  // after maximo executes an on focus of a certain field, store the last focus id
  // since the hidden frame seems to lose it after the ajax transaction.
  if( STORAGE.focusid != getFocusId()) {
    // focussing on a different element from last time.
    
    STORAGE.focusid = getFocusId();
    // bug# 1430. Need to be able to control the tab ordering in a maximo app.
    // don't need to do anything more here. inputdevice.Controller takes care of
    // refocussing if needed.
  }
  
  top.document.trm.displayproperty.Controller.highlightSelected(component);
}

/**
 * Called when a field loses focus
 */
FIELDS.onBlur = function(component){
  // store the name of the element that's losing focus.
  STORAGE.prevFocusid = getFocusId();

  // clear our cached elements etc since dom may have changed
  STORAGE.clear();
  
  // remove highlighting
  top.document.trm.displayproperty.Controller.unhighlightSelected(component);
}

/**
 * Taverses the hierarchy to see if the specified control is hidden
 * 
 * @return true if a parent of this control is a TR and is hidden
 */
FIELDS.isHidden = function(id){
  
  var parent = STORAGE.getElement(id);

  do{
    if(!parent){
      return false;
    }
    // fix 2444: then check parent
    if(parent.style && (parent.style.visibility == 'hidden' || parent.style.display == 'none')){
      return true;
    }
    
    parent = parent.parentNode;

  }while(parent != document && parent.className != 'tabBodyTable')
  
  // shouldn't get here
  return false;
}



/*
 * Developed by Robert Nyman, http://www.robertnyman.com Code/licensing: http://code.google.com/p/getelementsbyclassname/
 */
var getElementsByClassName = function (className, tag, elm){
  if (top.document.getElementsByClassName) {
    getElementsByClassName = function (className, tag, elm) {
      elm = elm || top.document;
      // amahen: added check because <#TEXT> elements don't have this method
      var elements = elm.getElementsByClassName ? elm.getElementsByClassName(className) : [],
      nodeName = (tag)? new RegExp("\\b" + tag + "\\b", "i") : null,
      returnElements = [],
      current;
      for(var i=0, il=elements.length; i<il; i+=1){
        current = elements[i];
        if(!nodeName || nodeName.test(current.nodeName)) {
          returnElements.push(current);
        }
      }
      return returnElements;
    };
  }
  else if (top.document.evaluate) {
    getElementsByClassName = function (className, tag, elm) {
      tag = tag || "*";
      elm = elm || top.document;
      var classes = className.split(" "),
      classesToCheck = "",
      xhtmlNamespace = "http://www.w3.org/1999/xhtml",
      namespaceResolver = (top.document.documentElement.namespaceURI === xhtmlNamespace)? xhtmlNamespace : null,
      returnElements = [],
      elements,
      node;
      for(var j=0, jl=classes.length; j<jl; j+=1){
        classesToCheck += "[contains(concat(' ', @class, ' '), ' " + classes[j] + " ')]";
      }
      try {
        elements = top.document.evaluate(".//" + tag + classesToCheck, elm, namespaceResolver, 0, null);
      }
      catch (e) {
        elements = top.document.evaluate(".//" + tag + classesToCheck, elm, null, 0, null);
      }
      while ((node = elements.iterateNext())) {
        returnElements.push(node);
      }
      return returnElements;
    };
  }
  else {
    getElementsByClassName = function (className, tag, elm) {
      tag = tag || "*";
      elm = elm || top.document;
      var classes = className.split(" "),
      classesToCheck = [],
      elements = (tag === "*" && elm.all)? elm.all : elm.getElementsByTagName(tag),
      current,
      returnElements = [],
      match;
      for(var k=0, kl=classes.length; k<kl; k+=1){
        classesToCheck.push(new RegExp("(^|\\s)" + classes[k] + "(\\s|$)"));
      }
      for(var l=0, ll=elements.length; l<ll; l+=1){
        current = elements[l];
        match = false;
        for(var m=0, ml=classesToCheck.length; m<ml; m+=1){
          match = classesToCheck[m].test(current.className);
          if (!match) {
            break;
          }
        }
        if (match) {
          returnElements.push(current);
        }
      }
      return returnElements;
    };
  }
  return getElementsByClassName(className, tag, elm);
};

// start our declarations
var trm;
if(!trm)
  trm = {};
if(!trm.displayproperty)
  trm.displayproperty = {};

// *******************************JS_DEBUGGING***************************
var RMP_PREPEND = 0x1;
var RMP_APPEND = 0x2;
var RMP_ONESHOT = 0x4;

// Possible KEYS FOR the style queue.
// Higher value indicates higher priority.
// Bug# 416: Change priority of field styles.
var TRM_HIDETAB = 0;
var TRM_STYLE = 1;
var TRM_MAXSTYLEQSIZE = TRM_STYLE + 1; // equal to the maximum value.
var FIRST_TRMHIDDEN_ELEMENT = "FIRST_TRMHIDDEN_ELEMENT";

/***************************************************************************************************************************************************************
 * TOP LEVEL COMMON METHODS.
 **************************************************************************************************************************************************************/

// *****************************TRM_HEADER***************************
// ***************************** extend ***************************

if(!trm.extend)
  trm.extend = {}

/**
 * Used to extend functions...such as onblur or onfocus etc
 * 
 * @param event
 * @param component
 */
function trm_extend_exit(event, component) {
  // arg1 in the control handlers is the event.
  event = (event) ? event : ((window.event) ? window.event : "");

  if(!event)
    return;
  if(!component)
    component = this;
  
  switch(event.type){
    case 'blur':
      FIELDS.onBlur(component);
      break;
    case 'focus':
      FIELDS.onFocus(component);
      break;
  }
  
}// trm_extend_exit

/**
 * Allows the iteration of an array both forward and backward.
 */
function Iterator(array, reverse){
  if(!array){
    throw "null array passed to Iterator";
  }
  
  // the array we are iterating
  this.myarray = array;
  
  // current index we're on
  this.index = -1;
  
  // true if we're going backward
  this.backward = reverse;
  
  // we're to reverse this
  if(reverse){
    this.index = array.length - 1;
  }
  
  /**
   * 
   */
  this.next = function(){
    if(this.backward){
      this.index--;
      return this.myarray[this.index];
    }    
    this.index++;
    return this.myarray[this.index];
  }
  
  /**
   * 
   */
  this.hasNext = function(){
    if(this.backward){
      return this.index-1  > -1;
    }
    return this.index+1 < this.myarray.length;
  }
}

/**
 * @param inputdevice
 * @param prevId
 * @returns {FieldFocusEvent}
 */
function FieldFocusEvent(inputdevice, prevId){
  /**
   * The input device that contains info about our tabbing event
   */
  this.inputdevice = inputdevice; 
  /**
   * Id of the field currently in focus (field the user is tabbing from)
   */
  this.currentId = prevId;
  
  /**
   * @returns Iterator to iterate the fields on the page
   */
  this.getIter = function(){
    return new Iterator(FIELDS.getAllFields(),(this.inputdevice.mode == this.inputdevice.MODE_SHIFT_TAB));
  }
  
  /**
   * Initializes the member variables
   */
  this.init = function(){
    // already initted
    if(this.currentIndex || this.firstNotRequired || this.firstRequired){
      return;
    }
    
    var iter = this.getIter();
    var flag = false;
    var i = iter.index;
    while(iter.hasNext()){
      var fld = iter.next();
      
      // set the first required
      if(!this.firstRequired){
        if(FIELDS.isRequired(fld)){
          this.firstRequired = fld.id;
        }
      }
      
      // set first not required
      if(!this.firstNotRequired){
        if(!FIELDS.isRequired(fld)){
          this.firstNotRequired = fld.id;
        }
      }
      
      // set index of current
      if(!this.currentIndex){
        var input = fld;
        if(!this.currentId){
          this.currentIndex = i;
        }else if(input.id == this.currentId){
          this.currentIndex = i;
        }
      }
      
      // get out
      if(this.currentIndex && this.firstNotRequired && this.firstRequired){
        return;
      }
      i = iter.index;
    }
  }
  
  /**
   * @returns index of the field currently in focus (the field the user is tabbing from)
   */
  this.getCurrentIndex = function(){
    this.init();
    return this.currentIndex;
  }
  
  /**
   * @returns Iterator starting from currentIndex
   */
  this.getIterFromCurrent = function(){
    var retval = this.getIter();
    retval.index = this.getCurrentIndex();
    retval.next();
    return retval;
  }
  
  /**
   * @returns id of the first required field on the page
   */
  this.getFirstRequired = function(){
    this.init();
    return this.firstRequired;
  }
  
  /**
   * @returns id of the first not required field on the page
   */
  this.getFirstNotRequired = function(){
    this.init();
    return this.firstNotRequired;
  }
  
  /**
   * @returns id of the next required field. If at the end it will loop around
   */
  this.getNextRequired = function(){
    if(this.nextRequired){
      return this.nextRequired;
    }
    var iter = this.getIterFromCurrent();
    while(iter.hasNext()){
      var input = iter.next();
      if(FIELDS.isRequired(input)){
        this.nextRequired = input.id;
        return this.nextRequired;
      }
    }
    return this.getFirstRequired();
  }
  
  /**
   * @returns id of the next not required field
   */
  this.getNextNotRequired = function(){
    if(this.nextNotRequired){
      return this.nextNotRequired;
    }
    var iter = this.getIterFromCurrent();
    while(iter.hasNext()){
      var input = iter.next();
      if(!FIELDS.isRequired(input)){
        this.nextNotRequired = input.id;
        break;
      }
    }
    return this.nextNotRequired;
  }
  
  /**
   * @returns Iterator of the FOCUSORDER
   */
  this.getRuleIter = function(){
    return new Iterator(FIELDS.FOCUSORDER,(this.inputdevice.mode == this.inputdevice.MODE_SHIFT_TAB));
  }
  
  /**
   * @returns Iterator of the FOCUSORDER from the current field currently in focus
   */
  this.getRuleIterFromCurrent = function(){
    if(!this.currentFOIndex){
      // have a tab order rule and previous element was stored.
      // now find out if a rule mentions this specific element.
      for( var i = 0; i < FIELDS.FOCUSORDER.length; i++) { 
        
        // field tabbing from
        if(FIELDS.FOCUSORDER[i] == this.currentId){
          this.currentFOIndex = i;
          break;
        }
      }
    }
    var retval = this.getRuleIter();
    retval.index = this.currentFOIndex;
    return retval;
  }
  
  /**
   * Warning make sure there are Rules before calling this method
   * 
   * @returns id of the first field to focus on from the FieldFocusRules. NULL if no rules have been set
   */
  this.getFirstFromRules = function(){
    return this.getRuleIter().next();
  }
  
  /**
   * Warning make sure there are Rules before calling this method
   * 
   * @returns true only if there is another field in the FieldFocusRules. false otherwise
   */
  this.hasNextFromRules = function(){
    return this.getRuleIterFromCurrent().hasNext();
  }
  
  /**
   * Warning make sure there are Rules before calling this method
   * 
   * @returns id of the next field to focus on from the FieldFocusRules. NULL if no rules have been set
   */
  this.getNextFromRules = function(){
    var iter = this.getRuleIterFromCurrent();
    
    // loop around
    if(!iter.hasNext()){
      return this.getFirstFromRules();
    }
    return iter.next();
  }
  
}

/**
 * 
 */
trm.extend.JsExtend = function() {
  /**
   * 
   */
  this.extended = false;

  /**
   * makes sure we try to extend only once. complete list of functions that need to be extended. setFocusId is needed since input_onfocus is not called for all
   * controls.
   */
  this.fnNames = new Array("input_onblur", "setFocusId");

  /**
   * 
   */
  this.sprint = function(fmt) {
    var i, j, locs;

    if(!document._saveSprintFmt) {
      document._saveSprintFmt = new Array();
    }

    if(!document._saveSprintFmt[fmt]) {

      locs = new Array();
      i = -1;
      j = 0;
      do {
        i = fmt.indexOf("?", i + 1);
        if(i != -1) {
          locs[j++] = i;
        }
      } while(i != -1);

      document._saveSprintFmt[fmt] = locs;
    } else {
      locs = document._saveSprintFmt[fmt];
    }

    j = -1;

    var newstr = new String();

    for(i = 0; i < locs.length; i++) {
      newstr += fmt.substring(j + 1, locs[i]) + this.sprint.arguments[i + 1];
      j = locs[i];
    }

    newstr += fmt.substring(j + 1, fmt.length);

    return(newstr);
  }

  /**
   * 
   */
  this.removeFuncExtension = function(funcspec, func) {
    func._tobedeleted = true;
  }

  /**
   * 
   */
  this.extendFunction = function(ctxt, oldFnName, newFnName, flags) {
    var prepend = flags & RMP_PREPEND;
    var oneshot = flags & RMP_ONESHOT;

    var container = (isnull(ctxt)) ? "window" : ctxt;

    var owner = eval(container);

    if(!owner[oldFnName]) {
      return false;
    }

    // store the old function in a renamed location.
    // making it ready to replace the old function.
    var renamedFn = "_baseFunction_" + oldFnName;
    owner[renamedFn] = owner[oldFnName];

    // now construct the arguments of the new function
    // object based on arguments of the old function.`
    letters = "abcdefghijklmnop";
    var constrString = "new Function(";
    var letstr = new String();
    var barstr = new String();
    for( var i = 0; i < owner[oldFnName].length; i++) {
      curc = letters.charAt(i);
      if(i > 0) {
        letstr += ",";
        barstr += ",";
      }
      letstr += curc;
      barstr += "'" + curc + "'";
    }
    constrString += barstr + (owner[oldFnName].length > 0 ? "," : "");

    // now build the body of the function
    // which is the final argument of the Function ()
    /*
     * it is of the type function test(a,b,c) { if(!this.oldFn) this.oldFn = oldFn; if(!this.newFn) this.newFn = newFn; this.oldFn(a,b,c); this.newFn(a,b,c); }
     * this allows oldFn to continue to use the this object as before.
     */

    // decide which function gets called first.
    var firstFn = renamedFn;
    var secondFn = newFnName
    if(prepend) {
      firstFn = newFnName;
      secondFn = renamedFn;
    }
    constrString = this.sprint("? \" " + "if(!this.?) this.?=?;" + "if(!this.?) this.?=?;" + "this.?(?);" + "this.?(?); \"); ", constrString, firstFn, firstFn,
        firstFn, secondFn, secondFn, secondFn, firstFn, letstr, secondFn, letstr);
    // alert(constrString);

    // attach the new function object where the old function once was.
    owner[oldFnName] = eval(constrString);

    return true;
  }

  /**
   * 
   */
  this.getExtendingFn = function(ctxtObj, oldFnName) {
    // generate fn to extend. For now it can only do activate/deactivate.

    // var ctxtObj = eval(ctxt);
    if(isnull(ctxtObj))
      return;

    var oldFn = ctxtObj[oldFnName];
    if(isnull(oldFn)) {
      trm.warn("Old function not defined:" + oldFnName + ".");
      return;
    }

    var fnName = "trm_extend_" + oldFnName;
    var retVal = ctxtObj[fnName];
    if(isnull(retVal)) {
      trm.warn("Did not implement extending function: " + fnName);
    }
    return retVal;
  }

  /**
   * 
   */
  this.extendFn = function() {
    if(this.extended)
      return;
    try {
      this.extendFunction("window", "processXHR", "trm_extend_processXHR", RMP_APPEND);
      
      // extend the event handlers for all controls.
      for( var i = 0; i < this.fnNames.length; i++) {
        var origFnName = this.fnNames[i];
        var newFnName = 'trm_extend_exit';
        this.extendFunction("window", origFnName, newFnName, RMP_APPEND);
      }
      
      // amahen: can't extend when there is a return value
//      this.extendFunction("window", "showCommonTooltipDialog", "trm_extend_showCommonTooltipDialog", RMP_APPEND);
      // instead extend old fashion way
      const self = window;
      if(!self._showCommonTooltipDialog){
        self._showCommonTooltipDialog = self.showCommonTooltipDialog;
        self.showCommonTooltipDialog = function(){
          const retval = self._showCommonTooltipDialog.apply(self, arguments);
          self.trm_extend_showCommonTooltipDialog.apply(self, arguments);
          return retval;
        };
      }
      // 1690
      window._appendClass = window.appendClass;
      window.appendClass = DOM.appendClass;
      window._removeClass = window.removeClass;
      window.removeClass = DOM.removeClass;
      
      this.extended = true;
      clearInterval(this.intervalId);
    } catch (ex) {
      trm.warn(ex);
    }
  }

} // trm.extend.JsExtend

/**
 * After IBM processXHR this method is called 
 * 
 * @param responseObj
 * @param ioArgs
 * @returns
 */
function trm_extend_processXHR(responseObj, ioArgs){
  if(undef(responseObj)){
    return;
  }
  var updateComponents = responseObj.getElementsByTagName("component");
  if(undef(updateComponents)) {
    return;
  }
  for(var i=0;i<updateComponents.length;i++) {
    var replaceComponent=updateComponents[i];
    var id = replaceComponent.getAttribute("id");
    var htmlAndScript = fixAndRemoveScripts(replaceComponent);
    var compHTML = htmlAndScript[0];
    var compScript=htmlAndScript[1];
  }
}

/**
 * After IBM showCommonTooltipDialog is called, this is called
 * 
 * @param messageObj
 * @param customtooltip
 * @returns
 */
function trm_extend_showCommonTooltipDialog(messageObj, customtooltip){
  // cached tooltips don't have rmstyles replaced
  DOM.replaceRMSTYLES();
}
      
// ***************************TRM_FOOTER**********************************


/**
 * This section is used to redirect user to a different location.
 */
trm.displayproperty.Redirect = function() {
  
  /**
   * 
   */
  this.getAppUrl = function(jsParam) {
    var url = jsParam
    var currLocation = top.location.toString();
    if(isnull(currLocation) || isnull(url) || url.indexOf("app:") != 0)
      return url;

    // app specified.
    // convert app:wotrack to
    // http://deskswamialex:7001/maximo/ui/maximo.jsp?event=loadapp&value=wotrack
    var strArr = currLocation.split("/maximo/");
    if(strArr.length < 1) {
      trm.error(" cannot parse the location: " + currLocation);
      return url;
    }
    var newUrl = strArr[0] + "/maximo/ui/maximo.jsp?event=loadapp&value=" + url.substring("app:".length);
    return newUrl;
  }
  
/**
 * 
 */
  this.exec = function(jsParam) {
    // redirect the browser to the new url
    var url = jsParam.url;
    var newWindow = jsParam.newWindow;
    
    var newUrl = this.getAppUrl(url);
    
    // fix 1777: this is a boolean NOT a string
    if(newWindow) {
      // show in new window.
      window.open(newUrl);
    } else {
      // show in the same window. this is the default.
      top.location.replace(newUrl);
    }
  }
}// trm.displayproperty.Redirect

/***************************************************************************************************************************************************************
 * trm.displayproperty.ChgStyle: This section handles changes in style of any control.
 **************************************************************************************************************************************************************/
trm.displayproperty.ChgStyle = function() {
  
  /**
   * @param ctrl container or array 
   */
  this.changePropValue = function(ctrl, type, value) {
    // change the value of the property as specified by the parameter.
    // ASSUMES ctrl, type are defined.


    // go through the type and get to the final property.
    // i.e. ctrl["style"]["backgroundColor"]
    var property = ctrl;
    
    // set the style property
    var typeArr = type.split(".");
    for( var i = 0; i < typeArr.length - 1; i++) {
      property = property[typeArr[i]];
      if(isnull(property)) {
        trm.info("INVALID COMBINATION ctrl " + ctrl.id + " type " + type + " value " + value);
        return;
      }
    }

    // the last portion of the type is the key that needs the value
    var key = typeArr[typeArr.length - 1];

    // value needs to be reset.
    if(isnull(value) || '-' == value) {
      // fix 2202: size can't be nulled...just leave it
      if(key != 'size')
        property[key] = '';
      return;
    }


    // VALUE NEEDS TO BE SET
    // Oct 23, 2006 SN: check if command has already been issued.
    // catch any exception while setting the value.
    // So a meaningful message can be written to the log.
    try {
      property[key] = value;
      // fix 2202: width will override the size setting
      if(key == 'size'){
        property.style.width = '';
      }
      // fix 3657 - value is not set without px/percent/em, additionally it requires an !important in 7.6.1 iot18
      else if (key == "fontSize") { //confirm it's fontSize
    	  //can't set important by just setting the property[key] to the value
    	  //ide by default just brings a number, if so, append 'px' (bug 2950 also)
		  ctrl.style.setProperty("font-size", isNaN(value) ? value : value + "px", "important");
	  }
      // fix 2950: hex must have # before it
      else if(key.toLowerCase().indexOf('color') > -1 && value && value.length == 6 && value.match(/^[a-fA-F0-9]+/)){
        property[key] = '#'+value;
      }

      // fix 2098: added extra part to the condition
      // fix 1923: until IE corrects the hiding an li bug...this will have to do
      if(isIE() && key == 'display' && value == 'none' && ctrl.tagName == 'LI' && ctrl.ctype == 'toolbarbutton'){
        ctrl.parentNode.removeChild(ctrl);
      }
      
      // fix 1635: they are using background images in tivoli09 skin
      // undo 1635 since they re-worked the div in 7.5.0.1
//      if('backgroundColor' == key && (property['backgroundImage'] == '' || property['backgroundImage'] == 'inherit')){
//        property['backgroundImage'] = 'none';
//      }
    } catch (e) {
      trm.warn("CANNOT SET value: " + value + " <BR> Errorname:" + e.name + " Message: " + e.message);
    }
  }

  /**
   * 
   */
  this.changeElementStyleValue = function(ctrl, type, value) {
    if(!ctrl){
      return;
    }
    
    // Split the type|value string and change the value of the element style.
    // typeValue: of the kind type|value i.e. textbox.style.backgroundColor|red

    
    // TYPE IS DEFINED, Value may be empty if it needs to be reset.
    var typeArr = type.split(".");
    
    // Oct 3, 2008 SN: Bug# 1151. Container style rules should have prefix "Container"
    // require all types to have a prefix i.e. label, textbox, desc and container.
    // get the child element corr. to the specified type.
    var input = DOM.getComponent(ctrl, typeArr[0]);

    // strip the type (label, container etc)
    type = type.substring(typeArr[0].length + 1)

    // not necessarily a bug. E.g. Some textboxes may not have corr. labels.
    if(isnull(type)){
      return;
    }

    // found it just do it
    // fix 2594: skip this if doing style by index
    // fix 3210: only apply if NOT a tablerow
    //in 7.6.1 skin, document is selected and does not have a className
    if (ctrl.className === undefined) {
    	return;
    }
    if(ctrl.className.indexOf('tablerow') < 0 && !isnull(input) && (isnull(ctrl.colorCellIndex) && isnull(ctrl.txtcolorCellIndex))){
      this.changePropValue(input, type, value);
      return;
    }

    // allow color in rows of text
    switch(typeArr[0]){
      case 'textbox':
        typeArr[0] = 'fld';
        break;
      case 'label':
        break;
      default:
        console.log('Unable to change style for '+typeArr[0]+' on '+ctrl);
        return;
    }

    // fix 2592: they changed their tables
    var temparray;
    if(ctrl.className.indexOf('tablerow') > -1){
      temparray = getElementsByClassName('cd', null, ctrl);
      // fix 2826: classes are different when selectable
      if(!temparray || !temparray.length){
        temparray = getElementsByClassName('tabletext', null, ctrl);
      }
    }
    // find all labels in this cell
    var rowlabels = getElementsByClassName(typeArr[0], null, ctrl);
    if(temparray){
      temparray = temparray.concat(rowlabels);
    }
    else{
      temparray = rowlabels;
    }
    
    // missed it
    if(!temparray || temparray.length < 1 || !temparray[0]){
      return;
    }

    // specified a column number to highlight (for labels)
    if(typeArr[0] == 'label' && (ctrl.colorCellIndex || ctrl.colorCellIndex == 0)){
      input = temparray[ctrl.colorCellIndex]; 
    } 
    // specified a column number to highlight (for txts)
    else if(typeArr[0] == 'fld' && (ctrl.txtcolorCellIndex || ctrl.txtcolorCellIndex == 0)){
      input = temparray[ctrl.txtcolorCellIndex]; 
    } 

    // change the whole array
    else{
      for(var i = 0; i < temparray.length; i++){
        this.changePropValue(temparray[i], type, value);
      }
      return;
    }


    this.changePropValue(input, type, value);
  }

  /**
   * Change the style for the specified element
   * 
   * @param element
   *          to change the style on
   * @param styleTLV
   *          an object with properties relating to the component and the style to set (ex: styleTLV['textbox.backgroundColor'] == 'tomato')
   */
  this.changeElementStyle = function(element, styleTLV) {
    if(element && !isnull(styleTLV['label.style.index'])){
      element.colorCellIndex = styleTLV['label.style.index'];
    }

    // enh 2215
    if(element && !isnull(styleTLV['textbox.style.index'])){
      element.txtcolorCellIndex = styleTLV['textbox.style.index'];
    }
    
    //fix 2117: when styling fields we get the input's TR...when styling controls we get the labels TR
    // so for controls lets mirror the field
    // fix 2598: table's are also tr's so only get sibling if its a field (i.e there is no child with class tableouter)
    if(FIELDS.isVerticalLabelRow(element) && !getElementsByClassName('tableouter','TABLE',element).length){
      var temp = DOM.getNextSibling(element);
      if(temp)
        element = temp;
    }
    
    // fix styles for specified controls (i.e hard coded styles not a display setting)
    if(FIELDS.isControl(element)){
      var divided = FIELDS.divideStyle(styleTLV);
      
      var input = DOM.getInputElement(element);
      this.changeElementStyle(input, divided[0]);
      styleTLV = divided[1];
    }
    
    // for each type value pair change the value.
    // amahen: saw some wierdness here where it just ignored certain attributes (like label.style.color)
    for( var att in styleTLV) {
      if(att == 'label.style.index' || att == 'textbox.style.index'){
        continue;
      }
      this.changeElementStyleValue(element, att, styleTLV[att]);
      
      // if this is the input row of vert label call same thing on label row
      if(FIELDS.isVerticalInputRow(element)){
        this.changeElementStyleValue(DOM.getVerticalLabel(element), att, styleTLV[att]);
      }
    }
    
    
  }
  
  /**
   * Change the style for the specified element
   */
  this.exec = function(el, styleTLV) {
    
    // sanity check
    if(isnull(el) || isnull(styleTLV)) {
      return;
    }
    
    this.changeElementStyle(el, styleTLV);
  }
  
} // trm.displayproperty.ChgStyle.


// bug 621: Add ability to hide a table column using a rule
// This object will reorder cells in the row for the table.
// In general, this object can be used to insert and remove any element
// that is in a list and has a parent.
trm.displayproperty.Reorder = function() {
  this.pushToEnd = function(el) {
    // push the element to the end and insert a placeholder in its place.
    
    if(!isnull(el.realEl)) {
      // it is a placeholder, cant push to end.
      trm.error("pushToEnd: el " + el.id + " is probably a placeholder. ")
      return;
    }
    
    // insert an empty element in the original place.
    var parent = el.parentNode;
    var placeHolderEl = document.createElement(el.tagName);
    if(!isnull(el.id)) {
      placeHolderEl.id = "trm_" + el.id; 
    } 
    placeHolderEl.realEl = el;
    parent.insertBefore(placeHolderEl,el);
    
    // no need to actually push it to the end of the list.
    // can remove from the cells, this ensures we don't see a
    // empty space at the end.
    parent.removeChild(el);
  }
  
  this.popFromEnd = function(placeHolderEl) {
    if(isnull(placeHolderEl.realEl)) {
      trm.error("popFromEnd: el " + placeHolderEl.id + " is not a placeholder!");
      return;
    }
    
    var parent = placeHolderEl.parentNode;
    var el = placeHolderEl.realEl;
    parent.insertBefore(el,placeHolderEl);
    parent.removeChild(placeHolderEl);
  }
}
 
/***************************************************************************************************************************************************************
 * trm.displayproperty.StyleQ: this object is stored in every (top-level) element that has a style change. It holds a priority queue of style changes that were
 * applied on the element.
 **************************************************************************************************************************************************************/

trm.displayproperty.StyleQ = function(trmChgStyle, el) {

  /**
   * 
   */
  this.trmChgStyle;FieldFocusEvent
  /**
   * The id of the element
   */
  this.id
  /**
   * The actual Q of styles
   */
  this.q;
  
  /**
   * 
   */
  this.setId = function(element){
    var temp = DOM.getElementId(element);
    if(!temp){
      throw 'Invalid element to attach StyleQ.';
    }
    this.id = temp;
  }
  
  /**
   * 
   */
  this.getId = function() {
    return this.id;
  }
  
  /**
   * 
   */
  this.setElement = function(element){
    this.setId(element);
  }
  
  /**
   * @return cached Element
   */
  this.getElement = function(){
    return STORAGE.getElement(this.getId());
  }
  
  /**
   * 
   */
  this.invalidArg = function(styleId) {
    return((isnull(styleId)) || (styleId >= TRM_MAXSTYLEQSIZE) || (styleId < 0));
  }

  /**
   * Check if the input has a value
   */
  this.ctrlHasValue = function() {
      
    var txtboxCtrl = DOM.getComponent(this.getElement(),"textbox");
    
    if(!isnull(txtboxCtrl) && !isnull(txtboxCtrl.value) && txtboxCtrl.value != "")
      return true;
    
    return false;
  }

  /**
   * Merges the two style TLVs into 1 and returns it. If either is null returns just the 1. This WILL modify styleTLV2! (the returned value)
   */
  this.mergeTLV = function(styleTLV, styleTLV2){
    if(!styleTLV){
      return styleTLV2;
    }
    if(!styleTLV2){
      return styleTLV;
    }
    
    for(var i in styleTLV){
      if(i in styleTLV2){
        continue;
      }
      styleTLV2[i] = styleTLV[i];
    }
    return styleTLV2;
  }
  
  /**
   * Create a new value for the style.
   */
  this.putNewValue = function(styleId, styleTLV) {
    switch(styleId) {
      case TRM_HIDETAB:
      case TRM_STYLE:
        // fix 1651: merge the styles instead of replacing
        this.q[styleId] = this.mergeTLV(this.q[styleId], styleTLV);
        break;
    }
  }

  /**
   * Apply all styles in the queue in the predefined order.
   */
  this.applyQueuedStyles = function() {
    
    // the element on which style is applied
    var element = this.getElement();
    
    for( var i = 0; i < TRM_MAXSTYLEQSIZE; i++) {
      var styleTLV = this.q[i];
      if(isnull(styleTLV)) {
        continue;
      }
      this.trmChgStyle.exec(element, styleTLV);
    }
  }

  /**
   * Remove the old value corr. to the styleid.
   */
  this.removeOldValue = function(styleId) {
    if(!isnull(this.q[styleId])) {
      this.q[styleId] = null;
    }
  }

  /**
   * Check if q is empty.
   */
  this.isEmpty = function() {
    // true if there are no styles in the q.
    for( var i = 0; i < TRM_MAXSTYLEQSIZE; i++) {
      if(!isnull(this.q[i]))
        return false;
    }
    return true;
  }

  /**
   * Add a new style to the queue.
   */
  this.addStyle = function(styleId, styleTLV) {
    /*
     * styleId styleTLV TRM_STYLE valid style. TRM_DISPPROP valid display property. TRM_READONLY <undefined> take value from global readonly style. TRM_REQURIED
     * <undefined> ,, ,, required style.
     */
    if(this.invalidArg(styleId)) {
      trm.error("addStyle: invalid parameters style: " + styleId);
      return;
    }

    this.putNewValue(styleId, styleTLV);
    this.applyQueuedStyles();
  }

  /**
   * Remove a style from the queue.
   */
  this.removeStyle = function(styleId, newStyle) {
    // must specify a styleId
    if(this.invalidArg(styleId)) {
      return;
    }

    var oldStyle = this.q[styleId];
    
    // if there was no corr. old style, nothing to remove.
    if(isnull(oldStyle)) {
      return;
    }
    
    // undo the specified styling (but only remove if the set styles match)
    if(newStyle){
      var count = 0;
      // fix 2578: switched to newStyle (had to rethink logic, not sure it was done correctly in the first place)
      for(var x in newStyle){
        // fix 2577 (only undo styles that are set the same)
        var resetstyles = newStyle[x] ? newStyle[x].split(/[,]\s*/) : [];
        if(!oldStyle[x] || resetstyles.indexOf(oldStyle[x]) > -1){
          count++;
          // fix 2215: don't reset style index
          if(x.endsWith('.index')){
            continue;
          }
          oldStyle[x] = undefined;        }
      }
      
      // check if we reset entire old style
      // remove from q etc
      if(trm.size(oldStyle) == count){
        newStyle = undefined;
      }
    }
    
    // remove the style from the element.
    if(!newStyle){
      var resetStyle = trm.displayproperty.Util.resetAllValues(oldStyle);
      this.trmChgStyle.exec(this.getElement(), resetStyle);

      // remove style from q.
      this.removeOldValue(styleId);
    }

    // update all the styles.
    this.applyQueuedStyles();
  }

  /**
   * 
   */
  this.print = function() {
  }
  
  // init the vars
  this.trmChgStyle = trmChgStyle || "";
  this.setElement(el);
  this.q = new Array(TRM_MAXSTYLEQSIZE);
  
}// trm.displayproperty.StyleQ

/***************************************************************************************************************************************************************
 * trm.displayproperty.Util: general utilities that I couldn't put anywhere else.
 **************************************************************************************************************************************************************/

trm.displayproperty.Util = function() {
  this.trmChgStyle = new trm.displayproperty.ChgStyle(); // change the style.
  this.reorder = new trm.displayproperty.Reorder(); // reorder a list of elements.

  /**
   * Creates a new style q and puts a reference to the current element.
   * 
   * @return trm.displayproperty.StyleQ that was created
   */
  this.addNGetStyleQ = function(el) {
    var retval = FIELDS.getStyleQ(el);
    if(isnull(retval)) {
      retval = new trm.displayproperty.StyleQ(this.trmChgStyle, el);
      FIELDS.addStyleQ(el, retval);
    }
    return retval;
  }

  /**
   * Apr 9, 2008 SN: Bug# 979. Speed up DisplaySetting rule. define a separate method that takes the element (rather than id).
   */
  this.addStyleEl = function(el, styleId, styleTLV) {
    if(isnull(styleTLV))
      return;

    var styleQ = this.addNGetStyleQ(el);
    if(isnull(styleQ)) {
      // interesting..
      // can happen if tab was changed and the entire element suddenly went away from the page.
      return;
    }
    styleQ.addStyle(styleId, styleTLV);
    styleQ.print();
  }

  /**
   * TEMPORARY UNTIL JSON is able to provide both the main element and the sub element if necessary.
   */
  this.getCtrlForStyleChg = function(id) {
    var el = STORAGE.getElement(id);

    if(!el) {
      return el;
    }
    
    switch(el.tagName){
      case 'INPUT':
      case 'TEXTAREA':
      case 'A':
        break;
      // fix 2188
      case 'DIV':
        // richtext div...get control element
        if(el.className.indexOf('dijitEditor') > -1){
            break;
        }
      default:
        return el;
    }

    // it is an INPUT it can be either attribute or description.

    // at this point parent is either null OR the TR/TABLE representing the control (TABLE if its for a tab)
    var parent = DOM.getControlElement(el);

    if(parent) {
      // amahen: probably broke 7.5.0.0 DOM here (desc tables were necessary)
      el = parent;
    }
    return el;
  }

  /**
   * Remove the style for the specified element. This removes the styleid from the styleQ and removes the Q if the Q is empty Apr 9, 2008 SN: Bug# 979. Speed up
   * DisplaySetting rule. define a separate method that takes the element (rather than id).
   */
  this.removeStyleEl = function(el, styleId, styleTLV) {
    var styleQ = FIELDS.getStyleQ(el);
    if(!isnull(styleQ)) {
      styleQ.removeStyle(styleId, styleTLV);
      if(styleQ.isEmpty()){
        FIELDS.removeStyleQ(el);
      }
    }
  }
  
  /**
   * Configure the style for the element. This will either reset the style or set the style depending on isResetStyle.
   */
  this.configureStyle = function(elId, styleId, styleTLV, isResetStyle){
    // nothing to set/reset
    if(!styleTLV || trm.size(styleTLV) < 1){
      return;
    }
    
    var el = this.getCtrlForStyleChg(elId);

    if(!el){
      return;
    }

    var input = STORAGE.getElement(elId);
    // amahen: description input of this
    if(input && input.tagName == 'INPUT'){
      var temp = DOM.getComponent(el, 'desc');
      if(temp == input) {
        styleTLV = FIELDS.updateStyleAsDesc(styleTLV);
      }
    }
    
    // remove the style
    if(isResetStyle){
      // amahen: removed part of fix 1690. This prevents the ability to mix styling for control and dataattr (the removed code would undo all styles done by the other)
      this.removeStyleEl(el, styleId, styleTLV);
    }
    
    // add the style (create the style Q if necessary)
    else{
      this.addStyleEl(el, styleId, styleTLV);
    }
    
  }
  
  /**
   * Adds the style to the elements specified in content.
   */
  this.addStyleForStyleId = function(content,styleId) {
    // all adding of style, goes thru this method.
    var elIdArr = content.ids;
    
    for( var i = 0; i < elIdArr.length; i++) {
      this.configureStyle(elIdArr[i].trim(), styleId, content.resetHash, true);
      this.configureStyle(elIdArr[i].trim(), styleId, content.setHash, false);
    }
    
    // amahen: quick fix for their broken menus in smart cloud (can't hide mxactions in folders)
    // fix 2131
    if(elIdArr.length == 0 && content.vlabels){
      // get all sub menus
      var submenus = getElementsByClassName('subNavMenus', 'UL');
      
      // safety first
      if(!submenus){
        return;
      }
      
      var ids = new Object();
      
      // later uls are more recent so iterate backwards
      for(var i = submenus.length - 1; i > -1; i--){
        
        // safety first
        if(!submenus[i]){
          continue;
        }
        
        // sub menu already exists...remove it from DOM so it doesn't interfere with menus
        if(ids[submenus[i].id]){
          
          // safety check
          if(!submenus[i].parentNode){
            continue;
          }
          
          submenus[i].parentNode.removeChild(submenus[i]);
        }
        else{
          ids[submenus[i].id] = submenus[i];
        }
      }
    }
  }
  
  /**
   * Add the style from the content (content is a JSON string with element ids and the styles to set/reset)
   */
  this.addStyle = function(content) {
    this.addStyleForStyleId(content,TRM_STYLE);
  }
  
  /**
   * Hids a tab specified in content. content is a well formed JSON string with tab id and the visibility set/reset
   */
  this.hideTab = function(content) {
    this.addStyleForStyleId(content,TRM_HIDETAB);
  }
  
  
  // bug 621: Add ability to hide a table column using a rule
  // This method changes the column style. It needs to be told
  // Which table to change and which set of column numbers to change
  // and it will apply the specified style to the corr. cell in
  // each row of the table.
  this.addColStyle = function(content) {
    /*
     * content for column style change looks like this: "colNos":[7] "tbodRid":"mx171_0" "resetHash":{} "setHash":{"container.style.backgroundColor":"red"}
     */     
    // the tablebody control looks like this
    // <TABLE class='tbod'>
    // <TBODY>
    // <TR> .... each TR maps to one row in the browser screen including
    // title and filter box.
    var tbody = STORAGE.getElement(content.tbodRid);
    if(isnull(tbody)) {
      trm.error("Didn't find tablebody " + content.tbodRid);
      return;
    }

    // fix 4304: moved the selectRowExists logic out of the row for loop...only need to check the header row (7.6.1.2 removed the attribute we flagged off)
    // fix 1940: col count changes (MINUS 1) when select check are showed
    var selectRowExists = 0;
    var hrow = tbody.rows.length ? tbody.rows[0] : undefined;
    if(hrow && hrow.cells[0] && hrow.cells[0].id && hrow.cells[0].className && ((new RegExp("(^|\\s)tc(\\s|$)")).test(hrow.cells[0].className))){
      // fix 2593
      if(((new RegExp("(^|\\s)hlsel(\\s|$)")).test(hrow.cells[0].className))){
        selectRowExists = 1;  
      }
    }

    for(var i =0;i<tbody.rows.length;i++) {
      // for each row in the table....
      // retrieve the list of cells corr. to the column numbers
      // specified.
      var row = tbody.rows[i];
      
      for (var j = 0;j<content.colNos.length;j++) {
        var colNo = content.colNos[j];
        
        if(selectRowExists){
          colNo = colNo - selectRowExists;
        }
        if(row.cells.length <= colNo) {
          continue;
        }        
        var cell = row.cells[colNo];

        this.removeStyleEl(cell,TRM_STYLE);
        
        // set style via id (this can only be done when there is no select box
        if(!selectRowExists){
          this.addStyleEl(cell, TRM_STYLE, content.setHash );
        }
        
        // all cells have same id when there is a select box (can't do by id...don't worry about caching it to remove later)
        else{
          this.trmChgStyle.exec(cell, content.setHash);
        }
        
      }// for each column number in the list.
    }// for each row in the table.
  }// addColStyle.
  
  
}// trm.displayproperty.Util

/**
 * Static method to reset all values.
 * 
 * @return styleTLV will all values reset
 */
trm.displayproperty.Util.resetAllValues = function(styleTLV) {
  // styleTLV is { type1 : value1, type2 : value2 }
  // retval is { type1 : }
  var retVal = {};
  
  // note this is slow
  for(type in styleTLV) {
    retVal[type] = "";
  }  
  return retVal;
}

/***************************************************************************************************************************************************************
 * trm.displayproperty.Decoder: This object decodes the command parameters sent by the jsp and calls appropriate functions.
 **************************************************************************************************************************************************************/
trm.displayproperty.Decoder = function(trmUtil) {
  this.trmUtil = trmUtil || "";
  this.trmRedirect = new trm.displayproperty.Redirect();
  this.exec = function(paramStr) {
    
    // execute actions encoded in the parameter string.
    var paramArr = eval(paramStr);

    /*
     * paramArr is an array of JsParam that is sent across from UI to browser. Structure of JsParam is as follows: direction : 0 //TOBROWSER msgType :
     * DISP_HIDE_TAB, DISP_CHGSTYLE_CNTRL etc. content { ids : [ "id1", "id2",...] setHash : { textbox.style.backgroundColor : red .... } resetHash : ,, }
     */
    if(!isnull(paramArr)) {

      // starting from the end (all resets are at the end)
      // move up the list.
      // amahen: fix 1630 we now should iterate in the correct order or this breaks things (second part of the bug)
      // for( var i = paramArr.length-1; i >=0; i--) {
      for( var i = 0; i < paramArr.length; i++) {
        var content = paramArr[i].content;
        switch(paramArr[i].msgType) {
          case 5:
            FIELDS.setRequiredStyle(content);
            break;
          case 6:
            FIELDS.setReadOnlyStyle(content);
            break;
          // setting a filter field to required
          case 13:
            FIELDS.FILTERS.setRequired(content);
            break;
          // put the new style
          case 4:
            this.trmUtil.addStyle(content);
            break;
          // hide tab.
          case 1:
            this.trmUtil.hideTab(content);
            break;
          // redirect
          case 7:
            this.trmRedirect.exec(content);
            break;
          // alert
          case 8:
            alert(content.message);
            break;
          // eval
          case 9:  
            eval(content.command);
            break;
          // column style change.
          case 10:
            this.trmUtil.addColStyle(content);
            break;
          // tab ordering.
          case 11:
            FIELDS.setFocusOrder(content);
            break;
          // selected input styling
          case 12:
            FIELDS.setSelectedStyle(content);
            break;
          default:
            trm.warn("MsgType:  " + paramArr[i].msgType + " invalid!");
        }
      }
    } else {
      trm.warn("Invalid JsParam array: " + paramStr);
    }
  }
}// trm.displayproperty.Decoder

/** ********************BEGIN EXPORTED OBJECTS***************************** */

/***************************************************************************************************************************************************************
 * trm.displayproperty.Controller : top level object used to issue all javascript commands.
 **************************************************************************************************************************************************************/
trm.displayproperty.Controller = function() {
  // this.urlPrefix = 'http://swami:83/maximo/webclient/components/rmmessenger.jsp?';
  // this.urlPrefix = 'http://swami:83/maximo/webclient/smartbrowser/rmmessengertest.jsp?';
  this.trmUtil = new trm.displayproperty.Util();
  this.decoder = new trm.displayproperty.Decoder(this.trmUtil);
  this.paramStr = null; // past commands that are to be reissued on refresh.

  this.constructor = function() {
  }

  this.setParam = function(paramStrVal) {
    // returns true iff the command
    // stored internally was changed.
    if(paramStrVal == this.paramStr) {
      // Bug.... sometimes we need to apply this even when parameters are the same.
      return false;
    }
    this.paramStr = paramStrVal;
    return true;
  }

  /**
   * Iterates the StyleQMap (array of currently active style Qs) and applys all styles.
   */
  this.applyFieldStyles = function() {
    
    // first apply all styles for controls with styles
    this.applyStyleQs();
    
    // only iterate controls with style qs
    if(!FIELDS.readOnlyStyle && !FIELDS.requiredStyle){
      return;
    }
    
    // apply the highlights
    this.configureHighlighting(true);
      
   }
  
  /**
   * Configures the highlights using the specified apply/unapply method
   * 
   * @param configMethod
   *          either applyHighlights or unapplyHighlights
   */
  this.configureHighlighting = function(apply){
    // quick exit
    if(!FIELDS.requiredStyle && !FIELDS.readOnlyStyle){
      return;
    }
    
    // need to iterate every control since we are applyign ro/req styles
    var flds = FIELDS.getAllFields();
    var controls = FIELDS.getFilterControls();
    if(controls){
      flds = flds.concat(controls);
    }
    for( var i = 0; i < flds.length; i++) {
      try{
        if(apply){
          this.applyHighlights(flds[i]);
        }else{
          this.unapplyHighlights(flds[i]);
        }
      }catch(e){
        // this happens for filter fields being replaced...no biggie just go on
        continue;
      }
    }
  }
  
  /**
   * Undo any highlightling
   */
  this.unapplyHighlights = function(imagediv){
    
    // sanity check
    if(!imagediv){
      return;
    }
    
    // unconfigure required
    if(FIELDS.requiredStyle){
      
      // field is not required...undo styles if we applied any
      if(!FIELDS.isRequired(imagediv, true)){
        var input = DOM.getInputElement(imagediv);
        var control = FIELDS.getControl(imagediv);
        var table = DOM.getTableForFilter(imagediv);
        
        // filter inputs aren't replaced by their hidden frame so we need to undo the style here
        if(input && input.isfilter){
          this.trmUtil.trmChgStyle.exec(input, trm.displayproperty.Util.resetAllValues(FIELDS.requiredStyle[0]));

        }
        this.trmUtil.trmChgStyle.exec(control, trm.displayproperty.Util.resetAllValues(FIELDS.requiredStyle[1]));
      }
    }
  }
  
  /**
   * Configure any display setting highlights (required/readonly)
   */
  this.applyHighlights = function(imagediv){
    
    // sanity check
    if(!imagediv){
      return;
    }
    
    // fix 1632: filter field!
    if(imagediv.filterrowid){
      
      // filter fields that start as hidden (in some single page apps) are replaced when shown...account for this element swap
       if(STORAGE.getElement(imagediv.id) != imagediv){
         
         // *remove from inputs
         var i = -1;
         FIELDS.getFilterInputs().forEach(function(element,index,array){
           if(element == imagediv){
             i = index;
           }
         });
         
         // essential removing it from array
         if(i != -1){
           FIELDS.getFilterInputs()[i] = undefined;
         }
         
         // set it required
         FIELDS.FILTERS.setFilterFieldRequired(STORAGE.getElement(imagediv.filterrowid), STORAGE.getElement(imagediv.id));
         // and use this now instead
         imagediv = STORAGE.getElement(imagediv.id);
       }
    }
    
    var input = DOM.getInputElement(imagediv);
    var control = FIELDS.getControl(imagediv);
    var desc = DOM.getComponent(imagediv, 'desc');
    
    // configure required
    if(FIELDS.requiredStyle){
      if(FIELDS.isRequired(input, true)){
        this.trmUtil.trmChgStyle.exec(input, FIELDS.requiredStyle[0]);
        this.trmUtil.trmChgStyle.exec(control, FIELDS.requiredStyle[1]);
      }
    }
    
    // configure readonly
    if(FIELDS.readOnlyStyle){
      if(FIELDS.isReadOnly(input)){
        this.trmUtil.trmChgStyle.exec(control, FIELDS.readOnlyStyle[1]);
        if(input && input.tagName != 'A'){
          this.trmUtil.trmChgStyle.exec(input, FIELDS.readOnlyStyle[0]);
        }
      }
      // fix 2823: desc are losing readonly styles when selected then unselected
      if(desc && FIELDS.isReadOnly(desc)){
        this.trmUtil.trmChgStyle.exec(desc, FIELDS.readOnlyStyle[0]);
      }
    }
  }
  
  /**
   * Apply all Queued styles
   */
  this.applyStyleQs = function(){
    var map = FIELDS.getStyleQMap();
    for( var i = 0; i < map.length; i++) {
      var q = map[i];
      if(!q){
        continue;
      }
      q.applyQueuedStyles();
    }
   
  }
  

  this.decode = function() {
    if(!isnull(this.paramStr)) {
      this.decoder.exec(this.paramStr);
      this.paramStr = "";
      return true;
    }
    return false;
  }

  this.fireEvents = function(params) {
    // before doing anything..convert RMSTYLE cssclasses
    DOM.replaceRMSTYLES();
    
    var url = top.document.trm.rootPath + "/components/rmmessenger.jsp?";

    // TEMPORARY is this needed on every fire.
    // request command string.
    var XMLHttp = new trm.util.Util.XMLHttpRequest(this);
    url = trm.util.Util.addAttr(url, "rmaction", "getjsparams");

    // every request is unique,
    // adding this attribute will avoid the browser caching issues.
    url = trm.util.Util.addAttr(url, "requestTime", (new Date()).valueOf());

    // add the sessionuid etc
    url = trm.util.Util.addAttr(url, "uisessionid", top.document.trm.uisessionid);

    // Bug# 1384. Style changes need to be supported in dialog.
    // Copy the buimessengerid that was sent into the callback request.
    // add all the parameters that were passed in.
    for( var key in params) {
      url = trm.util.Util.addAttr(url, key, params[key]);
    }

    XMLHttp.requestData(url);
    XMLHttp.addObserver(this);
  }

  // CALLBACKS FROM THE XMLHTTPREQUEST Object.
  this.processResponseXML = function(me, responseXML) {
  }

  /**
   * 
   */
  this.processResponseText = function(me, responseText) {
    // fix 2906: our vlabels setting from server broke...this works better anyway
	// fix 4233: iot18 vlabels adapted to act like previous vert. labels...disabled fix 3610
    DOM.verticallabels = DOM.readBoolean(window.VERTLABELS);
    // fix 3610: iot18 so could be dynamic not vert
    if(DOM.verticallabels && SKIN.indexOf("iot18") > -1){
      if(document && document.getElementById('labelcsslink')){
    	  var lbllink = document.getElementById('labelcsslink');
    	  if(lbllink && lbllink.href && lbllink.href.match(/dynamic.css$/)){
    		  DOM.verticallabels = false;
    	  }
      }
    }

    // clear anything that was stored because it may have changed
    STORAGE.clear();
    // unconfig highlighting (config after proc)
    this.configureHighlighting(false);
    
    if(responseText)
      responseText = responseText.trim();
    if(!isnull(responseText)) {
      // there is some commands issued.
      this.paramStr = responseText;
      this.decode();
    }

    // extend functions if not already extended.
    var e = top.document.trm.extend.JsExtend;
    // we check if its extended in the fn
    e.extendFn();
    
    // restore styles that maximo may have changed
    this.applyFieldStyles();
      
    // restore field focus if appropriate
    this.restoreFocus(STORAGE.focusid);
  }
  
  /**
   * Restores field focus appropriately (because required fields may have changed or we may have lost focus to our field due to I.E)
   */
  this.restoreFocus = function(focusid) {
    
    // had a focus event right before we ajax'd
    if(STORAGE.getPersistent('focusevent')){
      
      var prevEvent = STORAGE.getPersistent('focusevent');
      
      // clear out the event so we don't keep coming in here
      STORAGE.clearPersistent();
      
      // check if my focus event should change
      var event = new FieldFocusEvent(prevEvent.currentId);
      if(event.getFirstRequired() != prevEvent.getFirstRequired()){
        focusItem(event.getFirstRequired());
        return;
      }
    }
    
    if(isnull(focusid)) {
      return;
    } 
        
    // Bug# 1310. Tabbing out of a field with display rules on it doesn't shift focus to the next field in IE.
    // set the focus back to the element maximo set to.
    if(dojo && dojo.isIE) {
      focusItemNow(focusid);
    }
  }
  
  /**
   * 
   */
  this.highlightSelected = function(component){
    // no rule
    if(!STORAGE.selectedStyle || component.tagName == 'IMG' || (component.getAttribute && component.getAttribute('ctype') == 'toggleimage')){
      return;
    }
    
    this.trmUtil.trmChgStyle.exec(component, STORAGE.selectedStyle[0]);

    var control = DOM.getControlElement(component);
    this.trmUtil.trmChgStyle.exec(control, STORAGE.selectedStyle[1]);

    // highlight row
    if(component.id && component.id.match(/\[R[:]\d+\]/)){
      var row = DOM.getRow(component);
      this.trmUtil.trmChgStyle.exec(row, STORAGE.selectedStyle[1]);
    }
  }
  
  /**
   * 
   */
  this.unhighlightSelected = function(component){
    if(!STORAGE.selectedStyle || component.tagName == 'IMG' || (component.getAttribute && component.getAttribute('ctype') == 'toggleimage')){
      return;
    }
    var resetStyle = trm.displayproperty.Util.resetAllValues(STORAGE.selectedStyle[0]);
    this.trmUtil.trmChgStyle.exec(component, resetStyle);
    
    var table;
    var control;
    
    control = DOM.getControlElement(component);
    this.trmUtil.trmChgStyle.exec(control, trm.displayproperty.Util.resetAllValues(STORAGE.selectedStyle[1]));

    // unhighlight row
    if(component.id && component.id.match(/\[R[:]\d+\]/)){
      var row = DOM.getRow(component);
      this.trmUtil.trmChgStyle.exec(row, trm.displayproperty.Util.resetAllValues(STORAGE.selectedStyle[1]));
    }


    // reconfig the req/readonly
    if(!component.isfilter){
      
      // 7.6
      if(control){
        var q = FIELDS.getStyleQ(control);
        if(q){
          q.applyQueuedStyles();
        }
        
        // fix 2823: highlight req/ro
        this.applyHighlights(control);        
      }

    }
    // its a filter field just do txt box
    else {
      component = component.parentNode;
      while(component && !component.filterrowid){
        component = component.parentNode;
      }
      this.unapplyHighlights(component);
      this.applyHighlights(component);
    }
    //3668-put the style back on the field for de2
    DOM.replaceElementRMSTYLES(component);
  }

  // construct this
  this.dummy = this.constructor();
} // trm.displayproperty.Controller

/** ********************END EXPORTED OBJECTS***************************** */

/** ********************BEGIN INITIALIZATION***************************** */

if(trm.smartbrowser == 'enabled') {

  if(!top.document.trm)
    top.document.trm = {};
  if(!top.document.trm.displayproperty)
    top.document.trm.displayproperty = {};
  if(!top.document.trm.extend)
    top.document.trm.extend = {};

  if(!top.document.trm.displayproperty.Controller) {
    // Create a new instance of the top level handler (once).
    // This object is used to issue any commands.
    // Comment this line to turn all style changes off.
    top.document.trm.displayproperty.Controller = new trm.displayproperty.Controller();
  }

  if(!top.document.trm.extend.JsExtend) {
    top.document.trm.extend.JsExtend = new trm.extend.JsExtend();
  }

} /* trm.smartbrowser == 'enabled' */
/** ********************END INITIALIZATION***************************** */

