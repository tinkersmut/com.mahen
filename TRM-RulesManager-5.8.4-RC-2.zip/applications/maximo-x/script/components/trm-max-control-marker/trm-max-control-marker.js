 Polymer({
   is: 'trm-max-control-marker',
   behaviors: [BaseComponent],
   properties: {
     comprules: {
       type: Object,
       notify: true,
     },
   },
   listeners: {},
   created: function() {

   },
   ready: function() {

   },
   attached: function() {

   },
   /**
    * checks if there are UI rules in the comprules json property
    * @return true when this.comprules.ui.length > 0
    */
   hasUIRules: function() {
     if (!this.comprules) {
       return false;
     }
     if (!this.comprules.ui) {
       return false;
     }
     return this.comprules.ui.length > 0;
   },
   /**
    * checks if there are MBO rules in the comprules json property
    * @return true where this.comprules.mbo.length > 0
    */
   hasMBORules: function() {
     if (!this.comprules) {
       return false;
     }
     if (!this.comprules.mbo) {
       return false;
     }
     return this.comprules.mbo.length > 0;
   },

 });