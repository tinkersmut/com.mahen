Polymer({
  is: 'trm-max-data',
  behaviors: [BaseComponent],
  properties: {
    /**
     * Set to true on this element to not cache data. Caches by default
     */
    noCache: {
      type: Boolean,
      value: false,
      notify: true
    },

    /**
     * Number of records per page when fetching an ObjectStructure. Defaults to All records (only 1 page)
     */
    recordsPerPage: {
      type: Number,
      value: 0
    },

    /**
     * Internal prefix added to url path to access OSLC scripts for GET or POST
     */
    urlPath: {
      type: String,
      notify: true,
      value: '/oslc/wcc/'
    },
    /**
     * This defaults to the action. The key used in the localStorage to hold this cache
     */
    key: {
      type: String,
      notify: true
    },
    /**
     * This is unique to the user. Defaults to the mxauth header. When it changes it will clear key (reset the data cache)
     */
    _session: {
      type: String,
      notify: true
    },
    /**
     * Data fetched from the server via ajax
     */
    _response: {
      type: Object,
      notify: true,
      observer: '_handleResponse'
    },
    /**
     * HTTP method. Defaults to 'GET'
     */
    method: {
      type: String,
      value: 'GET',
      notify: true
    },
    /**
     * OSLC Action being called on the server. ex: 'XDRD'
     */
    action: {
      type: String,
      notify: true
    },
    /**
     * Query paramaters added to URL for fetch
     */
    params: {
      type: Object,
      notify: true,
      value: function() {
        return {};
      }
    },
    /**
     * Data response from the server
     */
    data: {
      type: Object,
      notify: true,
      observer: '_dataUpdated'
    },
    /**
     * TRUE if this will automatically generateRequest when action is set
     */
    auto: {
      type: Boolean,
      value: false,
    },
    /**
     * FALSE only when fetching from Maximo native REST
     */
    _iswcc: {
      type: Boolean,
      value: true
    }

  },
  observers: ['_updateServerDetails(action,urlPath)'],
  created: function() {

  },
  ready: function() {
    this._configureHeaders();
    this._relogin = true;
  },
  attached: function() {

  },
  /**
   * Called whenever the _response is set. Does nothing if caching...sets data if no-caching
   */
  _handleResponse: function(response) {
    if (this.noCache) {
      this.data = response;
    }
  },
  _configureHeaders: function() {
    // <7.6.0.7
    if (this.$.myauthenticator.getAuthenticationHeader) {
      this.$.rmConn.headers = this.$.myauthenticator.getAuthenticationHeader();
      this._session = this.$.myauthenticator.getAuthenticationHeader();
    }
    // >=7.6.0.8
    else {
      this.$.rmConn.headers = {
        csrftoken: $M.getCSRFToken()
      }
      this._session = $M.getCSRFToken();
    }

  },
  _updateServerDetails: function() {
    if (!this.action) {
      return;
    }
    this._configureHeaders();
    this.key = this.action;
    this._url = this._getBaseUri() + this.urlPath + this.action;
    this._relogin = true;
    // fetch
    if (this.auto) {
      this.send();
    }
  },
  
  /**
   *  Mechanism for getting uri to maximo server. The authenticator may have lost its members, so always check the session too
   */
  _getBaseUri: function(){
    if(this.$.myauthenticator.getBaseUri() === undefined){
      if($M && $M.getMaxauth()){
        return $M.getMaxauth().baseUri;
      }
      // hard code it?
      console.log("Unable to find base uri to Maximo server. ",$M);
    }
    return this.$.myauthenticator.getBaseUri();
  },
  _dataUpdated: function() {
    if (!this.data || !this._resolve) {
      return;
    }
    if (this._iswcc && !this.data.success) {
      this._reject(this.data.message);
    } else {
      this._resolve(this.data);
    }
  },
  /**
   * Generates a request to the server
   */
  send: function() {
    this._resolve = undefined;
    this._reject = undefined;
    return new Promise(this._send.bind(this));
  },
  _send: function(resolve, reject) {
    this._resolve = resolve;
    this._reject = reject;
    this.$.rmConn.generateRequest();
  },

  /**
   * Post content to server
   */
  post: function(content) {
    this.method = 'POST';
    this.$.rmConn.contentType = 'application/json';
    this.$.rmConn.body = content;
    return this.send();
  },
  /**
   * Handles an ajax error from the server
   */
  _processError: function(e) {
    if (this._reject) {
      var error = e;
      if (e.detail && e.detail.error)
        error = e.detail.error;
      this._reject(error);
    }
  },
  /**
   * Get the maximo-collection used to fetch/create records
   * 
   * @param detailHref (optional) String uri to the details collection. When passed this will create a temporary collection for the details set
   * @return maximo-collection
   */
  _getCollection: function(detailHref) {
    if (detailHref) {
      const details = Polymer.Base.create('maximo-collection', {
        id: 'detailscollection'
      });
      details.pageSize = this.recordsPerPage;
      details.selectedQueryName = 'All';
      details.collectionUri = detailHref;
      // amahen: deep copy
      details.creationInfo = Array.from(this._collection.creationInfo, info => Object.assign({}, info));
      // hard coded path to detail
      details.creationInfo[0].href = detailHref;

      details.queryInfo = Array.from(this._collection.queryInfo, info => Object.assign({}, info));
      return details;
    }
    if (!this._collection) {
      this._collection = Polymer.Base.create('maximo-collection', {
        id: 'mycollection'
      });
      this._collection.pageSize = this.recordsPerPage;
      this._collection.selectedQueryName = 'All';
    }
    return this._collection;
  },

  /**
   * Fetch a set of records (object structure)
   * 
   * @param osName
   *          String name of the object structure
   * @param attributes
   *          (optional) String csv of attribute names to fetch
   * @param queryName
   *          (optional) String to use (filters data, defaults to All)
   * @param qbe
   *          (optional) Object with attribute:value pairs ex({attribute:'USEWITH',value:'INTEGRATION'})
   * @param orderby
   *          (optional) String name of attributes to order by (asc or desc) ex('%2Bintobjectname' = +intobjectname)
   * @param additionalParams
   *          (optional) Array of strings to add as params (sets the additional params) ex: ['internalvalues=1']
   * @param advWhere
   *          (optional) Array of {field:String,filtertype:'SIMPLE'/'DATERANGE',availablevalues:[{selected:true,value:String}]} to add as params (sets the additional params) ex: ['internalvalues=1']
   */
  fetchOS: function(osName, attributes, queryName, qbe, orderby, additionalParams, advWhere) {
    const maxCollection = this._getCollection();
    maxCollection.objectName = osName;
    maxCollection.attributeNames = attributes;
    maxCollection.selectedQueryName = queryName === undefined ? 'All' : queryName;

    // make sure we cache each os by name if not specified
    if (!this.key) {
      this.key = `${osName}_${maxCollection.selectedQueryName}`;
    }

    maxCollection.pageSize = this.recordsPerPage;
    if (qbe) {
      maxCollection.keySearchAttributeName = qbe.attribute;
      maxCollection.keySearch = qbe.value;
    }
    if (orderby) {
      maxCollection.orderByAttributeNames = orderby;
    }
    if (additionalParams) {
      // this only affects creation of records
      if (additionalParams.filter(param => param.indexOf('internalvalues=1')).length) {
        maxCollection.addInternalValues = true;
      }
      // caching in indexdb... tell sw to noCache if nec
      if (!this.noCache) {
        additionalParams.push('_skipsw=true');
      }
    }

    // caching in indexdb... tell sw to noCache if nec
    else if (!this.noCache) {
      additionalParams = ['_skipsw=true'];
    }

    maxCollection.additionalParams = additionalParams;
    if (advWhere) {
      maxCollection.filterData = advWhere;
    }
    return maxCollection.refreshRecords().then(data => {
      this._response = maxCollection.collectionData;
      return this._response;
    })
  },

  /**
   * Refreshes a record in the object structure. This will make an attempt to replace the record in cached data collection (the set)
   * 
   * @param record
   *          Object the record from the fetchOS collection. Its assumed this record came from the collection returned from fetchOS
   */
  reloadOSRecord: function(record) {
    // for merge need index
    var i;
    if (this._response) {
      this._response.forEach(function(mbo, index) {
        if (mbo.href === record.href) {
          i = index;
        }
      });
    }

    var self = this;
    const attributeNames = this._getCollection().attributeNames;
    return new Promise(function(resolve, reject) {
      const resource = self._getResource(record);

      // remove it so attributeNames won't screw up future resource stuff
      self._clearResource();

      resource.attributeNames = attributeNames;
      resource.loadRecord().then(function(newrec) {
        if (i !== undefined) {
          self._response[i] = newrec;
        }
        resolve(newrec);
      }, function(err) {
        reject(err);
      });
    });

  },
  
  /**
   * Creates a record for the objectstructure fetched in the fetchOS method. NOTE: fetchOS must have been called before this method.
   * 
   * @return Promise
   */
  createOSRecord: function(record, returnFields, detailHref) {
    const maxCollection = this._getCollection(detailHref);

    // amahen: pulled from _processRecordCreateResponse in maximo-collection...make same as event.detail for record-create event
    const createSuccess = xhr => {
      return xhr.response;
    };

    // amahen: pulled from _processrecordCreateError in maximo-collection...they reject with event.detail
    const createFail = event => {
      return event.request.xhr.response;
    };
    if (!Array.isArray(record)) {
      record._action = 'Add';
    }
    const merge = detailHref !== undefined;
    return maxCollection.createRecord(record, returnFields).then(createSuccess).catch(createFail);
  },
  
  /**
   * Changes the status of the specified record
   * 
   *@param record is the the record to change the status of
   *@param tostatus the status to change to
   *@param memo the value of the memo field
   *@param date (optional) date to use for status change (defaults to now)
   */
  changeStatus: async function(record, tostatus, memo, date){
    const params = {
        'status': tostatus,
        'date': date,
        'memo': memo
      };
    return this.actionForRecord(record, 'wsmethod:changeStatus', params, 'status');
  },

  /**
   * Call the action for the specified record 
   * 
   * @param record
   * @param params
   * @param action
   * @param responseProperties
   * @param method
   * @returns
   */
  actionForRecord: async function(record, action, params, responseProperties, method){
    const resource = this._getResource(record);
    return resource.updateAction(action, params, responseProperties, method);
  },

  /**
   * Updates a details record for the specified parentRecord
   * 
   * @param parentRecord Object with the details collectionref (ex: record from fetchOS result)
   * @param detailName String name of the detail (ex: assetaudit when attributes in fetchOS includes assetaudit{*})
   * @param record Object with field values for the new record to update
   * 
   * @return Promise
   */
  updateDetailRecord: async function(parentRecord, detailName, record) {
    record._action = 'Change';
    const maxCollection = this._getCollection();
    const info = {
      'object': detailName,
      'href': parentRecord.href
    }
    return maxCollection.updateChildRecord(record, info);
  },
  
  /**
   * Creates a details record for the specified parentRecord
   * 
   * @param parentRecord Object with the details collectionref (ex: record from fetchOS result)
   * @param detailName String name of the detail (ex: assetaudit when attributes in fetchOS includes assetaudit{*})
   * @param newRecord Object with field values for the new record to create
   * 
   * @return Promise
   */
  createDetailRecord: async function(parentRecord, detailName, newRecord) {
    newRecord._action = 'Add';
    const maxCollection = this._getCollection();
    const info = {
      'object': detailName,
      'href': parentRecord.href
    }
    return maxCollection.createChildRecord(newRecord, info);
  },

  /**
   * Delete a details record for the specified parentRecord
   * 
   * @param parentRecord Object with the details collectionref (ex: record from fetchOS result)
   * @param detailName String name of the detail (ex: assetaudit when attributes in fetchOS includes assetaudit{*})
   * @param record Object with field values for the new record to delete
   * 
   * @return Promise
   */
  deleteDetailRecord: async function(parentRecord, detailName, record) {
    const res = this._getResource(parentRecord);
    return res.deleteRecord(record.localref);
  },
  
  _getResource: function(record) {
    if (!this._resource) {
      this._resource = Polymer.Base.create('maximo-resource', {
        resourceUri: record.href
      });
    }
    this._resource.resourceUri = record.href;
    return this._resource;
  },
  
  _clearResource: function(){
    if(this._resource){
      delete this._resource;
    }
  },

  /**
   * Updates a record in the object structure. This will make an attempt to replace the record in cached data collection (the set)
   * 
   * @param record
   *          Object the record from the fetchOS collection. Its assumed this record came from the collection returned from fetchOS
   */
  updateOS: function(record) {
    // for merge need index
    var i;
    if (this._response) {
      this._response.forEach(function(mbo, index) {
        if (mbo.href === record.href) {
          i = index;
        }
      });
    }

    var self = this;
    return new Promise(function(resolve, reject) {
      self._getResource(record).updateRecord(record).then(function() {
        if (i !== undefined) {
          self._response[i] = self._resource.resourceData;
        }
        resolve(self);
      }, function(err) {
        reject(err);
      });
    });

  },
  /**
   * Gets the url of the current connection
   */
  getURL: function() {
    return this.$.myauthenticator.getBaseUri();
  },

  /**
   * Get the MBOSET as a REST request. Will resolve to an Array of records (fieldnames:value) and sets this.count and this.total pulled from response
   * 
   * @param mboname
   *          String name of the mbo set to fetch
   * @param params
   *          Object (optional) {param:value} for ex: {'ersonid':'WILSON'}. This can include the following extra params: _orderby, _orderbyasc,_orderbydesc,
   * @param fieldlist
   *          String (optional) csv of field names to download
   * @param excludefields
   *          String (optional) csv of field names to not download
   * @param start
   *          Number (optional) record to start fetching at (for paging)
   * @param max
   *          Number (optional) max number of Items to fetch
   */
  fetchSet: function(mboname, params, fieldlist, excludefields, start, max) {
    // disable this for now
    if (this.auto) {
      this.auto = false;
    }
    if (params === undefined) {
      params = {};
    }

    params['_format'] = 'json';
    params['_compact'] = 1;
    // _rsStart & _maxItems
    if (start !== undefined) {
      params['_rsStart'] = start;
    }
    if (max !== undefined) {
      params['_maxItems'] = max;
    }

    if (fieldlist !== undefined) {
      params['_includecols'] = fieldlist;
    }
    if (excludefields !== undefined) {
      params['_excludecols'] = excludefields;
    }

    this.urlPath = '/rest/mbo/';
    this.params = params;
    this.action = mboname;

    //    const start = 'rsStart';
    const count = 'rsCount';
    const total = 'rsTotal';

    const name = `${mboname}MboSet`;

    return new Promise((resolve, reject) => {
      this._iswcc = false;
      this.send().then(response => {
        // format
        this.count = 0;
        this.total = 0;

        if (!response[name]) {
          resolve([]);
          return;
        }

        this.count = response[name][count];
        this.total = response[name][total];

        resolve(response[name][mboname]);
      }).catch(err => {
        reject(err);
      });
    });
  },
});