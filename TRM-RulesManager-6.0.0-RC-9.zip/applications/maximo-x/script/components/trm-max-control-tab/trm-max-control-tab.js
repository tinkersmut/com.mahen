Polymer({
  is: 'trm-max-control-tab',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {
    tabheader: {
      type: Boolean,
      notify: true,
      value: false
    }
  },
  listeners: {},
  created: function() {

  },
  ready: function() {},
  attached: function() {

  },
  _tabclick: function() {
    console.log("tab clicked");
  }


});