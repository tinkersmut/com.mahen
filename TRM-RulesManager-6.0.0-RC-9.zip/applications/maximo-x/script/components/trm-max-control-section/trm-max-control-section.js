 Polymer({
   is: 'trm-max-control-section',
   behaviors: [BaseComponent, ControlBehavior],
   properties: {
     underTable: {
       type: Object,
       value: function() {
         return null;
       },
       notify: true
     }
   },
   listeners: {},
   created: function() {

   },
   ready: function() {

   },
   attached: function() {

   },
   isUnderTable: function() {
     if (this.underTable != null) {
       return this.underTable;
     }
     var parent = this.parentNode;
     while (parent != null && !this.underTable == true) {
       if (parent.tagName != null && parent.tagName.toLowerCase() == "trm-max-control-table") {
         this.underTable = true;
         break;
       }
       parent = parent.parentNode;
     }
     return this.underTable;
   },

 });