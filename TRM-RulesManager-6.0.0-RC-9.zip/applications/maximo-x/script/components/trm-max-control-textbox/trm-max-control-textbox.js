 Polymer({
   is: 'trm-max-control-textbox',
   behaviors: [BaseComponent, ControlBehavior],
   properties: {},
   listeners: {},
   created: function() {

   },
   ready: function() {

   },
   attached: function() {

   },
   getClass: function() {
     if (this.hasAtt(this.component, "attlength")) {
       try {
         var attlen = parseInt(this.getAtt(this.component, "attlength"));
         if (attlen > 200) {
           return " largest";
         } else if (attlen > 100) {
           return " large";
         } else {
           return " standard"
         }
       } catch (err) {
         console.log("warn: textbox - could not parse attlength");
       }
     }
     return "standard";
   },

 });
