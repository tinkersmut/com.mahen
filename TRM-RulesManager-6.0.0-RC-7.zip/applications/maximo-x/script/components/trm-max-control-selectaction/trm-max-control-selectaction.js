Polymer({
  is: 'trm-max-control-selectaction',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {},
  listeners: {},
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },

});