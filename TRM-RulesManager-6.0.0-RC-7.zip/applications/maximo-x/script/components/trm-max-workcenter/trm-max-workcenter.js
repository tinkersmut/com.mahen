Polymer({
      is: 'trm-max-workcenter',
      behaviors: [BaseComponent],
      properties: {

        /**
         * Response from server (will contain content property when fetching)
         */
        data: {
          type: Object,
          notify: true
        }
      },
      /**
       * Fetch this workscape from the server. This will overwrite existing source
       * property. name property must be set
       */
      fetch: function(name) {

        this.$.server.method = 'GET';
        // get all workcenters
        if (!name) {
          this.$.server.params = {};
        } else {
          this.$.server.params = {
            '_workscape': name
          };
        }
        return new Promise((resolve, reject) => {

          // got modified content from server
          this.$.server.send().then(data => {
            resolve(data);
          }, fail => {
            // get from war
            let requestor = Polymer.Base.create('trm-max-comprequestor', {});
            // amahen: TODO: fix hardcoding
            requestor.path = 'script/workscape/workscape-' + name.toLowerCase() + '.html';
            requestor.fetch().then(content => {

              // got modified from server
              this.data = {
                'success': true,
                'backup': true,
                'content': content
              };
              resolve(this.data);
            }, err => {
              // failed to get from war too
              reject(err);
            });
          });

        });

      },

      /**
       * @return String or undefined
       */
      getWorkCenterContent: function() {
        if (!this.data) {
          return;
        }
        return this.data.content;
      },

      /**
       * Sends the source property to be the content of the workscape file on the
       * server
       */
      send: function(name, content) {
        this.$.server.params = {
          '_workscape': name
        };
        return this.$.server.post(content);
      },

      /**
       * Save the content as the backup
       */
      backup: function(name, content) {
        this.$.server.params = {
          '_workscape': name,
          '_status': 'BACKUP'
        };
        return this.$.server.post(content);
      },

      /**
       * Save the content as the backup
       */
      activate: function(name, content) {
        this.$.server.params = {
          '_workscape': name,
          '_status': 'ACTIVE'
        };
        return this.$.server.post(content);
      },

      /**
       * Create a new workscape
       */
      create: function(name, description, iconpath) {
        this.$.server.params = {
          '_create': 'true',
          '_workscape': name,
          '_description': description,
          '_iconpath': iconpath
        };
        return this.$.server.post('NA');
      }
});