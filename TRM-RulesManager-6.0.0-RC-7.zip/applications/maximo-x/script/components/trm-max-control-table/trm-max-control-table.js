Polymer({
  is: 'trm-max-control-table',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {},
  listeners: {
    filterable: {
      type: Boolean,
      notify: true,
      value: false
    },
    expanded: {
      type: Boolean,
      notify: true,
      value: false
    },
    detailsadded: {
      type: Boolean,
      notify: true,
      value: false
    },
    detailsids: {
      type: Array,
      notify: true,
      value: function() {
        return new Array()
      }
    }
  },
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },
  listeners: {
    'maxprez-table-expand': 'expandTable'
  },
  isOtherChild: function(elem) {
    if (!this.isType(elem, 'tablebody') && !this.isType(elem, 'tabledetails')) {
      return true;
    }
    return false;
  },
  setFilterable: function(tablebody) {
    //console.log(tablebody.getAttribute("filterable"));
    if (this.hasAtt(tablebody, "filterable") && "true" == (this.getAtt(tablebody, "filterable"))) {
      this.filterable = true;
    } else {
      this.filterable = false;
    }
    return this.filterable;
  },
  expandTable: function() {
    if (!this.detailsadded) {
      for (var i = 0; i < this.children.length; i++) {
        var curr = this.children[i];
        if (curr.tagName == "tabledetails") {

          var newchild = Polymer.Base.create('trm-max-control-tabledetails', {
            'comprules': [],
            'rules': this.rules,
            'component': curr
          });
          if (this.detailsids == null) {
            this.detailsids = new Array();
          }
          this.$.tablechildren.appendChild(newchild);
          this.detailsids.push(newchild);
          this.detailsadded = true;
        }
      }
      this.expanded = true;
    } else {
      for (var i = 0; i < this.detailsids.length; i++) {
        var str = this.detailsids[i];
        var status = str.$.wrapper.style.display;
        if (status == "none") {
          str.$.wrapper.style.display = "block";
        } else {
          str.$.wrapper.style.display = "none";
        }
      }

    }
    //not needed
    return "";
  }
});