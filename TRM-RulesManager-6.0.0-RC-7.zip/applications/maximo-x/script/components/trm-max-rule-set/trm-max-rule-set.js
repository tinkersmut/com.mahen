 Polymer({
   is: 'trm-max-rule-set',
   behaviors: [BaseComponent],
   properties: {},
   listeners: {},
   created: function() {

   },
   ready: function() {

   },
   attached: function() {

   },
   /**
    * Fetch the rules from the server. 
    */
   fetch: function(names) {
     this.$.rules.method = 'GET';
     // get file hierarchy
     if (!names) {
       this.$.rules.params = {};
     }
     // get specific file contents
     else {
       this.$.rules.params = {
         '_files': names.toString()
       };
     }
     this.$.rules.action = 'XDRD';
     return this.$.rules.send();
   },

   /**
    * Get the rule hierarchy for the specified plugin
    */
   fetchPlugin: function(plugin) {
     this.$.rules.method = 'GET';
     this.$.rules.params = {
       '_plugin': plugin
     };
     this.$.rules.action = 'XDRD';
     return this.$.rules.send();
   },

   /**
    * Sends the source property to be the content of the rule file on the
    * server
    */
   send: function(name, source) {
     this.$.rules.params = {
       '_file': name
     };
     this.$.rules.action = 'XDRD';
     return this.$.rules.post(source);
   },

   /**
    * Causes the rules engine to re-read the rule file
    */
   refresh: function() {
     this.$.rules.method = 'GET';
     this.$.rules.params = {};
     this.$.rules.action = 'XDRDREFRESH';
     return this.$.rules.send();
   },
   /**
    * Gets the performance metrics
    */
   fetchPerfomanceMetrics: function() {
     this.$.rules.method = 'GET';
     this.$.rules.params = {};
     this.$.rules.action = 'XDRDPERF';
     return this.$.rules.send();
   }

 });