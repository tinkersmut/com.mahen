Polymer({
  is: 'trm-multipageeditor',
  properties: {
    selected: {
      type: Number,
      notify: true,
      observer: '_selectionChanged'
    }
  },

  ready: function() {
    let self = this;
    let obs = new MutationObserver(function(mutations) {
      let pages = mutations.filter(m => (m.addedNodes.length && m.addedNodes[0].nodeType == 1));
      if(pages.length){
          this.disconnect();
          self.pages = [].concat(...pages.map(p => Array.from(p.addedNodes)));
          self._initPages(self.pages);
      }
    });
    obs.observe(this.$.splash, {
      childList: true
    });

  },
  attached: function() {
    let pages = $j(this.$.splash).children();
    this.pages = Array.from(pages).filter(p => p.tagName.match(/multipageeditor\-page$/i));
    this._initPages(this.pages);
  },

  _initPages: function(pages) {
    Polymer.Base.toggleClass('hide', pages.length < 2, this.$.tabbar);
    if (pages.length) {
      this.selected = 0;

      // fix 3544: make sure the bar shows for initial selection
      this.async(() => {
        this.$.tabbar._tabChanged(this.$.tabbar.selectedItem);
      }, 1000);
    }
  },

  _selectionChanged: function(selection) {
    if (!this.pages) {
      return;
    }
    // update active flag on pages
    this.pages.forEach((page, i) => page.active = (i == selection));
  }

});