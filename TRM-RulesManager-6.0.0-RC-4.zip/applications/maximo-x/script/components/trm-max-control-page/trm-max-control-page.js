Polymer({
  is: 'trm-max-control-page',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {},
  listeners: {},
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },


});