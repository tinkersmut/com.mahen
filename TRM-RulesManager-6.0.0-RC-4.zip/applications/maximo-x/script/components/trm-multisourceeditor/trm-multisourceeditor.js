Polymer({
  is: 'trm-multisourceeditor',
  behaviors: [BaseComponent],
  properties: {

    /**
     * Array of JSON objects with {name: filename, content: filecontents}
     */
    pages: {
      type: Array,
      notify: true,
      value: function() {
        return [];
      },
      observer: 'setPages'
    },
    title: {
      type: String,
      notify: true
    },
    height: {
      type: Number,
      notify: true,
      observer: '_setHeight'
    },
    /**
     * TRUE only when tabs are to be hidden
     */
    _hidetabs: {
      type: Boolean,
      value: false
    }
  },
  listeners: {
    'xbuilder-editor-change': '_editorModified',
    'iron-select': '_changePage'
  },
  created: function() {

  },
  ready: function() {
    this.$.editor.addCommand({
      name: 'save',
      bindKey: {
        win: 'Ctrl-S',
        mac: 'Command-S',
        sender: 'editor|cli'
      },
      exec: function(env, args, request) {
        this.save({
          currentTarget: this.$.save
        });
      }.bind(this)
    });
    this.$.editor.addCommand({
      name: 'quit',
      bindKey: {
        win: 'Ctrl-Q',
        mac: 'Command-Q',
        sender: 'editor|cli'
      },
      exec: function(env, args, request) {
        this.close({
          currentTarget: this.$.close
        });
      }.bind(this)
    });
    this.$.editor.addCommand({
      name: 'vim',
      bindKey: {
        win: 'Ctrl-Shift-V',
        mac: 'Command-Shift-V',
        sender: 'editor|cli'
      },
      exec: function(env, args, request) {
        this.$.vim.active = !this.$.vim.active;
        this.vim({
          currentTarget: this.$.vim
        });
      }.bind(this)
    });
    if($M.workScape && $M.workScape.getHeight() > 0){
      this._setHeight($M.workScape.getHeight());
    }
    else{
      this._setHeight(window.outerHeight);
    }
    this.$.save.disabled = true;
  },
  attached: function() {
    //amahen: uncomment these for release
    this.$.editor.vim = false;
    this.$.vim.active = false;
  },
  _setHeight: function(height){
      if(height && this.$.editor){
          // tabs at bottom is 48 toolbar is 30
        this.$.editor.height = (height - 78) + 'px';
      }
  },
  /**
   * Sets the pages to be edited. Expects and array of {name: button name, icon:
   * button icon (ex: 'icons:save'), content: to be edited} objects.
   */
  setPages: function() {
    this._hidetabs = (!this.pages || this.pages.length < 2);
    this.$.tabbar.selected = 0;
    this._initEditorForPage(0);
  },
  /**
   * Called when a nav button is selected
   */
  _changePage: function(e) {
    // safety first
    if (!this.pages || !this.pages.length) {
      return;
    }
    var index = this.$.tabbar.selected;
    if (this.pages.length > index) {
      // remember cursor loc for page
      this.pages.forEach(function(page) {
        if (page.name == this.title) {
          page._cpos = this.$.editor.editor.getCursorPosition();
        }
      }, this);
      this._initEditorForPage(index);
    }
    // don't bubble
    if (e && e.stopPropagation) {
      e.stopPropagation();
    }
  },

  _initEditorForPage: function(index) {
    if (!this.pages || index >= this.pages.length || !this.pages[index]) {
      return;
    }
    // flag to disable change listener
    this._ignoreChanges = true;

    // clearly specified type
    var type = this.pages[index].type;

    // pull type from name
    if (!type) {
      type = this.pages[index].name.match(/\w+$/i)[0].toLowerCase();

      // default type is html
      if (!type) {
        type = 'html';
      }
    }

    // set mode from type
    switch (type) {
      case 'js':
        this.$.editor.mode = 'ace/mode/javascript';
        break;
      case 'xml':
        this.$.editor.mode = 'ace/mode/xml';
        break;
      case 'json':
        this.$.editor.mode = 'ace/mode/json';
        break;
      case 'py':
        this.$.editor.mode = 'ace/mode/python';
        break;
      default:
        this.$.editor.mode = 'ace/mode/html';
    }
    this.$.editor.script = this.pages[index].content;
    this.$.save.disabled = !this.pages[index].modified;
    this._ignoreChanges = false;
    this.title = this.pages[index].name;
    if (this.pages[index]._cpos) {
      this.$.editor.editor.moveCursorToPosition(this.pages[index]._cpos);
      this.$.editor.editor.clearSelection();
    }
  },

  /**
   * Mirrors modifications back to the pages array
   */
  _editorModified: function() {
    // listener disabled
    if (this._ignoreChanges) {
      return;
    }
    if (!this.pages || !this.pages.length) {
      return;
    }
    var index = this.$.tabbar.selected;
    if (this.pages.length > index) {
      // track hash for dirty bit
      if (!this.pages[index].hash && this.pages[index].content !== undefined) {
        this.pages[index].hash = this._hashCode(this.pages[index].content);
      }
      // cache current value
      this.pages[index].content = this.$.editor.getValue();
      // enable save if nec
      this.pages[index].modified = this._hashCode(this.pages[index].content) !== this.pages[index].hash;
      this.$.save.disabled = !this.pages[index].modified;
    }
  },
  /**
   * Save the contents of the currently selected editor
   */
  save: function(e) {
    // selected page
    var index = this.$.tabbar.selected;
    this.fire('xbuilder-editor-save', {
      srcElement: this,
      index: index
    })
  },

  /**
   * Close the editor. Confirm close if modified content exists
   */
  close: function(e) {
    var modified = false;
    if (this.pages) {
      this.pages.forEach(function(page) {
        if (page.modified) {
          modified = true;
        }
      });
    }
    // dirty editors
    if (modified) {
      // confirm close with user
      $M.confirm('Component Modified: Discard changes?', function(yes) {
        if (yes) {
          this.fire('xbuilder-editor-close', {
            srcElement: this
          });
        }
      }, this, 1, ['yes', 'no']);
      // cancel gets here and does nothing
    }
    // nothing dirty
    else {
      this.fire('xbuilder-editor-close', {
        srcElement: this
      });
    }
  },
  vim: function(e) {
    this.$.editor.vim = this.$.vim.active;
    $M.notify('VI Mode ' + (this.$.vim.active ? 'Enabled' : 'Disabled'), $M.alerts.info);
  },
  isVim: function() {
    if (!this.$.editor) {
      return false;
    }
    return this.$.editor.vim;
  },
  _hashCode: function(s) {
    return s.split("").reduce(function(a, b) {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a
    }, 0);
  },
  clearDirtyBit: function(index) {
    this.pages[index].modified = false;
    this.pages[index].hash = undefined;
    this.$.save.disabled = !this.pages[index].modified;
  }
});
