Polymer({
  is: 'trm-max-control-toolitem',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {},
  listeners: {
  },
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },
  /**
   * gets the image src
   * @return the path to the image
   */
  getImageSrc: function() {
    var str = this.getAtt(this.component, 'image');
    return this.getImagePath(str);
  },
  /**
   * gets the type of control
   * @return 1 when it's a separator, 2 if it's an option, and 0 otherwise
   */
  getType: function() {
    if (this.getAtt(this.component, "elementtype") == "SEP") {
      return 1;
    }
    if (this.getAtt(this.component, "elementtype") == "OPTION") {
      return 2;
    }
    return 0;
  },
  /**
   * checks if a control is a separator
   * @return true when it is a separator type
   */
  isSep: function() {
    return this.getType() == 1;
  },
  /**
   * checks if a control is an option type
   * @return true when it is an OPTION
   */
  isOption: function() {
    return this.getType() == 2;
  },
  /**
   * Overwrites the behavior setup method this checks the rules for a toolitem (oncreate/onsave) 
   * instead of checking for rules on a control or a field
   */
  _setup: function() {
    if (!this.component || !this.component.tagName || !this.rules) {
      return;
    }
    if (this.comprules == null) {
      var filter = new RuleFilter();
      //the rules for this component
      //this.comprules = new Array();
      //filter rules for this control
      if (this.rules != null && this.rules.length > 0) {
        this.comprules = filter.getRulesForToolItem(this.component, this.rules);
      } else {
        this.comprules = {
          'mbo': []
        };
      }
    }
  },
  /**
   * Checks if a control needs a marker drawn over it
   * @return true if there are mbo rules on the toolitem
   */
  needsOverlay: function(r) {
    if (this.comprules == null) {
      return false;
    }
    if (this.comprules.mbo == null) {
      return false;
    }
    return this.comprules.mbo.length > 0;
  },

});
