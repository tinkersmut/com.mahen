 Polymer({
   is: 'trm-max-control-attachments',
   behaviors: [BaseComponent, ControlBehavior],
   properties: {},
   listeners: {},
   created: function() {

   },
   ready: function() {

   },
   attached: function() {

   },
   getImageSrc: function() {
     //var str = this.getImagePath('img_attachments.gif');
     return this.getImagePath('img_attachments.gif');
   }

 });