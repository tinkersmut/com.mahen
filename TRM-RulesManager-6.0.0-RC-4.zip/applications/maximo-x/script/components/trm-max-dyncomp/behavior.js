TRMDynamicComponent = {

  /**
   * Initialize the service worker if needed
   */
  created : function() {
    if('serviceWorker' in navigator) {
      let context = document.location.href.replace(/^.+\/\/[^\/]+\/([^\/]+)\/.*/i, '$1')
      let url = `/${context}/trm-sw.js`;
      navigator.serviceWorker.register(url).then(function(registration) {
        console.log('TRM ServiceWorker registration successful', registration.scope);
      }, function(err) {
        $M.notify('TRM ServiceWorker registration failed. Caching is disabled and application will not work offline: ' + err, $M.alerts.error);
      });
    }
  }
};
