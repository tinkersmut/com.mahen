Polymer({
  is: 'trm-max-control-tab-button',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {
    nextTabIndex: {
      type: Number,
      notify: true,
      value: 0
    },
    ndx: {
      type: Number,
      notify: true,
      observer: '_setActive'
    },
  },
  listeners: {},
  created: function() {

  },
  ready: function() {

  },
  attached: function() {},
  /**
   * Handles on click of a tab-buttons, and styles the button to be active
   * fires a select and passes the selected ndx to the tab group to display the correct page
   */
  openTab: function(evt) {
    //style the selected tab
    this.toggleClass("active", true, evt.target);
    var details = {
      'selected': this.ndx
    };
    this.fire('select', details);
  },
  //   getNextTabIndex: function() {
  //     var ret = this.nextTabIndex;
  //     this.nextTabIndex++;
  //     return ret;
  //   },
  /**
   * clicks the first tab button so it styles it properly and sets the currtab on the tabgroup to the first tab button
   */
  _setActive: function() {
    //if the ndx of this tab is 0, click the tabbutton control
    if (this.ndx != null && this.ndx == 0 && this.$.tabbutton != null) {
      this.$.tabbutton.click();
    }
  }
});