Polymer({
      is: 'trm-max-dseditor',
      properties: {
        /**
         * DataSourceElement being edited
         */
        datasource: {
          type: Object,
          notify: true,
          observer: '_setDataSource'
        },

        height: {
          type: Number,
          notify: true,
          observer: '_setHeight'
        },

        /**
         * Mirrors the currently selected page index of the multipage editor
         */
        pageIndex: {
          type: Number,
          notify: true,
          observer: '_pageChanged'
        },

        /**
         * The JSON UI that describes how to layout this editor
         */
        presentation: {
          type: Object,
          notify: true
        },
      },

      attached: function() {
        if ($M.workScape && $M.workScape.getHeight() > 0) {
          this._setHeight($M.workScape.getHeight());
        } else {
          this._setHeight(window.outerHeight);
        }

        this.$.save.disabled = true;
      },

      _setHeight: function(height) {},

      _pageChanged: function(index) {},

      /**
       * Called when the datasource of this editor is set
       */
      _setDataSource: function(datasource) {
        // needed for tabs
        this.osname = datasource.objectStructure;

        // not dirty by default
        this.$.save.disabled = true;

        this.title = datasource.getLabel();
        datasource.componentImpl.getEditorUIFile().then(json => {
          // downloaded as string?
          if(json && !json.tabs && json.indexOf){
            this.presentation = JSON.parse(json);
          }
          // downloaded as null or JSON
          else{
            this.presentation = json;
          }
        }).catch(err => {
          $M.notify(`Error editing ${datasource.getLabel()}. Error: ${err}`, $M.alerts.error);
        });

      },

      /**
       * Save the datasource
       */
      save: function(e) {
        this.datasource.commit();

        this._updateDirtyState();

        // notify outside editors to update content and rebuild model
        this.fire('save', {
          editor: this,
          datasource: this.datasource
        })
      },

      /**
       * Close the editor.
       */
      close: function(e) {
        this.fire('close', {
          editor: this
        });
      },

      /**
       * @return true if this editor has been modified
       */
      isDirty: function() {
        return this._modified;
      },

      clearDirtyBit: function() {
        this._modified = false;
        this.$.save.disabled = !this._modified;
      },

      markDirty: function() {
        this._modified = true;
        this.$.save.disabled = !this._modified;
      },

      _evalBinding: function(e) {
        let setvalue = e.detail.setvalue;
        let bind = e.detail.bind;

        // method call
        if (bind.indexOf('(') > -1) {
          let ELEMENT = this.datasource;
          let value = eval(bind);
          if (value !== undefined) {
            setvalue(value);
            return;
          }
          console.log("eval method call failed", value);
        }


        let variable = this._getVariable(bind);
        if (variable !== undefined) {
          if (variable.hasOwnProperty('value')) {
            setvalue(variable.value);
          } else {
            setvalue(variable);
          }
        }
      },

      /**
       * Helper method to evaluate the bind into a variable
       */
      _getVariable: function(bind) {
        let current = undefined;
        let split = bind.split(/\./);

        let prev = '';
        for (let i = 0; i < split.length; i++) {
          let s = split[i];
          if (s === 'ELEMENT') {
            current = this.datasource;
            continue;
          }
          if (current === undefined) {
            return;
          }
          if (current.filter) {
            let filter = current.filter(c => c.name == s);
            if (filter && filter.length) {
              return filter[0];
            }
          }
          current = current[s];
        }
        return current;
      },

      _isRemovingValue: function(value) {
        return value === undefined || (typeof(value) == 'string' && value.length == 0);
      },

      _setBinding: function(e) {
        let bind = e.detail.bind;
        let value = e.detail.value;
        let variable = this._getVariable(bind);

        // change value
        if (variable !== undefined && variable.hasOwnProperty('value')) {
          if (variable._origvalue === undefined) {
            variable._origvalue = variable.value;
          }
          variable.value = value;
          variable._modified = (value !== variable._origvalue);
          // removing
          variable._deleted = this._isRemovingValue(value);
        }

        // create it
        else {
          let member = bind.replace(/\.[^\.]+$/, '');
          let varname = bind.split(/\./).pop();
          variable = this._getVariable(member);
          // array
          if (variable !== undefined && variable.hasOwnProperty('length')) {
            let attribute = this.datasource.convertPropertyName(varname);
            // events member
            if (bind.indexOf('.events.') > -1) {
              let event = this.datasource.createEvent(varname, `on-${attribute}`, value);
              event._modified = true;
              variable.push(event);
            }
            // props/atts
            else {
              let newatt = this.datasource.createAtt(varname, attribute, value);
              newatt._modified = true;
              variable.push(newatt);
            }
          }
        }

        this._updateDirtyState();
      },

      /**
       * Set the state of the save button
       */
      _updateDirtyState: function() {
        this.$.save.disabled = !this.datasource.isDirty();
      },
    });