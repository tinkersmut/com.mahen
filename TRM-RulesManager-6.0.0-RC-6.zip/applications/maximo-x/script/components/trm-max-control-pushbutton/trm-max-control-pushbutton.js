Polymer({
  is: 'trm-max-control-pushbutton',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {},
  listeners: {},
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },

});