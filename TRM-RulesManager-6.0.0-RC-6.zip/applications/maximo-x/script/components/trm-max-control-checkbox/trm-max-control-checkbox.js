    Polymer({
      is: 'trm-max-control-checkbox',
      behaviors: [BaseComponent, ControlBehavior],
      properties: {},
      listeners: {},
      created: function() {

      },
      ready: function() {

      },
      attached: function() {

      },

    });