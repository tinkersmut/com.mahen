Polymer({
  is : 'trm-max-comprequestor',
  behaviors : [ BaseComponent ],
  properties : {
    /**
     * Set to true on this element to not cache data. Caches by default
     */
    noCache : {
      type : Boolean,
      value : false,
      notify : true
    },

    /**
     * Data fetched from the server via ajax
     */
    _response : {
      type : Object,
      notify : true,
      observer : '_handleResponse'
    },
    /**
     * Data response from the server
     */
    data : {
      type : Object,
      notify : true,
      observer : '_dataUpdated'
    },
    
    /**
     * Path of the file to retrieve 
     */
    path : {
      type: String,
      notify: true,
      observer : '_updateURL'
    }
  },
  
  ready: function(){
    // initialize
    this._updateURL();
  },
  
  _updateURL: function(){
    let pathname = window.location.pathname;
    // fix when index.html is in play
    pathname = pathname.replace(/index\.html/i,'');
    this._url = window.location.origin + pathname + this.path;
  },

  /**
   * Called whenever the _response is set. Does nothing if caching...sets data if no-caching
   */
  _handleResponse : function(response) {
    if(this.noCache) {
      this.data = response;
    }
  },

  _dataUpdated : function() {
    if(!this.data || !this._resolve) {
      return;
    }
    this._resolve(this.data);
  },

  /**
   * Retrieves the file content from the server
   * @return Promise that resolves to String
   */
  fetch: function() {
    if(this.data){
      return Promise.resolve(this.data);
    }
    this._resolve = undefined;
    this._reject = undefined;
    return new Promise((resolve, reject)=>{
      this._resolve = resolve;
      this._reject = reject;
      this.$.xwar.generateRequest();
    });
  },
  
  /**
   * Handles an ajax error from the server
   */
  _processError : function(e) {
    if(this._reject) {
      var error = e;
      if(e.detail && e.detail.error)
        error = e.detail.error;
      this._reject(error);
    }
  },
});
