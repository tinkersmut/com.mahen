Polymer({
  is: 'trm-max-compcard',
  behaviors: [BaseComponent],
  properties: {

    card: {
      type: Object,
      notify: true,
      observer: '_setCard'
    },
    _showfiles: {
        type: Boolean,
        notify: true,
        value: false
    }
  },
  
  _setCard: function(card){
    if(card.description && card.description.trim && card.description.trim().length){
        this._description = card.description;
    }
    else{
        this._description = 'No Details Available';
    }
  },

  _getIcon: function(card) {
    if (card.behavior) {
      return 'extension';
    }
    return 'polymer';
  },

  _edit: function(e) {
    this.fire('edit', {
      card: this.card
    });
  },
  _showFiles: function(){
      this._showfiles = true;
  },
  _showLess: function(){
      this._showfiles = false;
  },
  _shorten: function(path){
      return path.replace(/^script([\/\\])/i,'..$1');
  }
});