    Polymer({
      is: 'trm-max-control-tablebody',
      extends: 'tr',
      behaviors: [BaseComponent, ControlBehavior],
      properties: {
        inputs: {
          type: String,
          notify: true,
          value: "false"
        }
      },
      listeners: {},
      created: function() {},
      ready: function() {},
      attached: function() {},
      isInputs: function() {
        return this.inputs == "true";
      },
    });