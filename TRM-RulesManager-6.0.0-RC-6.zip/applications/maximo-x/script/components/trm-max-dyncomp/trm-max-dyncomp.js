Polymer({
  is : 'trm-max-dyncomp',
  behaviors: [BaseComponent, DynamicComponent, TRMDynamicComponent],
  properties: {
      /**
       * Name of component to fetch
       */
    name: {
      type: String,
      notify: true
    },
    
    /**
     * Contents of the component
     */
    content: {
        type: Object,
        notify: true,
        observer: '_contentFetched'
    }
  },
  
  ready: function(){
      this.$.data.params = {'_format':'xml'};
    // fetch content
    this.$.data.send();
  },

  /**
   * Called when name of oslcscript is set
   */
  _contentFetched: function(content) {
      if(content !== undefined && content.success){
          this.root.host.appendChild($j(content.content)[0]);
      }
  },
});