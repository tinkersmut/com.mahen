/**
 * Handles passed in component and draws the corresponding control
 */
Polymer({
  is: 'trm-max-control-handler',
  behaviors: [BaseComponent],
  properties: {

  },
  listeners: {
    'mouseover': '_mouseover', //draws border around control
    'mouseout': '_mouseout', //removes border from control
    'contextmenu': 'rightClick' //draws right click
  },
  observers: ['_setup(component,rules)'], //draws the component once rules and component are defined
  created: function() {

  },
  ready: function() {

  },
  attached: function() {

  },
  /**
   * displays a blue border on mouse over
   */
  _mouseover: function(evt) {
    if (this && this.$ && this.$.container && this.$.container.children.length == 1 && this.$.container.children[0].$ && this.$.container.children[0].$.wrapper) {
      this.$.container.children[0].$.wrapper.setAttribute("style", "border: 2px double blue;")
    } else {
      //   console.log("can't find it", this.$.container);
    }
    evt.stopPropagation();
  },
  /**
   * hides the border
   */
  _mouseout: function(evt) {
    if (this && this.$ && this.$.container && this.$.container.children.length == 1 && this.$.container.children[0].$ && this.$.container.children[0].$.wrapper) {
      this.$.container.children[0].$.wrapper.setAttribute("style", "border: 2px double transparent;")
    }
  },
  /**
   * Takes the component that is passed in and creates the corresponding control
   */
  _setup: function() {
    try {
      //ensure all of the necessary properties have been defined
      if (!this.component || !this.rules) {
        return;
      }
      //create the control for this component, and pass the conponent rules
      var newchild = Polymer.Base.create('trm-max-control-' + this.component.tagName, {
        'rules': this.rules,
        'component': this.component,

      });
      //append the control
      this.$.container.appendChild(newchild);
      //default the border to transparent
      if (newchild && newchild.$ && newchild.$.wrapper) {
        newchild.$.wrapper.setAttribute("style", "border: 2px double transparent;")
      }
    } catch (err) {
      console.log(err);
    }
  },
  /**
   * call the context menu event passing this component
   */
  rightClick: function(evt) {
    this.fire('contextmenu-node', {
      x: evt.pageX,
      y: evt.pageY,
      node: this
    });
    evt.preventDefault();
    evt.stopPropagation();
  },
});