Polymer({
  is: 'trm-max-control-tabgroup',
  behaviors: [BaseComponent, ControlBehavior],
  properties: {
    selected: {
      type: Number,
      notify: true,
      value: 0
    },
    nextTabIndex: {
      type: Number,
      notify: true,
      value: 0
    },
    currTab: {
      type: Object,
      notify: true
    }
  },
  listeners: {

  },
  created: function() {

  },
  ready: function() {

  },
  attached: function() {},
  /**
   * Gets the next tab index (so selected matches the corresponding drawn page)
   * @return the next tab index 
   */
  getNextTabIndex() {
    var ret = this.nextTabIndex;
    this.nextTabIndex++;
    return ret;
  },
  /**
   * Handles when a tab is clicked (called via onclick of a max-control-tab-button executing a select() )
   * Sets selected so the page content is displayed
   * also sets the currTab property so we can highlight/unhighlight the appropriate tab-button
   * @param evt - the event that fires when a tab is clicked, detail contains a 
   *              selected property that contains the index of the page content to display
   */
  _tab_button_tap: function(evt) {
    if (evt == null) {
      //sanity check
      console.log("_tab_button_tap: evt is null");
    }
    //turn off the active class
    if (this.currTab != null) {
      this.toggleClass("active", false, this.currTab.$.tabbutton);
    }
    //changes the iron-page to the appropriate tab content
    this.selected = evt.detail.selected;
    //stores the tab so we can turn off highlighting when another tab is defined
    this.currTab = evt.target;
  },
});