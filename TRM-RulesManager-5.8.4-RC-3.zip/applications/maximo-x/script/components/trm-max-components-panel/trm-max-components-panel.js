Polymer({
      is: 'trm-max-components-panel',
      behaviors: [BaseComponent, RecursiveFetch],
      listeners: {},
      properties: {
        _hideAll: {
          type: Boolean,
          value: true,
          notify: true
        },
        allComponents: {
          type: Array,
          notify: true,
          value: function() {
            return [];
          }
        }
      },

      _getRegistry: function() {
        if (!$M._registry) {
          $M._registry = Polymer.Base.create('trm-max-compregistry', {});
        }
        return $M._registry;
      },

      /**
       * Refresh the list of components
       */
      attached: function() {
        $M.toggleWait(true);

        let promises = [];
        let components = [];
        let behaviors = [];
        // fetch maximo- components
        promises.push(this._getRegistry().getMaximoComponents().then(c => {
          components = components.concat(c)
        }));
        // fetch library components
        promises.push(this._getRegistry().getLibraryComponents().then(c => {
          components = components.concat(c)
        }));
        // fetch maximo behaviors
        promises.push(this._getRegistry().getMaximoBehaviors().then(c => {
          behaviors = behaviors.concat(c)
        }));

        Promise.all(promises).then(() => {
          this.allComponents = components.concat(behaviors);

          // array of {name: ,components: []}
          var groups = [{
            name: 'Core',
            expanded: false,
            components: []
          }, {
            name: 'Maximo Core',
            expanded: false,
            components: []
          }, {
            name: 'Maximo Cards',
            expanded: false,
            components: []
          }, {
            name: 'Maximo DataDesigner',
            expanded: false,
            components: []
          }, {
            name: 'Maximo Inspection',
            expanded: false,
            components: []
          }, {
            name: 'Maximo Inspector',
            expanded: false,
            components: []
          }, {
            name: 'TRM XBuilder',
            expanded: false,
            components: []
          }, {
            name: 'TRM Classic Controls',
            expanded: false,
            components: []
          }, {
            name: 'TRM',
            expanded: true,
            components: []
          }];

          components.forEach(function(component) {
            var paths = component.name.split('-');
            // maximo comp
            if (paths[0] == 'maximo') {
              if (paths.length < 3) {
                groups[1].components.push(component);
              } else {
                switch (paths[1]) {
                  case 'xbuilder':
                    groups[6].components.push(component);
                    break;
                  case 'datadesign':
                    groups[3].components.push(component);
                    break;
                  case 'inspection':
                    groups[4].components.push(component);
                    break;
                  case 'inspector':
                    groups[5].components.push(component);
                    break;
                  default:
                    if (paths[paths.length - 1] == 'card') {
                      groups[2].components.push(component);
                    } else {
                      groups[1].components.push(component);
                    }
                }
              }
            }
            // trm comp
            else if (paths[0] == 'trm') {
              if (paths[1] == 'max' && paths.length > 2 && paths[2] == 'control') {
                groups[7].components.push(component);
              } else {
                groups[8].components.push(component);
              }
            }
            // core comp
            else {
              groups[0].components.push(component);
            }
          });

          this._componentgroups = [groups.shift(), {
            name: 'Maximo Behaviors',
            expanded: false,
            components: behaviors
          }].concat(groups);

          $M.toggleWait(false);
        }, err => {

          $M.toggleWait(false);
          console.log("Registry error ", err);
          $M.notify(`Error: ${err} fetching registry, please check that WAR file was built correctly`, $M.alerts.error);
        });

      },

      _search: function(event) {
        const search = this.$.search.value;
        if (!search || !search.trim()) {
          this._hideAll = true;
          this._filtered = [];
          return;
        }
        this._hideAll = false;
        this._filtered = this.allComponents.filter(component => {
          if (component.name.indexOf(search) > -1) {
            return true;
          }
          return false;
        });
      },

      /**
       * Called when edit is clicked on a component card
       */
      _editCard: function(e) {
        $M.toggleWait(true);
        let card = e.detail.card;
        let files = card.files;

        // make sure it uses / instead of \
        files = files.map(f => f.replace(/[\\]/g, '/'));

        // fetch all files associated
        this._recursiveFetchFiles(card.name, card.behavior, files).then(result => {
          // success
          $M.toggleWait(false);
          delete result.success;
          this.fire('edit-component', result);
        }, err => {
          // error
          $M.toggleWait(false);
          $M.notify('Unable to fetch component', $M.alerts.error);
        });
      },

    });