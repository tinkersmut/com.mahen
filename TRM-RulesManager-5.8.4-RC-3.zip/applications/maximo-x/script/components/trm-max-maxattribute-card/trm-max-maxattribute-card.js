Polymer({
  is : 'trm-max-maxattribute-card',
  properties : {
    card : {
      type : Object,
      notify : true
    }
  },

  _getLabel : function(card) {
    if(card.relationship) {
      return `${card.relationship}.${card.attributename}`;
    }
    return `${card.objectname}.${card.attributename}`
  },

  /**
   * Called when card is deleted
   */
  _deleteCard : function() {
    this.fire('delete', {
      card : this.card
    });
  }
});
