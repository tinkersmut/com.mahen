Polymer({
      is: 'trm-max-components',
      behaviors: [BaseComponent],

      /**
       * Fetch the file contents for the specified component
       * @param componentName String name of the component
       * @param files Array array of file paths to fetch
       * @param behavior Boolean TRUE if this is a behavior
       */
      fetch: function(componentName, files, behavior) {
        return new Promise((resolve, reject) => {
          // first hit wcc to see if modified content exists
          this._fetch(componentName, files, behavior).then(result => {
            // modified content exists in db
            // TODO: check what was not fetched and fetch rest from comprequestor
            resolve(result);
          }, fail => {
            // no modified content, get them all from comprequestor
            let promises = [];
            let data = {};
            files.forEach(f => {
              let requestor = Polymer.Base.create('trm-max-comprequestor', {});
              requestor.path = f;
              promises.push(requestor.fetch().then(content => {
                  data[f] = content;
              }));
            });
            Promise.all(promises).then(() => {
              resolve(data);
            }, err => {
              // one of them failed
              reject(err);
            })
          });
        });

      },

      /**
       * Fetch components from the server.
       */
      _fetch: function(name, files, behavior) {

        this.$.server.method = 'GET';
        this.$.server.params = {
          '_component': name,
          '_files' : files.join(','),
          '_behavior': (behavior === undefined ? false : behavior)
        };

        return new Promise((resolve, reject) => {
          this.$.server.send().then(function(result) {
            resolve(result);
          }.bind(this), function(error) {
            reject(error);
          });
        });
      },

      /**
       * Sends the source property to be the content of the component file on the
       * server
       */
      send: function(path, source) {
        this.$.server.params = {
          '_file': path
        };
        return this.$.server.post(source);
      },

      /**
       * Creates a empty component from the IBM template on the server
       * @return JSON {success: true, filepath: contents...}
       */
      create: function(name) {
        this.$.server.params = {
          '_component': name,
          '_create': 'true'
        };
        return this.$.server.post('Template');
      }

    });