 Polymer({
   is: 'trm-max-control-dialog',
   behaviors: [BaseComponent, ControlBehavior],
   properties: {},
   listeners: {},
   created: function() {

   },
   ready: function() {

   },
   attached: function() {

   },

 });