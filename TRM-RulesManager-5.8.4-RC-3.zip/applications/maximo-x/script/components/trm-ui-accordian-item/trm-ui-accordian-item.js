/**
 * Item in a trm-ui-accordian
 */
Polymer({
  is: "trm-ui-accordian-item",
  properties: {
    item: {
      type: Object,
      notify: true
    },

    /**
     * TRUE if currently active (checked)
     */
    active: {
      type: Boolean,
      notify: true
    },

    /**
     * Name of this item to display
     */
    name: {
      type: String,
      notify: true
    },

  },

  observers: ['_setItem(item)'],

  /**
   * Set the actions array
   */
  _setItem: function(item) {
    if (item && item.actions) {
      this._actions = item.actions;
    }
  },

  /**
   * Called when each action is rendered...decides if to hide action
   */
  _hideAction: function(action) {
    if (action.hide === undefined) {
      return false;
    }
    let index = this._actions.indexOf(action);

    // call hide function
    if (typeof(action.hide) === 'function') {
      let hide = action.hide();

      // Promise was returned (this is done async)
      if (hide.then) {
        this.debounce('hideSpin', () => {
          this._toggleSpinner(action, true);
        }, 2000);
        // toggle attribute in promise
        hide.then(shouldHide => {
          this.cancelDebouncer('hideSpin');
          this._toggleSpinner(action, false);
          // get by id and hide it
          let element = this.$$('#action_' + index);
          Polymer.Base.toggleAttribute('hidden', shouldHide, element);
        }).catch(err => {
          this.cancelDebouncer('hideSpin');
          this._toggleSpinner(action, false);
          console.log("Error hidding accordian icon: "+err, action);
        });

        // hide until promise comes back
        return true;
      }
      // hard value returned
      return hide;
    }

    // not a function...hard value
    return action.hide;
  },

  /**
   * Called when an action is pressed
   */
  _tapAction: function(event) {
    event.stopPropagation();
    let action = this.$.contentModel.itemForElement(event.target);
    if (action && action.run) {
      let retval = action.run(this.item);
      if (retval !== undefined) {

        // Promise...recheck hide state/icon
        if (retval.then) {

          this._toggleSpinner(action, true);
          
          retval.then(() => {
            // refresh the icons
            this._toggleSpinner(action, false);
            Polymer.Base.toggleAttribute('hidden', this._hideAction(action), event.target);
          });
        }
        // hard return value? just refresh actions
        else {
          this._actions = Array.from(this.item.actions);
        }
      }
    }
  },

  _toggleSpinner: function(action, active) {
    const index = this._actions.indexOf(action);
    const spinner = this.$$('#spin_' + index);
    if(spinner === undefined){
      console.log("No spinner found");
      return;
    }
    const icon = this.$$('#action_' + index);
    spinner.active = active;
    Polymer.Base.toggleClass('hideme', !spinner.active, spinner);
    Polymer.Base.toggleClass('hideme', spinner.active, icon);
  }
});