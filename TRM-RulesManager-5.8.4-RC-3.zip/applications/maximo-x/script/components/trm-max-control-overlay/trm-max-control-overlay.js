 Polymer({
   is: 'trm-max-control-overlay',
   behaviors: [BaseComponent],
   properties: {
     comprules: {
       type: Object,
       notify: true,
     },
   },
   listeners: {},
   created: function() {

   },
   ready: function() {

   },
   attached: function() {

   },
   hasUIRules: function() {
     if (!this.comprules) {
       return false;
     }
     if (!this.comprules.ui) {
       return false;
     }
     return this.comprules.ui.length > 0;
   },
   hasMBORules: function() {
     if (!this.comprules) {
       return false;
     }
     if (!this.comprules.mbo) {
       return false;
     }
     return this.comprules.mbo.length > 0;
   },
   hasRules: function() {
     if (!this.comprules) {
	   return false;
	 } 
	 if (this.comprules.mbo) {
	   return this.comprules.mbo.length > 0;
	 }
	 if (this.comprules.ui) {
	   this.comprules.ui.length > 0;
	 }
     return false;
   },

 });
