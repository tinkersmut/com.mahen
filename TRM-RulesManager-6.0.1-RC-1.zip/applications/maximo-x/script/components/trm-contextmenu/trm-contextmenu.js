    Polymer({
      is: 'trm-contextmenu',
      behaviors: [BaseComponent],
      properties: {
        /**
         * For positioning absolutely next to an element on the page
         */
        top: {
          type: Number,
          value: 0
        },
        /**
         * For positioning absolutely next to an element on the page
         */
        left: {
          type: Number,
          value: 0
        },
        /**
         * Items to display (with a .name property) as menu items
         */
        items: {
          type: Array,
          notify: true,
          value: function() {
            return [];
          }
        },
        /**
         * Set true to position this z-index to 9999
         */
        alwaysOnTop: {
          type: Boolean,
          notify: true
        },
        
        /**
         * Set true to make icons 16x16
         *
         */
        isSmall: {
          type: Boolean,
          notify: true
        },

        _hidemenu: {
          type: Boolean,
          value: true
        },

      },
      observers: [
        '_setLocation(left,top)'
      ],

      _setLocation: function(left, top) {
        this.$.menu.style.left = left + 'px';
        this.$.menu.style.top = top + 'px';
      },

      _selectItem: function(e) {
        e.stopPropagation();
        var item = this.$.tempItems.itemForElement(e.detail.item);
        this.$.paperMenu.selected = -1;
        this.fire("iron-select", {
          item: item
        });
      },
      /**
       * Get the icon for the specified action
       */
      _getIcon: function(item) {
        if (!item.icon) {
          return;
        }
        if (typeof(item.icon) === 'function') {
          return item.icon(item.node);
        }
        return item.icon;
      },
      /**
       * Get the name for the specified action
       */
      _getName: function(item) {
        if (!item.name) {
          return;
        }
        if (typeof(item.name) === 'function') {
          return item.name(item.node);
        }
        return item.name;
      },

      open: function() {
        this._hidemenu = false;
      },

      close: function() {
        this._hidemenu = true;

      }
    });
