    /**
     * Accordian style explorer
     */
    Polymer({
      is: "trm-ui-accordian",

      properties: {
        /**
         * Title of this accordian
         */
        name: {
          type: String,
          notify: true
        },

        /**
         * List of items to display as selectable items in this accordian
         */
        items: {
          type: Array,
          notify: true,
          value: function() {
            return [];
          }
        },

        /**
         * Actions with icon property, name, and run method that are displayed to the left of the title
         */
        actions: {
          type: Array,
          notify: true,
          value: function() {
            return [];
          }
        },
        
        /**
         * Defaults to FALSE. Set to true to make children toggled on selection
         */
        selectable: {
            type: Boolean,
            notify: true,
            value: false
        },

        /**
         * method to call on the item to get the name (only this or nameProperty can be set)
         */
        nameMethod: {
          type: String
        },

        /**
         * property on the item with name (only this or nameMethod can be set)
         */
        nameProperty: {
          type: String
        },
      },

      /**
       * 
       */
      toggle: function() {
        this.$.accordian.toggle();
      },
      /**
       * 
       */
      expand: function() {
        this.$.accordian.show();
      },

      /**
       * Clears any currently selected items
       */
      clearSelection: function() {
        // allow only 1 selection at a time
        if (this._selectedbutton) {
          this._selectedbutton.active = false;
        }
        this._selectedbutton = undefined;

      },

      /**
       * Get the currently selected item
       * @return Object
       */
      getSelectedItem: function() {
        if (!this._selectedbutton) {
          return;
        }
        let item = this.$.contentModel.modelForElement(this._selectedbutton).item;
        return item
      },

      /**
       * Make the specified item's button active. Does NOT Fire off a select or unselect event
       * 
       * @param item Object from the items array to select
       */
      selectItem: function(item) {
        this.clearSelection();
        // just clear selection and get out
        if (!item) {
          return;
        }
        
        let id = 'button_' + this.items.indexOf(item);
        let button = this.$$('#'+id);
        if (!button) {
          return;
        }
        button.active = true;
        this._selectedbutton = button;
      },

      /**
       * Fires the select or unselect event with properties {item: selected item, previousItem: unselected item}
       */
      _selectItem: function(e) {
        let previtem = undefined;
        // allow only 1 selection at a time
        if (this._selectedbutton) {
          this._selectedbutton.active = false;
          previtem = this.$.contentModel.itemForElement(this._selectedbutton);
        }

        // selected myself (or deselecting current selection)
        let button = e.target;
        while (button && button.tagName != 'PAPER-BUTTON') {
          button = button.parentElement;
        }
        if (!e || this._selectedbutton == button) {
          this._selectedbutton = undefined;
          this.fire("unselect", {
            item: previtem,
            previousItem: previtem
          });
          return;
        }
        this._selectedbutton = button;
        let item = this.$.contentModel.itemForElement(this._selectedbutton);
        this.fire("select", {
          item: item,
          previousItem: previtem
        });
      },

      /**
       * Called when an action is pressed
       */
      _tapAction: function(event) {
        event.stopPropagation();
        let action = this.$.actionsModel.modelForElement(event.target).action;
        if (action && action.run) {
          action.run();
        }
      },

      /**
       * Add an action. Action appear to the right of the title as icons
       * @param action Object of form {icon:'extension',run:function()}
       */
      addAction: function(action) {
        this.actions = this.actions.concat(action);
      },

      _getName: function(item) {
        if (this.nameMethod) {
          return item[this.nameMethod]();
        }
        if (!this.nameProperty) {
          return item;
        }
        return item[this.nameProperty];
      },
      _getZIndex: function(index) {
        return 1000 - index;
      }
    });