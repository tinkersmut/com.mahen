    Polymer({
      is: 'trm-max-control-selectactions',
      behaviors: [BaseComponent, ControlBehavior],
      properties: {
        actionsstr: {
          type: String,
          notify: true
        }
      },
      listeners: {
        'mxactionsel.tap': '_confirmlist',
      },
      created: function() {

      },
      ready: function() {

      },
      attached: function() {

      },
      _confirmlist: function() {
        if (this.actionsstr.length == 0) {
          if (this.component != null) {
            if (this.actionsstr == null || this.actionsstr.length == 0) {
              var str = "";
              for (var i = 0; i < this.component.children.length; i++) {
                if (i > 0) {
                  str = str + ",";
                }
                str = str + this.component.children[i].getAttribute("path");
              }
              this.actionsstr = str;
            }
          }
        }
      },
      _setup: function() {
        this._confirmlist();
      }

    });