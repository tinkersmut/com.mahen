Polymer({
  is: 'trm-max-compcardgroup',
  behaviors: [BaseComponent],
  properties: {

    /**
     * Data array to create cards from
     */
    components: {
      type: Array,
      notify: true,
      value: function() {
        return [];
      },
    },
    /**
     * Group Name
     */
    name: {
      type: String,
      notify: true,
      value: "Group"
    },
    expanded: {
      type: Boolean,
      notify: true,
      value: false
    }
  },
  expand: function() {
    this.expanded = !this.expanded;
    if (!this.expanded) {
      this.$.grouptitle.removeAttribute('expanded', false);
    } else {
      this.$.grouptitle.setAttribute('expanded', true);
    }
  },
  expandIcon: function(expanded) {
    if (expanded)
      return 'icons:remove';
    return 'icons:add';
  }
});