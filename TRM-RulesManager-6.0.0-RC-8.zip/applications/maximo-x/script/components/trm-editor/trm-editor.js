/**
 * @event xbuilder-editor-completion
 * @event xbuilder-editor-ready
 * @event xbuilder-editor-change
 * @event xbuilder-editor-scroll
 * @event xbuilder-editor-cursor
 */
Polymer({
  is: 'trm-editor',
  behaviors: [BaseComponent],
  properties: {

    /**
     * 'relative','absolute','static' etc
     */
    position: {
      type: String,
      value: 'relative'
    },
    /**
     * The script content of the editor
     */
    script: {
      type: String,
      notify: true,
      observer: '_setScript'
    },
    /**
     * width of the editor (default: 500px)
     */
    width: {
      type: String,
      value: '500px'
    },
    /**
     * height of the editor (default: 400px)
     */
    height: {
      type: String,
      notify: true,
      observer: '_setHeight'
    },
    editor: {
      type: Object
    },
    /**
     * Theme to use (default: ace/theme/tomorrow). Others include
     * "ace/theme/twilight"
     */
    theme: {
      type: String,
      value: 'ace/theme/tomorrow',
      observer: '_setTheme'
    },
    /**
     * Mode to use (defaults: ace/mode/javascript). Other modes include
     * "ace/mode/xml","ace/mode/python"
     */
    mode: {
      type: String,
      value: 'ace/mode/javascript',
      observer: '_setMode'
    },
    /**
     * Set to true to enable VI mode
     */
    vim: {
      type: Boolean,
      value: false,
      observer: '_setVim'
    },
    nolinenums: {
      type: Boolean,
      value: false,
      observer: '_hideLineNums'
    },
    /**
     * Set to true to quick set this editor to HTML editing (enables html mode
     * and formatting)
     */
    html: {
      type: Boolean,
      value: false
    }
  },
  created: function() {

  },
  ready: function() {
    var editorElem = this.$$('.editor');
    this.editor = ace.edit(editorElem)

    // amahen: prevents warning message
    //this.editor.$blockScrolling = Infinity;

    if (this.html) {
      this.mode = 'ace/mode/html';
    }

    this.editor.getSession().setMode(this.mode);

    this.editor.setTheme(this.theme);

    this.editor.getSession().setUseWrapMode(true);
    this._winkh = this.editor.getKeyboardHandler();
    if (this.vim) {
      this._setVim();
    }
    if (this.script) {
      this.editor.setValue(this.script);
    }
    if (this.nolinenums) {
      this.editor.renderer.setShowGutter(false);
    }

    // completion
    var contentAssist = ace.require('ace/ext/language_tools');
    this.editor.setOptions({
      enableBasicAutocompletion: true,
      enableSnippets: true,
      enableLiveAutocompletion: false
    });
    contentAssist.addCompleter({
      getCompletions: this.getCompletions.bind(this)
    });

    const self = this;

    // listen for modifications to document
    this.editor.on('change', function(e) {
      const fireChange = function(){
          // fix 4068: make sure script variable reflects current value
          self._fromme = true;
          self.script = self.getValue();
          delete self._fromme;

          // notify listeners editor changed
          self.fire('xbuilder-editor-change', e);
      };
      // amahen: this will prevent us from capturing every event (like removal of content immediately followed by insert...i.e replace)
      self.debounce('fireChange', fireChange, 250);
    });

    // listen to changes in cursor position
    this.editor.getSession().on("changeScrollTop", function(pos, session) {
      const fireScroll = function(){
        self.fire('xbuilder-editor-scroll', {
          position: pos
        });
      };
      self.debounce('fireScroll', fireScroll, 100);
    });
    
    this.editor.getSession().getSelection().on("changeCursor", function(e){
      const fireCursor = function(){
        self.fire('xbuilder-editor-cursor',{
          position: self.getCursorPosition()
        });
      };
      self.debounce('fireCursor', fireCursor, 50);
    });

    this.editor.setAutoScrollEditorIntoView(true);

    this.addCommand({
      name: 'format',
      bindKey: {
        win: 'Ctrl-Shift-F',
        mac: 'Command-Shift-F',
        sender: 'editor|cli'
      },
      exec: function(env, args, request) {
        if (this._formatter) {
          // remember cursor loc
          var pos = this.editor.getCursorPosition();

          // format a specific selection
          var range = this.editor.getSelectionRange();
          if (range.start.row != range.end.row || range.start.column != range.end.column) {
            var selectedtext = this.editor.getSession().getDocument().getTextRange(range);
            this.editor.getSession().getDocument().replace(range, this._formatter(selectedtext, env, args, request));
            return;
          }

          // format whole thing
          this.editor.setValue(this._formatter(this.editor.getValue(), env, args, request));
          this.editor.moveCursorToPosition(pos);
          this.editor.clearSelection();
        }
      }.bind(this)
    });
    if (this.html) {
      this.enableHTMLFormatter();
    } else {
      this.enableJSFormatter();
    }
    this.fire('xbuilder-editor-ready', {
      editor: this
    });
  },
  /**
   * Get the current position (row, column) of the cursor 
   */
  getCursorPosition: function(){
    return this.editor.getCursorPosition();
  },

  /**
   * Enables the javascript formatter
   */
  enableJSFormatter: function() {
    this.addFormatter(function(v) {
      return js_beautify(v, {
        "indent_size": 2,
        "preserve-newlines": true
      });
    });
  },

  /**
   * Enables the HTML formatter 
   */
  enableHTMLFormatter: function() {
    this.addFormatter(function(v) {
      return html_beautify(v, this._getHTMLFormatOptions());
    });
  },

  _getHTMLFormatOptions: function() {
    return {
      "indent_size": 2,
      "html": {
        "end_with_newline": true,
        "js": {
          "indent_size": 2
        },
        "css": {
          "indent_size": 2
        },
        "unformatted": [
          // https://www.w3.org/TR/html5/dom.html#phrasing-content
          'a', 'abbr', 'area', 'audio', 'b', 'bdi', 'bdo', 'br', 'button', 'canvas', 'cite',
          'code', 'data', 'datalist', 'del', 'dfn', 'em', 'embed', 'i', 'img',
          'ins', 'kbd', 'keygen', 'map', 'mark', 'math', 'meter', 'noscript',
          'object', 'output', 'progress', 'q', 'ruby', 's', 'samp', /* 'script', */ 'select', 'small',
          'strong', 'sub', 'sup', 'svg', 'time', 'u', 'var', 'video', 'wbr', 'text',
          // prexisting - not sure of full effect of removing, leaving in
          'acronym', 'address', 'big', 'dt', 'ins', 'strike', 'tt'
        ],
        "content_unformatted": ['pre', 'label', 'span', 'iframe', 'textarea', 'input']
      },
      "css": {
        "indent_size": 1
      },
      "js": {
        "preserve-newlines": true
      }
    };
  },
  attached: function() {

  },
  getCompletions: function(editor, session, pos, prefix, callback) {
    this.fire('xbuilder-editor-completion', {
      editor: this,
      session: session,
      pos: pos,
      prefix: prefix,
      callback: callback
    });
  },
  _computeStyle: function() {
    var retval = 'position:' + this.position + ';' + 'width:' + this.width + ';' + (this.height ? ('height:' + this.height + ';') : '');
    return retval;
  },
  _setScript: function(e) {
    // fix 4068: only do this when not coming from myself when changed
    if (this.editor && !this._fromme) {
      this.editor.setValue(this.script !== undefined ? this.script : '');
      this.editor.moveCursorTo(0, 0);
      this.editor.focus();
    }
  },
  _setTheme: function(e) {
    if (!this.theme || !this.editor) {
      return;
    }
    this.editor.setTheme(this.theme);
  },
  _setMode: function(e) {
    if (!this.mode || !this.editor) {
      return;
    }
    this.editor.getSession().setMode(this.mode);
    if (this.mode.match(/html$/i)) {
      this.enableHTMLFormatter();
    }
    if (this.mode.match(/xml$/i)) {
      this.enableHTMLFormatter();
    }
    if (this.mode.match(/javascript$/i)) {
      this.enableJSFormatter();
    }
    if (this.mode.match(/json$/i)) {
      this.enableJSFormatter();
    }
  },
  _setVim: function(e) {
    if (!this.editor) {
      return;
    }
    if (this.vim) {
      // set save command to :w (this assumes save command was created)
      if (!this._exDefined) {
        var api = ace.require('ace/keyboard/vim').CodeMirror.Vim;
        api.defineEx('write', 'w', function(cm, input) {
          cm.ace.execCommand('save');
        });
        api.defineEx('quit', 'q', function(cm, input) {
          cm.ace.execCommand('quit');
        });
        this._exDefined = true;
      }

      this.editor.setKeyboardHandler("ace/keyboard/vim");
    } else {
      this.editor.setKeyboardHandler(this._winkh);
    }
  },
  _hideLineNums: function(e) {
    if (!this.editor) {
      return;
    }
    this.editor.renderer.setShowGutter(!this.nolinenums);
  },
  _setHeight: function(e) {
    if (!this.editor) {
      return;
    }
    this.editor.resize(true);
  },
  getValue: function() {
    return this.editor.getValue();
  },
  /**
   * Adds a shortcut to a command
   */
  addCommand: function(cmd) {
    this.editor.commands.addCommand(cmd);
  },
  addFormatter: function(callback) {
    this._formatter = callback;
  }
});
