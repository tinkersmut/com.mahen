    Polymer({
      is: 'trm-d3tree',
      behaviors: [BaseComponent],
      properties: {

        /**
         * Root object (looks like {name:'Label',children:[]});
         */
        data: {
          type: Object,
          notify: true,
          observer: '_showTree'
        },

        /**
         * Width of this tree
         */
        width: {
          type: Number,
          value: 960
        },

        /**
         * Height of this tree
         */
        height: {
          type: Number,
          value: 800
        },

        /**
         * TRUE when this tree is oriented vertically. FALSE to orient horizontally
         */
        vertical: {
          type: Boolean,
          value: false
        },

        /**
         *  Duration between contraction/expansion animation
         */
        duration: {
          type: Number,
          value: 750
        },

        /**
         * Spacing between each level
         */
        depthSpacing: {
          type: Number,
          value: 180
        },

        skiproot: {
          type: Boolean,
          value: false
        },
        
        /**
         * Name of the color to use for the icon of nodes with children
         */
        parentColor: {
          type: String,
          value: 'lightsteelblue'
        },

        /**
         * Name of the color to use for the icon of nodes sans children OR expanded parent nodes
         */
        expandedColor: {
          type: String,
          value: '#fff'
        },

        /**
         * Offset of the text from center of node (to the right or left of the node depending on if it has children)
         */
        textXOffset: {
          type: Number,
          value: 10
        },

        /**
         * Offset of the text from center of node (to the right or left of the node depending on if it has children)
         */
        textYOffset: {
          type: Number,
          value: 10
        },

        /**
         * Name of the svg element that represents each node (default to a rect). Set to g when iconGetter is set
         */
        svgNodeElement: {
          type: String,
          value: 'rect'
        },

        /**
         * Map of attribute name/value pairs used to set properties on each svg element that represents a node
         */
        svgNodeElementAttributes: {
          type: Object
        },

        /**
         * Set this to 10 if NOT using icons
         */
        iconWidth: {
          type: Number,
          value: 24
        },
        /**
         * Set this to 10 if NOT using icons
         */
        iconHeight: {
          type: Number,
          value: 24
        },
        
        /**
         * note that iconWith should not change after the getter is set
         */
        iconGetter: {
          type: Object,
          observer: '_useIcon'
        },
        iconColor: {
          type: String,
          value: 'steelblue'
        },
        iconColorDisabled: {
          type: String,
          value: 'lightgray'
        },
        parentIconColor: {
          type: String,
          value: 'darkgreen'
        },
        parentIconColorDisabled: {
          type: String,
          value: 'darkgray'
        },
        /**
         * Defaults to _getIconStroke method. Set to configure your own function for determining icon color
         */
        iconStrokeFunction: {
          type: Object
        },

        /**
         * Defaults to _linkDashFunction method. configures the style of line connecting 2 nodes
         */
        linkDashFunction: {
          type: Object
        },
        /**
         *Used in place of linkDashFunction. When disabled this is the style of the dash array for disabled target nodes
         */
        linkDashStyle: {
          type: String,
          value: "10,10"
        },
        /**
         * Count used for creating unique node ids
         */
        _ID: {
          type: Number,
          value: 0
        },

        _meta: {
          value: Polymer.Base.create('iron-meta', {
            type: 'iconset'
          })
        }

      },

      observers: [
        '_setTreeSize(width,height,vertical,skiproot)'
      ],
      created: function() {
        // default style functions
        this.iconStrokeFunction = this._getIconStroke.bind(this);
        this.linkDashFunction = this._linkDashFunction.bind(this);
      },

      ready: function() {

      },

      attached: function() {
        //this._tree = d3.layout.tree().size([this.width, this.height]);
        this._tree = d3.layout.tree();

        var self = this;

        this.diagonal = d3.svg.diagonal().projection(function(d) {
          if (self.vertical) {
            return [d.x, d.y];
          }
          //horizontal orientation
          return [d.y, d.x];
        });

        // define the zoomListener which calls the zoom function on the "zoom" event constrained within the scaleExtents
        this._zoomListener = d3.behavior.zoom().scaleExtent([0.1, 3]).on("zoom", () => {
           let event = d3.event;
           this.debounce('zoom', () => {
               this._zoom(event);
           }, 10); 
        });

        this.svg = d3.select(this.$.svg).append("g");

        // true so it keeps css/styling for expansion/contraction
        this.scopeSubtree(this.$.svg, true);
        this._setTreeSize(this.width, this.height, this.vertical, this.skiproot);

        // delayed fire since data was set before attach
        if(this.data !== undefined){
          this._showTree();
        }
      },

      /** Define the zoom function for the zoomable tree
       *
       */
      _zoom: function(event) {
          // safety first
        if(event === undefined || event.sourceEvent === undefined){
            return;
        }
        var left = this._left + event.translate[0];
        var top = this._top + event.translate[1];

        // only zoom on wheelevent
        if (this._scale && this._scale != event.scale) {
          if (!event.sourceEvent || event.sourceEvent.type != 'wheel') {
            return;
          }
        }
        this.svg.attr("transform", "translate(" + [left, top] + ")scale(" + event.scale + ")");
        this._scale = event.scale;
      },

      sortTree: function() {
        this._tree.sort(function(a, b) {
          return b.name.toLowerCase() < a.name.toLowerCase() ? 1 : -1;
        });
      },

      getIconPath: function(icon) {
        //TODO: only works if iconset is loaded...fix this (gotta listen for event on window)
        var temp = (icon || '').split(':');
        var iconName = temp.pop();
        var iconsetName = temp.pop() || 'icons';
        var iconset = (this._meta.byKey(iconsetName));
        if (iconset) {
          var icons = iconset._icons || iconset._createIconMap();
          if (icons[iconName]) {
            return icons[iconName].firstElementChild.getAttribute('d');
          } else {
            console.log('no icons in set ' + iconsetName + ' for ', iconName);
          }
        } else {
          console.log('no icons for ', iconsetName);
        }
        return '';
      },

      _useIcon: function(getter) {
        this.svgNodeElement = 'g';
        this.parentColor = this.expandedColor;
        this.textXOffset = 15;
        // base 24px for icon sets
        // note that iconWith should not change after the getter is set
        this._iconsize = this.iconWidth/24;
      },

      _setTreeSize: function() {
        if (!this._tree) {
          return;
        }
        // think of width and height as max longitude and latitude
        var size = !this.vertical ? [this.height, this.width] : [this.width, this.height];
        this._tree.size(size);
        this.$.svg.setAttribute("style", "width:" + this.width + "px;height:" + this.height + "px");

        // keeps a min distance between siblings (figured this out via trial and error since cousin value {2} affects sibling value {2.35} )
        this._tree.separation(function(a, b) {
          return a.parent == b.parent ? 2.35 : 2;
        });

        var coord = this.vertical ? [-10, 20] : [50, -10];
        if (this.skiproot) {
          coord = this.vertical ? [coord[0], coord[1] - this.depthSpacing] : [coord[0] - this.depthSpacing, coord[1]];
        }
        this._left = coord[0];
        this._top = coord[1];


        d3.select(this.$.svg).select('g').attr("transform", "translate(" + this._left + "," + this._top + ")");

        d3.select(this.$.svg).call(this._zoomListener);
      },

      /**
       * Called when root is set
       */
      _showTree: function() {
        if(this.data === undefined || this._tree === undefined){
          return;
        }
        // data x is the not carteasan in this case (because of vertical vs horizontal) so x will always be the longitude and y the lat. So the starting longitude is always half
        this.data.x0 = this.width / 2;
        this.data.y0 = 0;


        this._update(this.data);

        d3.select(this.$.svg).style("height", this.height);

        // true so it keeps css/styling for expansion/contraction
        this.scopeSubtree(this.$.svg, true);
        Polymer.Base.toggleClass('flex', true, this.$.svg);
      },

      /**
       * Collapse an element and all its children
       */
      collapseNode: function(element) {
        if (element.children) {
          element._children = element.children;
          // call myself
          element._children.forEach(this.collapseNode.bind(this));
          element.children = null;
        }
      },

      _getIconStroke: function(node) {
        //amahen: had trouble with css since it gets separated from shadow dom
        if ((node.isDisabled && node.isDisabled()) || node.disabled === 'true') {
          return node._children ? this.parentIconColorDisabled : this.iconColorDisabled;
        }
        return node._children ? this.parentIconColor : this.iconColor;
      },

      _createIconElement: function(nodeEnter) {
        var retval = nodeEnter.append(this.svgNodeElement).attr("class", "icon").attr("width", 1e-6).attr("height", 1e-6).style("fill", this._getFill.bind(this)).style("fill", this.iconStrokeFunction);
        if (this.iconGetter) {
          retval.attr("transform", "translate(-10,-10)");
          retval.append('rect').attr("width", this.iconWidth).attr("height", this.iconHeight).style("fill", this.expandedColor).style("stroke-width", 0);
          let path = retval.append('path');
          
          // scale if nec.
          if(this._iconsize != 1){
            path.style("transform", `scale(${this._iconsize})`).style("-ms-transform", `scale(${this._iconsize})`).style("-webkit-transform", `scale(${this._iconsize})`);
          }
          
          path.attr("d", function(node) {
            var iconname = this.iconGetter(node);
            return this.getIconPath(iconname);
          }.bind(this));
          
          return retval;
        } else if (this.svgNodeElementAttributes) {
          for (var att in this.svgNodeElementAttributes) {
            retval.attr(att, this.svgNodeElementAttributes[att]);
          }
        }
        return retval;
      },

      /**
       * Updates the tree (drawing and transitioning nodes and links)
       */
      _update: function(source) {

        // Compute the new tree layout.
        var nodes = this._tree.nodes(this.data).reverse();
        var self = this;

        // Normalize for fixed-depth.
        nodes.forEach(function(d) {
          // y is not carteasan its the radius from parent (since we can shift between vert and horiz)
          d.y = d.depth * self.depthSpacing;
        });

        var links = this._tree.links(nodes);

        // Update the nodes…
        var node = this.svg.selectAll("g.node").data(nodes, function(d) {
          return d.id || (d.id = self._ID++);
        });

        // Enter any new nodes at the parent's previous position.
        var nodeEnter = node.enter().append("g").attr("class", "node").attr("transform", function(d) {
          if (self.vertical) {
            return "translate(" + source.x0 + "," + source.y0 + ")";
          }
          //horizontal orientation
          return "translate(" + source.y0 + "," + source.x0 + ")";
        }).on("click", this.click.bind(this)).on("dblclick", this.dblclick.bind(this)).on("contextmenu", function(n) {
          self.rightClick(n, d3.event.pageX, d3.event.pageY);
          d3.event.preventDefault();
        }).style("display", function(d) {
          return self.skiproot && d.depth === 0 ? "none" : undefined;
        });

        // create image for node (initial)
        this._createIconElement(nodeEnter);

        // create and anchor text for node
        var nodetext = nodeEnter.append("text");
        nodetext.attr("x", this._getTextXOffset.bind(this)).attr("y", this._getTextYOffset.bind(this)).attr("dy", this._getDY.bind(this)).attr("text-anchor", this._getAnchor.bind(this)).text(self._getName).style("fill-opacity", 1e-6).style("display", function(d) {
          return self.skiproot && d.depth === 0 ? "none" : undefined;
        });
        if (this.textFillFunction) {
          nodetext.style("fill", this.textFillFunction);
        }

        // move nodes to new posit
        var nodeUpdate = node.transition().duration(this.duration).attr("transform", function(d) {
          if (self.vertical) {
            return "translate(" + d.x + "," + d.y + ")";
          }
          //horizontal orientation
          return "translate(" + d.y + "," + d.x + ")";
        });

        // final attributes/sizes
        nodeUpdate.select(this.svgNodeElement).attr("width", this.iconWidth).attr("height", this.iconHeight).attr('x', -5).style("fill", this._getFill.bind(this)).style("fill", this.iconStrokeFunction);
        nodeUpdate.select("text").attr("x", this._getTextXOffset.bind(this)).attr("y", this._getTextYOffset.bind(this)).attr("dy", this._getDY.bind(this)).attr("text-anchor", this._getAnchor.bind(this)).style("fill-opacity", 1);

        // Transition exiting nodes to the parent's new position.
        var nodeExit = node.exit().transition().duration(this.duration).attr("transform", function(d) {
          if (self.vertical) {
            return "translate(" + source.x + "," + source.y + ")";
          }
          //horizontal orientation
          return "translate(" + source.y + "," + source.x + ")";
        }).remove();

        nodeExit.select(this.svgNodeElement).attr("width", 1e-6).attr("height", 1e-6).attr("transform", function() {
          if (this.svgNodeElement === 'g') {
            return 'scale(.01,.01)';
          }
        }.bind(this));

        nodeExit.select("text").style("fill-opacity", 1e-6);

        // Update the links…
        var link = this.svg.selectAll("path.link").data(links, function(d) {
          return d.target.id;
        });

        // Enter any new links at the parent's previous position.
        var linkenter = link.enter().insert("path", "g").attr("class", "link").attr("d", function(d) {
          var o = {
            x: source.x0,
            y: source.y0
          };
          return self.diagonal({
            source: o,
            target: o
          });
        }).style("display", function(d) {
          return self.skiproot && d.source && d.source.depth === 0 ? "none" : undefined;
        });
        if (this.linkDashFunction) {
          linkenter.style("stroke-dasharray", this.linkDashFunction);
        }

        // Transition links to their new position.
        link.transition().duration(this.duration).attr("d", this.diagonal);

        // Transition exiting nodes to the parent's new position.
        link.exit().transition().duration(this.duration).attr("d", function(d) {
          var o = {
            x: source.x,
            y: source.y
          };
          return self.diagonal({
            source: o,
            target: o
          });
        }).remove();

        // Stash the old positions for transition.
        nodes.forEach(function(d) {
          d.x0 = d.x;
          d.y0 = d.y;
        });

        Polymer.Base.distributeContent(true);
      },

      _getName: function(node) {
        if (this.getName) {
          return this.getName.apply(this, arguments);
        }
        return node.name;
      },

      _getFill: function(node) {
        return node._children ? this.parentColor : this.expandedColor;
      },

      _linkDashFunction: function(node) {
        if (node.target) {
          var n = node.target;
          if ((n.isDisabled && n.isDisabled()) || n.disabled === "true") {
            return this.linkDashStyle;
          }
        }
      },

      _getDY: function(node){
        // for better control of text position
        if (node.textpos != undefined) {
          return node.textpos.getDY(node);
        }
        return '1em'; 
      },
      
      _getAnchor: function(node) {
        // for better control of text position
        if (node.textpos != undefined) {
          return node.textpos.getAnchor(node);
        }
        return node.children || node._children ? "end" : "middle";
      },

      _getTextXOffset: function(node) {
        // for better control of text position
        if (node.textpos != undefined) {
          return node.textpos.getXOffset(node);
        }
        return node.children || node._children ? (-1 * this.textXOffset) : undefined;
      },

      _getTextYOffset: function(node) {
        // for better control of text position
        if (node.textpos != undefined) {
          return node.textpos.getYOffset(node);
        }
        return node.children || node._children ? (-10) : this.textYOffset;
      },

      /** 
       * Not used (zooms too far etc) needs tweaking
       * 
       */
      _centerNode: function(source) {
        this._scale = this._zoomListener.scale();
        var x = -source.y0;
        var y = -source.x0;
        x = x * this._scale + this.width / 2;
        y = y * this._scale + this.height / 2;
        d3.select('g').transition().duration(this.duration).attr("transform", "translate(" + x + "," + y + ")scale(" + this._scale + ")");
        this._zoomListener.scale(this._scale);
        this._zoomListener.translate([x, y]);
      },

      /**
       * Collapses all nodes in the tree
       */
      collapseAll: function(doupdate) {
        this.collapseNode(this.data, false);
        if (doupdate) {
          this._update(element);
        }
      },

      click: function(d) {
        // prevent movement on dbl click
        var self = this;
        this.debounce('_click', function() {
          self._click(d);
        }, 200);
      },

      _click: function(d) {
        // toggle
        this.toggleChildren(d);
      },

      /**
       * If collapsed, expand. If expanded, collapse
       */
      toggleChildren: function(d, skipupdate) {
        if (d.children) {
          d._children = d.children;
          d.children = null;
        } else {
          d.children = d._children;
          d._children = null;
        }
        if (!skipupdate) {
          this._update(d);
        }
        return d;
      },

      dblclick: function(d) {
        // cancel transform if one
        this.cancelDebouncer('_click');

        this.fire('edit-node', {
          node: d,
          tree: this
        });
      },

      /**
       * Called on right-click of a node
       */
      rightClick: function(e, x, y) {
        this._showContextMenu(e, x, y);

        // fire an event incase containing component wants to handle it
        this.fire('contextmenu-node', {
          node: e,
          x: x,
          y: y,
          tree: this
        });
      },

      /**
       * Closes an open context menu
       */
      closeContextMenu: function(e) {
        // clear current node for all actions
        if (this._cmactions) {
          this._cmactions.forEach(function(action) {
            action.node = undefined;
          });
        }

        var menu = this._menu;
        this._menu = undefined;
        if (menu) {
          Polymer.Base.async(function() {
            menu.close();
            menu.remove();
          }, 200);
        }
      },

      /**
       * Called when a context menu action is selected
       */
      _runContextAction: function(e) {
        let item = e.detail.item;
        let node = item.node;
        this.closeContextMenu(e);
        if (node && item.run && typeof(item.run) === 'function') {
          item.run(node);
          this._update(node);
        }
      },

      /**
       * Called when a node item is clicked. Will open the context menu at the specified point
       */
      _showContextMenu: function(node, x, y) {
        // no actions to show
        if (!this._cmactions || !this._cmactions.length) {
          return;
        }

        // set the current node for each action
        this._cmactions.forEach(function(action) {
          action.node = node;
          //TODO: configure check states for check actions
        });
         var items = this._cmactions.filter(function(action) {
          // always show
          if (action.hide === undefined) {
            return true;
          }
          if (typeof(action.hide) == 'function') {
            return !action.hide(node);
          }
          return !acton.hide;
        });
        if (!items.length) {
          return;
        }
        
        if(!this._menu){
            this._menu = Polymer.Base.create('trm-contextmenu',{
                id: 'menu'
            });
            this.$.svg.parentNode.insertBefore(this._menu, this.$.svg);
            this.listen(this._menu, 'iron-select', '_runContextAction');
        }
        this._menu.items = items;


        // needed for positioning
        this._menu.top = y;
        this._menu.left = x;

        // open it
        this._menu.open();
      },

      /**
       * Add an action to be displayed on right click of a node. This can include a hide method (passed node at invoke time).
       * @param action POJO ex: {name: function(node), icon: function(node), hide: function(node), run: function(nod)}
       */
      addContextAction: function(action) {
        let temp = this._cmactions ? this._cmactions : [];
        this._cmactions = temp.concat(action);
      }


    });
